import { useState } from 'react';
import { motion } from 'motion/react';
import { BOARD_IMAGE_PATH, BOARD_TILES, CATEGORY_META } from '../data/board';
import { Player } from '../types/game';
import { PlayerTokenIcon } from './PlayerTokenIcon';

interface BoardViewProps {
  players: Player[];
  currentPlayerIndex: number;
  isMoving: boolean;
}

function getOffsetForCluster(count: number, indexInTile: number): { dx: number; dy: number } {
  if (count <= 1) return { dx: 0, dy: 0 };
  if (count === 2) {
    return indexInTile === 0 ? { dx: -1.7, dy: -1.2 } : { dx: 1.7, dy: 1.2 };
  }
  if (count === 3) {
    const offsets = [
      { dx: -1.8, dy: -1.5 },
      { dx: 1.8, dy: -1.5 },
      { dx: 0, dy: 1.8 },
    ];
    return offsets[indexInTile] ?? { dx: 0, dy: 0 };
  }
  const offsets = [
    { dx: -1.8, dy: -1.7 },
    { dx: 1.8, dy: -1.7 },
    { dx: -1.8, dy: 1.7 },
    { dx: 1.8, dy: 1.7 },
  ];
  return offsets[indexInTile] ?? { dx: 0, dy: 0 };
}

export function BoardView({
  players,
  currentPlayerIndex,
  isMoving,
}: BoardViewProps) {
  const [imageError, setImageError] = useState(false);

  const activePlayer = players[currentPlayerIndex];
  const activeTile = activePlayer ? BOARD_TILES[activePlayer.position] : BOARD_TILES[0];
  const activeMeta = CATEGORY_META[activeTile.type];

  const tileGroups = new Map<number, Player[]>();
  players.forEach((p) => {
    const list = tileGroups.get(p.position) ?? [];
    list.push(p);
    tileGroups.set(p.position, list);
  });

  return (
    <div className="relative w-full max-w-[min(86vh,720px)] mx-auto aspect-square rounded-2xl overflow-hidden bg-black border border-white/15 shadow-[0_24px_64px_rgba(0,0,0,0.8)] select-none">
      {!imageError ? (
        <img
          src={BOARD_IMAGE_PATH}
          alt="Tablero del juego Neta sabes? con recorrido perimetral en sentido horario desde Salida"
          referrerPolicy="no-referrer"
          onError={() => setImageError(true)}
          className="w-full h-full object-contain block pointer-events-none"
        />
      ) : (
        <div className="w-full h-full flex flex-col items-center justify-center bg-slate-950 text-slate-300 p-6 text-center">
          <p className="font-display text-2xl font-bold text-white">Neta sabes?</p>
          <p className="text-sm text-slate-400 mt-1">No se pudo cargar la imagen del tablero.</p>
        </div>
      )}

      {/* Active tile highlight */}
      {activeTile && (
        <motion.div
          aria-hidden="true"
          className="absolute pointer-events-none rounded-lg"
          animate={{
            left: `${activeTile.x}%`,
            top: `${activeTile.y}%`,
          }}
          transition={{ type: 'spring', stiffness: 420, damping: 32 }}
          style={{
            width: '9.2%',
            height: '9.2%',
            transform: 'translate(-50%, -50%)',
            boxShadow: `0 0 0 2.5px ${activePlayer?.color.hex ?? '#F59E0B'}, 0 0 22px ${activeMeta.accentHex}99`,
          }}
        />
      )}

      {/* Smoothly animated player tokens */}
      {players.map((player) => {
        const tile = BOARD_TILES[player.position] ?? BOARD_TILES[0];
        const group = tileGroups.get(player.position) ?? [player];
        const indexInGroup = group.findIndex((g) => g.id === player.id);
        const { dx, dy } = getOffsetForCluster(group.length, indexInGroup);
        const isCurrent = player.id === activePlayer?.id;

        return (
          <motion.div
            key={player.id}
            animate={{
              left: `${tile.x + dx}%`,
              top: `${tile.y + dy}%`,
              scale: isCurrent && isMoving ? 1.18 : isCurrent ? 1.08 : 1,
              y: isCurrent && isMoving ? -6 : 0,
            }}
            transition={{
              left: { type: 'spring', stiffness: 340, damping: 26 },
              top: { type: 'spring', stiffness: 340, damping: 26 },
              scale: { duration: 0.14 },
              y: { duration: 0.14 },
            }}
            style={{
              zIndex: isCurrent ? 30 : 20,
              transform: 'translate(-50%, -50%)',
            }}
            className="absolute -translate-x-1/2 -translate-y-1/2"
            title={`${player.name} — ${tile.label}`}
          >
            <div className="relative flex flex-col items-center">
              {isCurrent && (
                <span
                  className="mb-0.5 px-1.5 py-px rounded text-[10px] font-bold tracking-tight text-slate-950 shadow-md whitespace-nowrap leading-tight"
                  style={{ backgroundColor: player.color.ringHex }}
                >
                  {player.name.split(' ')[0]}
                </span>
              )}
              <div
                className={`rounded-full transition-shadow duration-150 ${
                  isCurrent ? 'ring-2 ring-amber-300 shadow-lg' : 'opacity-95'
                }`}
              >
                <PlayerTokenIcon color={player.color} size={group.length > 2 ? 'sm' : 'md'} />
              </div>
            </div>
          </motion.div>
        );
      })}
    </div>
  );
}
