import type { BoardTile, CategoryMeta, PlayerColorOption, TileType } from '../types/game.ts';

export const BOARD_IMAGE_PATH =
  '/assets/aistudio/file_00000000c6e081f5a30c63b9a7ac2295_e21ea8dc.png';

export const TOTAL_TILES = 36;

export const CATEGORY_META: Record<TileType, CategoryMeta> = {
  SALIDA: {
    id: 'SALIDA',
    label: 'Salida',
    accentHex: '#F8FAFC',
    textOnAccent: '#0F172A',
    softBgClass: 'bg-slate-100',
    borderClass: 'border-slate-300',
    badgeTextClass: 'text-slate-900',
  },
  EXTRA: {
    id: 'EXTRA',
    label: 'Extra',
    accentHex: '#FFFFFF',
    textOnAccent: '#0F172A',
    softBgClass: 'bg-white',
    borderClass: 'border-slate-300',
    badgeTextClass: 'text-slate-900',
  },
  historia: {
    id: 'historia',
    label: 'Historia',
    accentHex: '#EF4444',
    textOnAccent: '#FFFFFF',
    softBgClass: 'bg-red-500',
    borderClass: 'border-red-400',
    badgeTextClass: 'text-red-400',
  },
  matematicas: {
    id: 'matematicas',
    label: 'Matemáticas',
    accentHex: '#F97316',
    textOnAccent: '#FFFFFF',
    softBgClass: 'bg-orange-500',
    borderClass: 'border-orange-400',
    badgeTextClass: 'text-orange-400',
  },
  filosofia: {
    id: 'filosofia',
    label: 'Filosofía',
    accentHex: '#A855F7',
    textOnAccent: '#FFFFFF',
    softBgClass: 'bg-purple-500',
    borderClass: 'border-purple-400',
    badgeTextClass: 'text-purple-400',
  },
  ciencias: {
    id: 'ciencias',
    label: 'Ciencias',
    accentHex: '#22C55E',
    textOnAccent: '#052E16',
    softBgClass: 'bg-green-500',
    borderClass: 'border-green-400',
    badgeTextClass: 'text-green-400',
  },
  arte: {
    id: 'arte',
    label: 'Arte',
    accentHex: '#EC4899',
    textOnAccent: '#FFFFFF',
    softBgClass: 'bg-pink-500',
    borderClass: 'border-pink-400',
    badgeTextClass: 'text-pink-400',
  },
  cultura_general: {
    id: 'cultura_general',
    label: 'Cultura General',
    accentHex: '#EAB308',
    textOnAccent: '#0F172A',
    softBgClass: 'bg-yellow-400',
    borderClass: 'border-yellow-300',
    badgeTextClass: 'text-yellow-400',
  },
  geografia: {
    id: 'geografia',
    label: 'Geografía',
    accentHex: '#06B6D4',
    textOnAccent: '#083344',
    softBgClass: 'bg-cyan-400',
    borderClass: 'border-cyan-300',
    badgeTextClass: 'text-cyan-400',
  },
};

export const PLAYER_COLORS: PlayerColorOption[] = [
  {
    id: 'rojo',
    name: 'Rojo Rubí',
    hex: '#EF4444',
    ringHex: '#FCA5A5',
    textHex: '#FFFFFF',
    shape: 'circle',
  },
  {
    id: 'azul',
    name: 'Azul Eléctrico',
    hex: '#3B82F6',
    ringHex: '#93C5FD',
    textHex: '#FFFFFF',
    shape: 'diamond',
  },
  {
    id: 'verde',
    name: 'Verde Lima',
    hex: '#10B981',
    ringHex: '#6EE7B7',
    textHex: '#052E16',
    shape: 'triangle',
  },
  {
    id: 'amarillo',
    name: 'Ámbar Dorado',
    hex: '#F59E0B',
    ringHex: '#FDE68A',
    textHex: '#1E1B0A',
    shape: 'star',
  },
];

// Exact 36-tile clockwise perimeter starting at SALIDA (bottom-left corner = index 0)
// Coordinates measured directly from the board PNG pixels for exact centering.
export const BOARD_TILES: BoardTile[] = [
  // Bottom-Left Corner
  { index: 0, type: 'SALIDA', label: 'Salida', x: 5.94, y: 93.5, isCorner: true },

  // Left Column (bottom to top)
  { index: 1, type: 'historia', label: 'Historia', x: 5.55, y: 85.01 },
  { index: 2, type: 'matematicas', label: 'Matemáticas', x: 5.55, y: 76.71 },
  { index: 3, type: 'EXTRA', label: 'Extra', x: 5.55, y: 66.83 },
  { index: 4, type: 'filosofia', label: 'Filosofía', x: 5.55, y: 56.9 },
  { index: 5, type: 'arte', label: 'Arte', x: 5.55, y: 46.85 },
  { index: 6, type: 'EXTRA', label: 'Extra', x: 5.55, y: 36.96 },
  { index: 7, type: 'geografia', label: 'Geografía', x: 5.55, y: 27.15 },
  { index: 8, type: 'cultura_general', label: 'Cultura General', x: 5.55, y: 16.99 },

  // Top-Left Corner
  { index: 9, type: 'EXTRA', label: 'Extra', x: 5.46, y: 6.1, isCorner: true },

  // Top Row (left to right)
  { index: 10, type: 'historia', label: 'Historia', x: 15.75, y: 6.1 },
  { index: 11, type: 'matematicas', label: 'Matemáticas', x: 26.2, y: 6.1 },
  { index: 12, type: 'filosofia', label: 'Filosofía', x: 36.68, y: 6.1 },
  { index: 13, type: 'ciencias', label: 'Ciencias', x: 46.89, y: 6.1 },
  { index: 14, type: 'EXTRA', label: 'Extra', x: 56.5, y: 6.1 },
  { index: 15, type: 'arte', label: 'Arte', x: 66.03, y: 6.1 },
  { index: 16, type: 'cultura_general', label: 'Cultura General', x: 75.6, y: 6.1 },
  { index: 17, type: 'geografia', label: 'Geografía', x: 84.93, y: 6.1 },

  // Top-Right Corner
  { index: 18, type: 'EXTRA', label: 'Extra', x: 94.54, y: 6.14, isCorner: true },

  // Right Column (top to bottom)
  { index: 19, type: 'filosofia', label: 'Filosofía', x: 94.54, y: 17.07 },
  { index: 20, type: 'ciencias', label: 'Ciencias', x: 94.54, y: 27.39 },
  { index: 21, type: 'historia', label: 'Historia', x: 94.54, y: 37.4 },
  { index: 22, type: 'cultura_general', label: 'Cultura General', x: 94.54, y: 47.29 },
  { index: 23, type: 'EXTRA', label: 'Extra', x: 94.54, y: 57.14 },
  { index: 24, type: 'matematicas', label: 'Matemáticas', x: 94.54, y: 66.99 },
  { index: 25, type: 'arte', label: 'Arte', x: 94.54, y: 76.87 },
  { index: 26, type: 'geografia', label: 'Geografía', x: 94.54, y: 85.73 },

  // Bottom-Right Corner
  { index: 27, type: 'EXTRA', label: 'Extra', x: 94.62, y: 94.14, isCorner: true },

  // Bottom Row (right to left back toward SALIDA)
  { index: 28, type: 'matematicas', label: 'Matemáticas', x: 84.61, y: 93.8 },
  { index: 29, type: 'filosofia', label: 'Filosofía', x: 74.68, y: 93.8 },
  { index: 30, type: 'geografia', label: 'Geografía', x: 64.87, y: 93.8 },
  { index: 31, type: 'EXTRA', label: 'Extra', x: 55.62, y: 93.8 },
  { index: 32, type: 'ciencias', label: 'Ciencias', x: 46.33, y: 93.8 },
  { index: 33, type: 'historia', label: 'Historia', x: 36.36, y: 93.8 },
  { index: 34, type: 'cultura_general', label: 'Cultura General', x: 26.48, y: 93.8 },
  { index: 35, type: 'arte', label: 'Arte', x: 16.43, y: 93.8 },
];
