import { Bot, Flag, PauseCircle, WifiOff } from 'lucide-react';
import { BOARD_TILES, CATEGORY_META } from '../data/board';
import { ANSWER_MODE_META, DIFFICULTY_META } from '../data/questions';
import { AnswerMode, DifficultyLevel, Player, TurnEvent } from '../types/game';
import { PlayerTokenIcon } from './PlayerTokenIcon';

interface ScoreboardPanelProps {
  players: Player[];
  currentPlayerIndex: number;
  roundNumber: number;
  finalRoundTriggered: boolean;
  difficulty: DifficultyLevel;
  answerMode?: AnswerMode;
  events: TurnEvent[];
  myClientId?: string;
}

export function ScoreboardPanel({
  players,
  currentPlayerIndex,
  roundNumber,
  finalRoundTriggered,
  difficulty,
  answerMode = 'multiple_choice',
  events,
  myClientId,
}: ScoreboardPanelProps) {
  return (
    <div className="bg-black border border-white/20 rounded-2xl p-4 sm:p-5 flex flex-col gap-4 shadow-[0_0_30px_rgba(255,255,255,0.04)]">
      <div className="flex flex-wrap items-center justify-between gap-2 border-b border-white/15 pb-3">
        <h2 className="font-display text-lg font-bold text-white">Marcador</h2>
        <div className="flex flex-wrap items-center gap-1.5 text-xs text-neutral-300 tabular-nums">
          <span className="px-2.5 py-0.5 rounded-full bg-white/10 border border-white/15 font-medium">
            Ronda {roundNumber}
          </span>
          <span className="px-2.5 py-0.5 rounded-full bg-white/10 border border-white/15 font-medium">
            {DIFFICULTY_META[difficulty].label}
          </span>
          <span className="px-2.5 py-0.5 rounded-full bg-cyan-400/15 border border-cyan-400/35 text-cyan-300 font-medium">
            {ANSWER_MODE_META[answerMode].shortLabel}
          </span>
          {finalRoundTriggered && (
            <span className="px-2.5 py-0.5 rounded-full bg-yellow-400 text-black font-bold">
              Final
            </span>
          )}
        </div>
      </div>

      <ul className="space-y-2.5">
        {players.map((player, idx) => {
          const isTurn = idx === currentPlayerIndex;
          const isMe = Boolean(myClientId && player.clientId === myClientId);
          const tile = BOARD_TILES[player.position] ?? BOARD_TILES[0];
          const tileMeta = CATEGORY_META[tile.type];

          return (
            <li
              key={player.id}
              style={
                isTurn
                  ? {
                      borderColor: player.color.hex,
                      boxShadow: `0 0 20px ${player.color.hex}38`,
                    }
                  : undefined
              }
              className={`rounded-xl px-3.5 py-2.5 border transition-all ${
                isTurn ? 'bg-neutral-950' : 'bg-black border-white/12'
              }`}
            >
              <div className="flex items-center justify-between gap-3">
                <div className="flex items-center gap-2.5 min-w-0">
                  <PlayerTokenIcon color={player.color} size="sm" />
                  <div className="min-w-0">
                    <div className="flex items-center gap-1.5 flex-wrap">
                      <span className="font-display font-bold text-sm text-white truncate">
                        {player.name}
                      </span>
                      {player.isBot && (
                        <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-full bg-cyan-400/15 border border-cyan-400/35 text-[10px] font-bold text-cyan-300 whitespace-nowrap shrink-0">
                          <Bot className="w-2.5 h-2.5" aria-hidden="true" />
                          {DIFFICULTY_META[player.botDifficulty ?? 'medium'].label}
                        </span>
                      )}
                      {isMe && (
                        <span className="px-2 py-0.5 rounded-full bg-white/10 text-[10px] font-semibold text-neutral-200 whitespace-nowrap shrink-0">
                          Tú
                        </span>
                      )}
                      {isTurn && (
                        <span className="px-2 py-0.5 rounded-full bg-yellow-400 text-black text-[10px] font-bold whitespace-nowrap shrink-0">
                          En turno
                        </span>
                      )}
                    </div>
                    <div className="text-xs text-neutral-400 flex items-center gap-1.5 truncate mt-0.5">
                      <span style={{ color: tileMeta.accentHex }} className="font-medium">
                        {tileMeta.label}
                      </span>
                      <span aria-hidden="true">·</span>
                      <span className="tabular-nums">Casilla {player.position}</span>
                      {player.completedLap && (
                        <>
                          <span aria-hidden="true">·</span>
                          <span className="inline-flex items-center gap-1 text-emerald-400 font-medium">
                            <Flag className="w-3 h-3" aria-hidden="true" />
                            Meta
                          </span>
                        </>
                      )}
                      {player.skipNextTurn && (
                        <>
                          <span aria-hidden="true">·</span>
                          <span className="inline-flex items-center gap-1 text-rose-400 font-medium">
                            <PauseCircle className="w-3 h-3" aria-hidden="true" />
                            Pierde turno
                          </span>
                        </>
                      )}
                      {player.connected === false && (
                        <>
                          <span aria-hidden="true">·</span>
                          <span className="inline-flex items-center gap-1 text-neutral-400">
                            <WifiOff className="w-3 h-3" aria-hidden="true" />
                            Desconectado
                          </span>
                        </>
                      )}
                    </div>
                  </div>
                </div>

                <div className="shrink-0">
                  <span className="inline-flex items-baseline gap-1 px-3 py-1 rounded-full bg-white/10 border border-white/15 font-display text-base font-bold text-white tabular-nums">
                    {player.score}
                    <span className="text-[11px] font-sans font-medium text-neutral-300">
                      {player.score === 1 ? 'pto' : 'pts'}
                    </span>
                  </span>
                </div>
              </div>
            </li>
          );
        })}
      </ul>

      {events.length > 0 && (
        <div className="border-t border-white/15 pt-3">
          <h3 className="font-display text-xs font-semibold text-neutral-400 mb-2">
            Últimas jugadas
          </h3>
          <ul className="space-y-1.5">
            {events.slice(0, 3).map((ev) => (
              <li key={ev.id} className="text-xs text-neutral-300 flex items-start gap-2">
                <span
                  className="w-2 h-2 rounded-full mt-1.5 shrink-0"
                  style={{ backgroundColor: ev.playerHex }}
                  aria-hidden="true"
                />
                <span>
                  <strong className="text-white font-semibold">{ev.playerName}:</strong>{' '}
                  {ev.summary}
                </span>
              </li>
            ))}
          </ul>
        </div>
      )}
    </div>
  );
}
