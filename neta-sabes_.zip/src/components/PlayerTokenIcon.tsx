import { PlayerColorOption } from '../types/game';

interface PlayerTokenIconProps {
  color: PlayerColorOption;
  size?: 'sm' | 'md' | 'lg';
  label?: string;
}

export function PlayerTokenIcon({
  color,
  size = 'md',
  label,
}: PlayerTokenIconProps) {
  const sizeClasses = {
    sm: 'w-5 h-5 text-[10px]',
    md: 'w-7 h-7 text-xs',
    lg: 'w-9 h-9 text-sm',
  }[size];

  return (
    <span
      className={`${sizeClasses} inline-flex items-center justify-center rounded-full font-bold shadow-md ring-2 ring-white/90 shrink-0 select-none`}
      style={{
        backgroundColor: color.hex,
        color: color.textHex,
      }}
      title={label || color.name}
    >
      {color.shape === 'circle' && (
        <svg viewBox="0 0 16 16" className="w-[56%] h-[56%]" fill="currentColor" aria-hidden="true">
          <circle cx="8" cy="8" r="5" />
        </svg>
      )}
      {color.shape === 'diamond' && (
        <svg viewBox="0 0 16 16" className="w-[58%] h-[58%]" fill="currentColor" aria-hidden="true">
          <polygon points="8,1.5 14.5,8 8,14.5 1.5,8" />
        </svg>
      )}
      {color.shape === 'triangle' && (
        <svg viewBox="0 0 16 16" className="w-[58%] h-[58%]" fill="currentColor" aria-hidden="true">
          <polygon points="8,2 14.5,13.5 1.5,13.5" />
        </svg>
      )}
      {color.shape === 'star' && (
        <svg viewBox="0 0 16 16" className="w-[62%] h-[62%]" fill="currentColor" aria-hidden="true">
          <polygon points="8,1.2 10,5.6 14.8,6.1 11.1,9.3 12.2,14 8,11.4 3.8,14 4.9,9.3 1.2,6.1 6,5.6" />
        </svg>
      )}
    </span>
  );
}
