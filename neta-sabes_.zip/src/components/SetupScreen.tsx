import { useState } from 'react';
import { ArrowLeft, Bot, Globe, Keyboard, ListChecks, Monitor, Play, User, Users } from 'lucide-react';
import { BOARD_IMAGE_PATH, PLAYER_COLORS } from '../data/board';
import { ANSWER_MODE_META, DIFFICULTY_META } from '../data/questions';
import { AnswerMode, DifficultyLevel, PlayerColorOption } from '../types/game';
import { LocalProfile } from '../utils/profilesStorage';
import { gameAudio } from '../utils/sound';
import { PlayerTokenIcon } from './PlayerTokenIcon';

export interface PlayerDraft {
  name: string;
  color: PlayerColorOption;
  profileId?: string;
  isBot?: boolean;
  botDifficulty?: DifficultyLevel;
}

interface SetupScreenProps {
  initialRoomCode?: string;
  savedProfiles: LocalProfile[];
  onBackToMenu: () => void;
  onStartLocalGame: (
    players: PlayerDraft[],
    difficulty: DifficultyLevel,
    answerMode: AnswerMode
  ) => void;
  onCreateOnlineRoom: (
    playerName: string,
    colorId: string,
    difficulty: DifficultyLevel,
    answerMode: AnswerMode,
    profileId?: string
  ) => void;
  onJoinOnlineRoom: (
    roomCode: string,
    playerName: string,
    colorId: string,
    profileId?: string
  ) => void;
  onlineConnecting: boolean;
  onlineError: string | null;
}

const DEFAULT_NAMES = ['Jugador 1', 'Jugador 2', 'Jugador 3', 'Jugador 4'];
const DEFAULT_BOT_NAMES = ['Bot Astro', 'Bot Nova', 'Bot Orión', 'Bot Vega'];

export function SetupScreen({
  initialRoomCode = '',
  savedProfiles,
  onBackToMenu,
  onStartLocalGame,
  onCreateOnlineRoom,
  onJoinOnlineRoom,
  onlineConnecting,
  onlineError,
}: SetupScreenProps) {
  const [playMode, setPlayMode] = useState<'online' | 'local'>('local');
  const [difficulty, setDifficulty] = useState<DifficultyLevel>('medium');
  const [answerMode, setAnswerMode] = useState<AnswerMode>('multiple_choice');

  const [playerCount, setPlayerCount] = useState<number>(2);
  const [drafts, setDrafts] = useState<PlayerDraft[]>([
    { name: DEFAULT_NAMES[0], color: PLAYER_COLORS[0], isBot: false, botDifficulty: 'medium' },
    { name: DEFAULT_NAMES[1], color: PLAYER_COLORS[1], isBot: false, botDifficulty: 'medium' },
    { name: DEFAULT_NAMES[2], color: PLAYER_COLORS[2], isBot: false, botDifficulty: 'medium' },
    { name: DEFAULT_NAMES[3], color: PLAYER_COLORS[3], isBot: false, botDifficulty: 'medium' },
  ]);

  const firstProf = savedProfiles[0];
  const [onlineName, setOnlineName] = useState<string>(firstProf?.username ?? '');
  const [onlineColor, setOnlineColor] = useState<PlayerColorOption>(
    (firstProf && PLAYER_COLORS.find((c) => c.id === firstProf.colorId)) ||
      PLAYER_COLORS[0]
  );
  const [onlineProfileId, setOnlineProfileId] = useState<string | undefined>(
    firstProf?.id
  );
  const [joinCode, setJoinCode] = useState<string>(initialRoomCode.toUpperCase());

  // Switch automatically to online tab if an invite URL parameter is present
  useState(() => {
    if (initialRoomCode.trim().length === 6) {
      setPlayMode('online');
    }
  });

  const handleNameChange = (idx: number, val: string) => {
    setDrafts((prev) =>
      prev.map((d, i) => (i === idx ? { ...d, name: val, profileId: undefined } : d))
    );
  };

  const handleToggleBot = (idx: number, nextIsBot: boolean) => {
    gameAudio.playClick();
    setDrafts((prev) =>
      prev.map((d, i) => {
        if (i !== idx) return d;
        const isDefaultHumanName = DEFAULT_NAMES.includes(d.name);
        const isDefaultBotName = DEFAULT_BOT_NAMES.includes(d.name);
        let nextName = d.name;
        if (nextIsBot && (isDefaultHumanName || !d.name.trim() || d.profileId)) {
          nextName = DEFAULT_BOT_NAMES[idx];
        } else if (!nextIsBot && (isDefaultBotName || !d.name.trim())) {
          nextName = DEFAULT_NAMES[idx];
        }
        return {
          ...d,
          isBot: nextIsBot,
          botDifficulty: d.botDifficulty ?? 'medium',
          profileId: nextIsBot ? undefined : d.profileId,
          name: nextName,
        };
      })
    );
  };

  const handleBotDifficultyChange = (idx: number, level: DifficultyLevel) => {
    gameAudio.playClick();
    setDrafts((prev) =>
      prev.map((d, i) => (i === idx ? { ...d, botDifficulty: level } : d))
    );
  };

  const handleColorPick = (playerIdx: number, chosen: PlayerColorOption) => {
    setDrafts((prev) => {
      const currentOwner = prev.findIndex((d) => d.color.id === chosen.id);
      const oldColor = prev[playerIdx].color;
      return prev.map((d, i) => {
        if (i === playerIdx) return { ...d, color: chosen };
        if (i === currentOwner) return { ...d, color: oldColor };
        return d;
      });
    });
  };

  const handleSelectProfileForLocal = (playerIdx: number, profId: string) => {
    if (!profId) {
      setDrafts((prev) =>
        prev.map((d, i) =>
          i === playerIdx
            ? { ...d, profileId: undefined, name: DEFAULT_NAMES[playerIdx] }
            : d
        )
      );
      return;
    }
    const prof = savedProfiles.find((p) => p.id === profId);
    if (!prof) return;
    const preferredColor =
      PLAYER_COLORS.find((c) => c.id === prof.colorId) ?? drafts[playerIdx].color;

    setDrafts((prev) => {
      const ownerOfColor = prev.findIndex((d) => d.color.id === preferredColor.id);
      const oldColor = prev[playerIdx].color;
      return prev.map((d, i) => {
        if (i === playerIdx) {
          return {
            name: prof.username,
            color: preferredColor,
            profileId: prof.id,
            isBot: false,
            botDifficulty: d.botDifficulty ?? 'medium',
          };
        }
        if (i === ownerOfColor) {
          return { ...d, color: oldColor };
        }
        return d;
      });
    });
  };

  const handleStartLocal = () => {
    gameAudio.playClick();
    const active = drafts.slice(0, playerCount).map((d, idx) => ({
      name: d.name.trim() || (d.isBot ? DEFAULT_BOT_NAMES[idx] : DEFAULT_NAMES[idx]),
      color: d.color,
      profileId: d.isBot ? undefined : d.profileId,
      isBot: Boolean(d.isBot),
      botDifficulty: d.isBot ? d.botDifficulty ?? 'medium' : undefined,
    }));
    onStartLocalGame(active, difficulty, answerMode);
  };

  return (
    <div className="relative z-10 min-h-screen flex items-center justify-center p-4 sm:p-6 lg:p-8">
      <div className="w-full max-w-5xl grid grid-cols-1 lg:grid-cols-12 gap-6 lg:gap-8 items-stretch">
        {/* Left: Board Preview & Back to Menu */}
        <div className="lg:col-span-5 bg-black border border-white/20 rounded-2xl p-5 sm:p-6 flex flex-col justify-between gap-5 shadow-[0_0_40px_rgba(255,255,255,0.05)]">
          <div>
            <button
              type="button"
              onClick={() => {
                gameAudio.playClick();
                onBackToMenu();
              }}
              className="font-display min-h-[38px] px-3.5 py-1.5 rounded-full bg-neutral-950 hover:bg-neutral-900 border border-white/20 hover:border-white/45 text-xs font-semibold text-neutral-200 hover:text-white inline-flex items-center gap-1.5 transition-all cursor-pointer whitespace-nowrap shrink-0 mb-4"
            >
              <ArrowLeft className="w-3.5 h-3.5 shrink-0" aria-hidden="true" />
              <span>Menú principal</span>
            </button>

            <div className="aspect-square w-full max-w-[260px] mx-auto rounded-xl overflow-hidden bg-black border border-white/20 shadow-[0_0_32px_rgba(255,255,255,0.06)]">
              <img
                src={BOARD_IMAGE_PATH}
                alt="Tablero oficial de Neta sabes?"
                referrerPolicy="no-referrer"
                className="w-full h-full object-contain"
              />
            </div>

            <h1 className="font-display text-3xl font-bold text-white mt-5 text-balance">
              Neta sabes?
            </h1>
            <p className="text-sm text-neutral-300 mt-2 leading-relaxed">
              Recorre el tablero en sentido horario desde <strong>SALIDA</strong>,
              responde preguntas en 30 segundos y supera las casillas{' '}
              <strong>EXTRA</strong>.
            </p>
          </div>

          <div className="border-t border-white/15 pt-4 text-xs text-neutral-400 space-y-1.5">
            <p>· Mezcla perfiles humanos y Bots IA (Fácil, Medio o Difícil) en local</p>
            <p>· Multijugador en línea con código de sala privado</p>
            <p>· Desbloquea logros y registra tu historial en tus perfiles</p>
          </div>
        </div>

        {/* Right: Mode + Difficulty + Setup */}
        <div className="lg:col-span-7 bg-black border border-white/20 rounded-2xl p-5 sm:p-7 flex flex-col justify-between shadow-[0_0_40px_rgba(255,255,255,0.05)]">
          <div>
            {/* Mode Switch */}
            <div className="flex flex-wrap items-center justify-between gap-3 border-b border-white/15 pb-4">
              <h2 className="font-display text-xl font-bold text-white flex items-center gap-2">
                <Users className="w-5 h-5 text-yellow-400 shrink-0" aria-hidden="true" />
                <span>Configurar partida</span>
              </h2>

              <div className="flex items-center gap-1 p-1 bg-neutral-950 border border-white/15 rounded-xl">
                <button
                  type="button"
                  onClick={() => {
                    gameAudio.playClick();
                    setPlayMode('local');
                  }}
                  className={`font-display px-3 py-1.5 rounded-lg text-xs font-bold inline-flex items-center gap-1.5 transition-all cursor-pointer whitespace-nowrap shrink-0 ${
                    playMode === 'local'
                      ? 'bg-yellow-400 text-black shadow-[0_0_16px_rgba(250,204,21,0.35)]'
                      : 'text-neutral-300 hover:text-white'
                  }`}
                >
                  <Monitor className="w-3.5 h-3.5 shrink-0" aria-hidden="true" />
                  <span>Local / Vs Bots</span>
                </button>
                <button
                  type="button"
                  onClick={() => {
                    gameAudio.playClick();
                    setPlayMode('online');
                  }}
                  className={`font-display px-3 py-1.5 rounded-lg text-xs font-bold inline-flex items-center gap-1.5 transition-all cursor-pointer whitespace-nowrap shrink-0 ${
                    playMode === 'online'
                      ? 'bg-yellow-400 text-black shadow-[0_0_16px_rgba(250,204,21,0.35)]'
                      : 'text-neutral-300 hover:text-white'
                  }`}
                >
                  <Globe className="w-3.5 h-3.5 shrink-0" aria-hidden="true" />
                  <span>En línea</span>
                </button>
              </div>
            </div>

            {/* Difficulty selector */}
            <div className="mt-4 rounded-xl bg-neutral-950 border border-purple-500/40 p-3.5">
              <div className="flex flex-wrap items-center justify-between gap-3">
                <div>
                  <p className="font-display text-xs font-bold text-white">
                    Dificultad de preguntas
                  </p>
                  <p className="text-xs text-neutral-400 mt-0.5">
                    {DIFFICULTY_META[difficulty].description}
                  </p>
                </div>

                <div className="flex items-center gap-1 p-1 bg-black border border-white/15 rounded-xl">
                  {(['easy', 'medium', 'hard'] as DifficultyLevel[]).map((lvl) => (
                    <button
                      key={lvl}
                      type="button"
                      onClick={() => {
                        gameAudio.playClick();
                        setDifficulty(lvl);
                      }}
                      className={`font-display px-3 py-1.5 rounded-lg text-xs font-bold transition-all cursor-pointer whitespace-nowrap shrink-0 ${
                        difficulty === lvl
                          ? 'bg-purple-500 text-white shadow-[0_0_14px_rgba(168,85,247,0.45)]'
                          : 'text-neutral-300 hover:text-white'
                      }`}
                    >
                      {DIFFICULTY_META[lvl].label}
                    </button>
                  ))}
                </div>
              </div>
            </div>

            {/* Answer mode selector */}
            <div className="mt-3 rounded-xl bg-neutral-950 border border-cyan-400/40 p-3.5">
              <div className="flex flex-wrap items-center justify-between gap-3">
                <div>
                  <p className="font-display text-xs font-bold text-white">
                    Modo de respuesta
                  </p>
                  <p className="text-xs text-neutral-400 mt-0.5">
                    {ANSWER_MODE_META[answerMode].description}
                  </p>
                </div>

                <div
                  className="flex items-center gap-1 p-1 bg-black border border-white/15 rounded-xl"
                  role="group"
                  aria-label="Modo de respuesta"
                >
                  <button
                    type="button"
                    onClick={() => {
                      gameAudio.playClick();
                      setAnswerMode('multiple_choice');
                    }}
                    className={`font-display px-3 py-1.5 rounded-lg text-xs font-bold inline-flex items-center gap-1.5 transition-all cursor-pointer whitespace-nowrap shrink-0 ${
                      answerMode === 'multiple_choice'
                        ? 'bg-cyan-400 text-black shadow-[0_0_14px_rgba(34,211,238,0.45)]'
                        : 'text-neutral-300 hover:text-white'
                    }`}
                  >
                    <ListChecks className="w-3.5 h-3.5 shrink-0" aria-hidden="true" />
                    <span>Opción múltiple</span>
                  </button>
                  <button
                    type="button"
                    onClick={() => {
                      gameAudio.playClick();
                      setAnswerMode('typed');
                    }}
                    className={`font-display px-3 py-1.5 rounded-lg text-xs font-bold inline-flex items-center gap-1.5 transition-all cursor-pointer whitespace-nowrap shrink-0 ${
                      answerMode === 'typed'
                        ? 'bg-cyan-400 text-black shadow-[0_0_14px_rgba(34,211,238,0.45)]'
                        : 'text-neutral-300 hover:text-white'
                    }`}
                  >
                    <Keyboard className="w-3.5 h-3.5 shrink-0" aria-hidden="true" />
                    <span>Escribir respuesta</span>
                  </button>
                </div>
              </div>
            </div>

            {playMode === 'online' ? (
              <div className="mt-5 space-y-4">
                <div className="bg-neutral-950 border border-white/15 rounded-xl p-4 space-y-3">
                  <div className="flex flex-wrap items-center justify-between gap-2">
                    <label
                      htmlFor="online-player-name"
                      className="font-display text-xs font-semibold text-neutral-300"
                    >
                      Tu nombre y ficha
                    </label>

                    {savedProfiles.length > 0 && (
                      <select
                        aria-label="Seleccionar perfil guardado"
                        value={onlineProfileId ?? ''}
                        onChange={(e) => {
                          const p = savedProfiles.find((sp) => sp.id === e.target.value);
                          if (p) {
                            setOnlineProfileId(p.id);
                            setOnlineName(p.username);
                            setOnlineColor(
                              PLAYER_COLORS.find((c) => c.id === p.colorId) ??
                                PLAYER_COLORS[0]
                            );
                          } else {
                            setOnlineProfileId(undefined);
                          }
                        }}
                        className="px-2.5 py-1 rounded-lg bg-black border border-white/20 text-xs text-neutral-200 focus:border-yellow-400 focus:outline-none"
                      >
                        <option value="">Nombre personalizado</option>
                        {savedProfiles.map((p) => (
                          <option key={p.id} value={p.id}>
                            Perfil: {p.username}
                          </option>
                        ))}
                      </select>
                    )}
                  </div>

                  <div className="flex flex-col sm:flex-row sm:items-center gap-3">
                    <div className="flex items-center gap-3 flex-1">
                      <PlayerTokenIcon color={onlineColor} size="md" />
                      <input
                        id="online-player-name"
                        type="text"
                        maxLength={18}
                        value={onlineName}
                        onChange={(e) => {
                          setOnlineName(e.target.value);
                          setOnlineProfileId(undefined);
                        }}
                        placeholder="Escribe tu nombre..."
                        className="w-full px-3.5 py-2.5 rounded-xl bg-black border border-white/20 focus:border-yellow-400 focus:outline-none text-sm font-medium text-white placeholder:text-neutral-500"
                      />
                    </div>
                    <div className="flex items-center gap-2 shrink-0">
                      {PLAYER_COLORS.map((c) => (
                        <button
                          key={c.id}
                          type="button"
                          onClick={() => setOnlineColor(c)}
                          aria-label={`Elegir color ${c.name}`}
                          className={`w-8 h-8 rounded-full transition-transform cursor-pointer ${
                            onlineColor.id === c.id
                              ? 'ring-2 ring-white scale-110'
                              : 'opacity-55 hover:opacity-100'
                          }`}
                          style={{ backgroundColor: c.hex }}
                        />
                      ))}
                    </div>
                  </div>
                </div>

                {onlineError && (
                  <p className="text-xs font-medium text-rose-300 bg-rose-950/60 border border-rose-500/50 rounded-xl px-3.5 py-2.5">
                    {onlineError}
                  </p>
                )}

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  <div className="rounded-xl bg-neutral-950 border border-yellow-400/40 p-4 flex flex-col justify-between gap-3">
                    <div>
                      <h3 className="font-display text-base font-bold text-white">
                        Crear sala privada
                      </h3>
                      <p className="text-xs text-neutral-400 mt-1">
                        Genera un código para invitar de 2 a 4 jugadores en tiempo real.
                      </p>
                    </div>
                    <button
                      type="button"
                      disabled={onlineConnecting}
                      onClick={() => {
                        gameAudio.playClick();
                        onCreateOnlineRoom(
                          onlineName.trim() || 'Anfitrión',
                          onlineColor.id,
                          difficulty,
                          answerMode,
                          onlineProfileId
                        );
                      }}
                      className="font-display w-full min-h-[44px] px-4 py-2.5 rounded-xl bg-yellow-400 hover:bg-yellow-300 hover:shadow-[0_0_22px_rgba(250,204,21,0.45)] disabled:bg-neutral-900 disabled:text-neutral-500 text-black font-bold text-sm transition-all cursor-pointer whitespace-nowrap shrink-0"
                    >
                      {onlineConnecting ? 'Conectando...' : 'Crear sala nueva'}
                    </button>
                  </div>

                  <div className="rounded-xl bg-neutral-950 border border-cyan-400/40 p-4 flex flex-col justify-between gap-3">
                    <div>
                      <h3 className="font-display text-base font-bold text-white">
                        Unirse con código
                      </h3>
                      <input
                        type="text"
                        maxLength={6}
                        value={joinCode}
                        onChange={(e) =>
                          setJoinCode(e.target.value.toUpperCase().replace(/[^A-Z0-9]/g, ''))
                        }
                        placeholder="Ej. K7P9QM"
                        aria-label="Código de sala"
                        className="mt-2 w-full px-3.5 py-2 rounded-xl bg-black border border-white/20 focus:border-cyan-400 focus:outline-none font-mono text-sm font-bold tracking-widest text-white uppercase placeholder:text-neutral-500 placeholder:tracking-normal placeholder:font-sans"
                      />
                    </div>
                    <button
                      type="button"
                      disabled={onlineConnecting || joinCode.trim().length !== 6}
                      onClick={() => {
                        gameAudio.playClick();
                        onJoinOnlineRoom(
                          joinCode.trim().toUpperCase(),
                          onlineName.trim() || 'Invitado',
                          onlineColor.id,
                          onlineProfileId
                        );
                      }}
                      className="font-display w-full min-h-[44px] px-4 py-2.5 rounded-xl bg-cyan-400 hover:bg-cyan-300 hover:shadow-[0_0_22px_rgba(34,211,238,0.45)] disabled:bg-neutral-900 disabled:text-neutral-600 text-black font-bold text-sm transition-all cursor-pointer disabled:cursor-not-allowed whitespace-nowrap shrink-0"
                    >
                      {onlineConnecting ? 'Conectando...' : 'Entrar a la sala'}
                    </button>
                  </div>
                </div>
              </div>
            ) : (
              <>
                <div className="mt-4 flex flex-wrap items-center justify-between gap-3">
                  <span className="text-xs text-neutral-400">
                    Combina jugadores humanos y Bots IA (2 a 4 fichas)
                  </span>
                  <div className="flex items-center gap-1 p-1 bg-neutral-950 border border-white/15 rounded-xl">
                    {[2, 3, 4].map((count) => (
                      <button
                        key={count}
                        type="button"
                        onClick={() => {
                          gameAudio.playClick();
                          setPlayerCount(count);
                        }}
                        className={`font-display px-3 py-1 rounded-lg text-xs font-bold transition-all cursor-pointer whitespace-nowrap shrink-0 ${
                          playerCount === count
                            ? 'bg-white text-black'
                            : 'text-neutral-300 hover:text-white'
                        }`}
                      >
                        {count} jugadores
                      </button>
                    ))}
                  </div>
                </div>

                <div className="mt-3.5 space-y-2.5">
                  {drafts.slice(0, playerCount).map((draft, idx) => {
                    const isBot = Boolean(draft.isBot);
                    const botLvl = draft.botDifficulty ?? 'medium';

                    return (
                      <div
                        key={idx}
                        style={{ borderColor: `${draft.color.hex}66` }}
                        className="bg-neutral-950 border rounded-xl p-3 flex flex-col gap-2.5"
                      >
                        <div className="flex flex-wrap items-center justify-between gap-2">
                          <div className="flex items-center gap-2">
                            <span className="text-[11px] font-medium text-neutral-400">
                              Ficha {idx + 1} · {draft.color.name}
                            </span>

                            {/* Human vs AI Bot Toggle */}
                            <div className="flex items-center gap-0.5 p-0.5 bg-black border border-white/15 rounded-lg">
                              <button
                                type="button"
                                onClick={() => handleToggleBot(idx, false)}
                                className={`font-display px-2 py-0.5 rounded-md text-[11px] font-bold inline-flex items-center gap-1 transition-all cursor-pointer whitespace-nowrap ${
                                  !isBot
                                    ? 'bg-white text-black'
                                    : 'text-neutral-400 hover:text-white'
                                }`}
                              >
                                <User className="w-3 h-3 shrink-0" aria-hidden="true" />
                                <span>Humano</span>
                              </button>
                              <button
                                type="button"
                                onClick={() => handleToggleBot(idx, true)}
                                className={`font-display px-2 py-0.5 rounded-md text-[11px] font-bold inline-flex items-center gap-1 transition-all cursor-pointer whitespace-nowrap ${
                                  isBot
                                    ? 'bg-cyan-400 text-black shadow-[0_0_12px_rgba(34,211,238,0.4)]'
                                    : 'text-neutral-400 hover:text-white'
                                }`}
                              >
                                <Bot className="w-3 h-3 shrink-0" aria-hidden="true" />
                                <span>Bot IA</span>
                              </button>
                            </div>
                          </div>

                          {isBot ? (
                            <div
                              className="flex items-center gap-1 p-0.5 bg-black border border-cyan-400/35 rounded-lg"
                              role="group"
                              aria-label={`Dificultad del Bot ${idx + 1}`}
                            >
                              {(['easy', 'medium', 'hard'] as DifficultyLevel[]).map((lvl) => (
                                <button
                                  key={lvl}
                                  type="button"
                                  onClick={() => handleBotDifficultyChange(idx, lvl)}
                                  className={`font-display px-2 py-0.5 rounded-md text-[11px] font-bold transition-all cursor-pointer whitespace-nowrap ${
                                    botLvl === lvl
                                      ? 'bg-cyan-400 text-black'
                                      : 'text-neutral-400 hover:text-white'
                                  }`}
                                >
                                  {DIFFICULTY_META[lvl].label}
                                </button>
                              ))}
                            </div>
                          ) : (
                            savedProfiles.length > 0 && (
                              <select
                                aria-label={`Perfil para ficha ${idx + 1}`}
                                value={draft.profileId ?? ''}
                                onChange={(e) =>
                                  handleSelectProfileForLocal(idx, e.target.value)
                                }
                                className="px-2 py-0.5 rounded bg-black border border-white/20 text-[11px] text-neutral-200 focus:border-yellow-400 focus:outline-none"
                              >
                                <option value="">Personalizado</option>
                                {savedProfiles.map((p) => (
                                  <option key={p.id} value={p.id}>
                                    {p.username}
                                  </option>
                                ))}
                              </select>
                            )
                          )}
                        </div>

                        <div className="flex flex-col sm:flex-row sm:items-center gap-3">
                          <div className="flex items-center gap-3 flex-1 min-w-0">
                            <PlayerTokenIcon color={draft.color} size="md" />
                            <input
                              id={`player-name-${idx}`}
                              type="text"
                              maxLength={18}
                              value={draft.name}
                              aria-label={`Nombre de ficha ${idx + 1}`}
                              onChange={(e) => handleNameChange(idx, e.target.value)}
                              placeholder={isBot ? DEFAULT_BOT_NAMES[idx] : DEFAULT_NAMES[idx]}
                              className="w-full px-3 py-1.5 rounded-lg bg-black border border-white/20 focus:border-yellow-400 focus:outline-none text-sm font-medium text-white placeholder:text-neutral-500"
                            />
                          </div>

                          <div className="flex items-center gap-2 shrink-0 sm:pl-2">
                            {PLAYER_COLORS.map((colorOpt) => {
                              const selected = draft.color.id === colorOpt.id;
                              return (
                                <button
                                  key={colorOpt.id}
                                  type="button"
                                  onClick={() => handleColorPick(idx, colorOpt)}
                                  aria-label={`Elegir color ${colorOpt.name} para ficha ${idx + 1}`}
                                  className={`w-7 h-7 rounded-full flex items-center justify-center transition-transform cursor-pointer ${
                                    selected
                                      ? 'ring-2 ring-white scale-110'
                                      : 'opacity-55 hover:opacity-100'
                                  }`}
                                  style={{ backgroundColor: colorOpt.hex }}
                                />
                              );
                            })}
                          </div>
                        </div>
                      </div>
                    );
                  })}
                </div>

                <button
                  type="button"
                  onClick={handleStartLocal}
                  className="font-display mt-5 w-full min-h-[48px] px-6 py-3 rounded-xl bg-yellow-400 hover:bg-yellow-300 hover:shadow-[0_0_26px_rgba(250,204,21,0.45)] text-black font-bold text-base inline-flex items-center justify-center gap-2 transition-all cursor-pointer whitespace-nowrap shrink-0"
                >
                  <Play className="w-5 h-5 fill-current shrink-0" aria-hidden="true" />
                  <span>Comenzar partida local</span>
                </button>
              </>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}
