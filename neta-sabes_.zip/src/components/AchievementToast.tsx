import { Award, Cpu, Flag, Flame, Sparkles, Swords, Trophy } from 'lucide-react';
import { AnimatePresence, motion } from 'motion/react';
import { AchievementDef } from '../data/achievements';

export interface AchievementToastItem {
  key: string;
  achievement: AchievementDef;
  playerName: string;
}

interface AchievementToastProps {
  current: AchievementToastItem | null;
}

export function AchievementGlyph({
  icon,
  className = 'w-5 h-5',
}: {
  icon: AchievementDef['icon'];
  className?: string;
}) {
  const props = { className, 'aria-hidden': true as const };
  switch (icon) {
    case 'trophy':
      return <Trophy {...props} />;
    case 'flame':
      return <Flame {...props} />;
    case 'cpu':
      return <Cpu {...props} />;
    case 'flag':
      return <Flag {...props} />;
    case 'sparkles':
      return <Sparkles {...props} />;
    case 'swords':
      return <Swords {...props} />;
    case 'award':
      return <Award {...props} />;
  }
}

export function AchievementToast({ current }: AchievementToastProps) {
  return (
    <div
      className="fixed bottom-5 left-1/2 -translate-x-1/2 z-[70] pointer-events-none w-[calc(100%-2rem)] max-w-md flex justify-center"
      aria-live="polite"
      aria-atomic="true"
    >
      <AnimatePresence mode="wait">
        {current && (
          <motion.div
            key={current.key}
            initial={{ opacity: 0, y: 28, scale: 0.92 }}
            animate={{ opacity: 1, y: 0, scale: 1 }}
            exit={{ opacity: 0, y: 18, scale: 0.94 }}
            transition={{ duration: 0.32, ease: [0.16, 1, 0.3, 1] }}
            style={{
              borderColor: current.achievement.accentHex,
              boxShadow: `0 0 32px ${current.achievement.accentHex}55, 0 18px 44px rgba(0,0,0,0.95)`,
            }}
            className="relative flex items-center gap-3.5 px-4 py-2.5 pr-6 rounded-full bg-black border-2 text-white max-w-full overflow-hidden"
          >
            {/* Glowing circular Xbox-style achievement emblem */}
            <motion.div
              initial={{ scale: 0.6, rotate: -25 }}
              animate={{ scale: 1, rotate: 0 }}
              transition={{ delay: 0.08, type: 'spring', stiffness: 320, damping: 18 }}
              style={{
                backgroundColor: current.achievement.accentHex,
                boxShadow: `0 0 18px ${current.achievement.accentHex}88`,
              }}
              className="w-11 h-11 rounded-full flex items-center justify-center text-black shrink-0"
            >
              <AchievementGlyph icon={current.achievement.icon} className="w-5 h-5" />
            </motion.div>

            {/* Text Content */}
            <div className="min-w-0 flex-1 pr-2">
              <div className="flex items-center gap-1.5 text-[10px] font-bold uppercase tracking-wider">
                <span style={{ color: current.achievement.accentHex }}>
                  Logro desbloqueado
                </span>
                <span className="text-neutral-500" aria-hidden="true">
                  ·
                </span>
                <span className="text-neutral-300 truncate">{current.playerName}</span>
              </div>
              <p className="font-display text-sm sm:text-base font-bold text-white leading-tight truncate">
                {current.achievement.title}
              </p>
              <p className="text-[11px] text-neutral-300 truncate">
                {current.achievement.description}
              </p>
            </div>

            {/* Subtle 4-point sparkle accent */}
            <svg
              viewBox="0 0 24 24"
              className="w-3.5 h-3.5 shrink-0 opacity-75"
              style={{ color: current.achievement.accentHex }}
              fill="currentColor"
              aria-hidden="true"
            >
              <path d="M12 0 L14.8 9.2 L24 12 L14.8 14.8 L12 24 L9.2 14.8 L0 12 L9.2 9.2 Z" />
            </svg>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}
