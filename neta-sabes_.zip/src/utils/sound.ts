class GameAudio {
  private ctx: AudioContext | null = null;
  public muted = false;

  private getContext(): AudioContext | null {
    if (this.muted || typeof window === 'undefined') return null;
    if (!this.ctx) {
      const AudioCtx =
        window.AudioContext ||
        (window as unknown as { webkitAudioContext: typeof AudioContext }).webkitAudioContext;
      if (AudioCtx) {
        this.ctx = new AudioCtx();
      }
    }
    if (this.ctx && this.ctx.state === 'suspended') {
      this.ctx.resume().catch(() => {});
    }
    return this.ctx;
  }

  private playTone(
    freq: number,
    duration: number,
    type: OscillatorType = 'sine',
    volume = 0.08,
    delay = 0
  ) {
    const ctx = this.getContext();
    if (!ctx) return;

    const now = ctx.currentTime + delay;
    const osc = ctx.createOscillator();
    const gain = ctx.createGain();

    osc.type = type;
    osc.frequency.setValueAtTime(freq, now);

    gain.gain.setValueAtTime(0.0001, now);
    gain.gain.exponentialRampToValueAtTime(volume, now + 0.012);
    gain.gain.exponentialRampToValueAtTime(0.0001, now + duration);

    osc.connect(gain);
    gain.connect(ctx.destination);

    osc.start(now);
    osc.stop(now + duration + 0.02);
  }

  playClick() {
    this.playTone(620, 0.045, 'sine', 0.045);
  }

  playCardFlip() {
    this.playTone(360, 0.08, 'sine', 0.05, 0);
    this.playTone(540, 0.1, 'triangle', 0.05, 0.045);
  }

  playDiceRoll() {
    [220, 290, 360, 250, 420, 310].forEach((freq, i) => {
      this.playTone(freq, 0.055, 'triangle', 0.055, i * 0.055);
    });
  }

  playStep() {
    this.playTone(520, 0.06, 'sine', 0.055);
  }

  playTimerTick(urgent = false) {
    this.playTone(urgent ? 880 : 700, 0.04, 'square', urgent ? 0.03 : 0.02);
  }

  playCorrect() {
    this.playTone(523.25, 0.14, 'triangle', 0.09, 0);
    this.playTone(659.25, 0.14, 'triangle', 0.09, 0.08);
    this.playTone(783.99, 0.24, 'triangle', 0.1, 0.16);
  }

  playWrong() {
    this.playTone(240, 0.18, 'sawtooth', 0.045, 0);
    this.playTone(185, 0.28, 'sawtooth', 0.045, 0.14);
  }

  playExtraCard() {
    this.playTone(440, 0.12, 'sine', 0.07, 0);
    this.playTone(587.33, 0.16, 'sine', 0.08, 0.08);
  }

  playVictory() {
    const notes = [523.25, 659.25, 783.99, 1046.5];
    notes.forEach((n, idx) => {
      this.playTone(n, 0.3, 'triangle', 0.09, idx * 0.11);
    });
  }

  playAchievement() {
    // Sleek ascending harmonic chime inspired by classic console achievement popups
    this.playTone(587.33, 0.16, 'sine', 0.08, 0); // D5
    this.playTone(880, 0.18, 'sine', 0.075, 0.09); // A5
    this.playTone(1174.66, 0.34, 'triangle', 0.09, 0.18); // D6
    this.playTone(1760, 0.28, 'sine', 0.045, 0.24); // A6 shimmer
  }
}

export const gameAudio = new GameAudio();
