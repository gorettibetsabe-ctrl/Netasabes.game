export type AchievementId =
  | 'first_win'
  | 'streak_3'
  | 'beat_hard_bot'
  | 'complete_lap'
  | 'high_scorer'
  | 'tiebreaker_champ'
  | 'veteran_5';

export interface AchievementDef {
  id: AchievementId;
  title: string;
  description: string;
  accentHex: string;
  icon: 'trophy' | 'flame' | 'cpu' | 'flag' | 'sparkles' | 'swords' | 'award';
}

export const ACHIEVEMENTS: AchievementDef[] = [
  {
    id: 'first_win',
    title: 'Primera Victoria',
    description: 'Gana tu primera partida en Neta sabes?',
    accentHex: '#FACC15',
    icon: 'trophy',
  },
  {
    id: 'streak_3',
    title: 'Racha de 3',
    description: 'Responde 3 preguntas seguidas correctamente.',
    accentHex: '#F97316',
    icon: 'flame',
  },
  {
    id: 'beat_hard_bot',
    title: 'Cazador de IA',
    description: 'Gana una partida enfrentando a un Bot Difícil.',
    accentHex: '#22D3EE',
    icon: 'cpu',
  },
  {
    id: 'complete_lap',
    title: 'Vuelta Completa',
    description: 'Recorre todo el tablero y llega o pasa por SALIDA.',
    accentHex: '#34D399',
    icon: 'flag',
  },
  {
    id: 'high_scorer',
    title: 'Mente Brillante',
    description: 'Alcanza 6 o más puntos en una sola partida.',
    accentHex: '#A855F7',
    icon: 'sparkles',
  },
  {
    id: 'tiebreaker_champ',
    title: 'Nervios de Acero',
    description: 'Gana una partida en ronda de desempate.',
    accentHex: '#EC4899',
    icon: 'swords',
  },
  {
    id: 'veteran_5',
    title: 'Jugador Frecuente',
    description: 'Completa 5 partidas con tu perfil guardado.',
    accentHex: '#EF4444',
    icon: 'award',
  },
];

export function getAchievementById(id: string): AchievementDef | undefined {
  return ACHIEVEMENTS.find((a) => a.id === id);
}
