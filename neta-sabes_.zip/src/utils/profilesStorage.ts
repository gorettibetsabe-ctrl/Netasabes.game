import type { AchievementId } from '../data/achievements';
import type { DifficultyLevel, Player } from '../types/game';

export interface LocalProfile {
  id: string;
  username: string;
  colorId: string;
  createdAt: string;
  matchesPlayed: number;
  wins: number;
  totalPoints: number;
  totalCorrect: number;
  totalQuestions: number;
  achievements?: Record<string, string>; // AchievementId -> ISO date unlocked
}

export interface MatchPlayerSummary {
  profileId?: string;
  name: string;
  colorId: string;
  score: number;
  placement: number;
  isWinner: boolean;
  isBot?: boolean;
  botDifficulty?: DifficultyLevel;
}

export interface MatchRecord {
  id: string;
  date: string;
  mode: 'local' | 'online';
  difficulty: DifficultyLevel;
  winnerName: string;
  wonByTiebreaker: boolean;
  players: MatchPlayerSummary[];
}

const PROFILES_KEY = 'netasabes_profiles_v1';
const HISTORY_KEY = 'netasabes_match_history_v1';

export function loadProfiles(): LocalProfile[] {
  if (typeof window === 'undefined') return [];
  try {
    const raw = window.localStorage.getItem(PROFILES_KEY);
    if (!raw) return [];
    const parsed = JSON.parse(raw);
    return Array.isArray(parsed) ? parsed : [];
  } catch {
    return [];
  }
}

export function saveProfiles(profiles: LocalProfile[]): void {
  if (typeof window === 'undefined') return;
  try {
    window.localStorage.setItem(PROFILES_KEY, JSON.stringify(profiles));
  } catch {
    // ignore storage quota errors
  }
}

export function createProfile(username: string, colorId: string): LocalProfile {
  const cleanName = username.replace(/\s+/g, ' ').trim().slice(0, 18) || 'Jugador';
  const profiles = loadProfiles();
  const profile: LocalProfile = {
    id: `prof-${Date.now()}-${Math.random().toString(36).slice(2, 7)}`,
    username: cleanName,
    colorId,
    createdAt: new Date().toISOString(),
    matchesPlayed: 0,
    wins: 0,
    totalPoints: 0,
    totalCorrect: 0,
    totalQuestions: 0,
    achievements: {},
  };
  saveProfiles([profile, ...profiles]);
  return profile;
}

export function updateProfile(
  profileId: string,
  username: string,
  colorId: string
): LocalProfile[] {
  const cleanName = username.replace(/\s+/g, ' ').trim().slice(0, 18) || 'Jugador';
  const next = loadProfiles().map((p) =>
    p.id === profileId ? { ...p, username: cleanName, colorId } : p
  );
  saveProfiles(next);
  return next;
}

export function deleteProfile(profileId: string): LocalProfile[] {
  const next = loadProfiles().filter((p) => p.id !== profileId);
  saveProfiles(next);
  return next;
}

export function unlockProfileAchievement(
  profileId: string,
  achievementId: AchievementId
): { unlockedNow: boolean; profiles: LocalProfile[] } {
  const profiles = loadProfiles();
  let unlockedNow = false;
  const nowIso = new Date().toISOString();

  const next = profiles.map((prof) => {
    if (prof.id !== profileId) return prof;
    const currentMap = prof.achievements ?? {};
    if (currentMap[achievementId]) return prof;
    unlockedNow = true;
    return {
      ...prof,
      achievements: {
        ...currentMap,
        [achievementId]: nowIso,
      },
    };
  });

  if (unlockedNow) {
    saveProfiles(next);
  }
  return { unlockedNow, profiles: next };
}

export function loadMatchHistory(): MatchRecord[] {
  if (typeof window === 'undefined') return [];
  try {
    const raw = window.localStorage.getItem(HISTORY_KEY);
    if (!raw) return [];
    const parsed = JSON.parse(raw);
    return Array.isArray(parsed) ? parsed : [];
  } catch {
    return [];
  }
}

export function clearMatchHistory(): void {
  if (typeof window === 'undefined') return;
  try {
    window.localStorage.removeItem(HISTORY_KEY);
  } catch {
    // ignore
  }
}

export function recordCompletedMatch(params: {
  players: Player[];
  winnerId: number;
  wonByTiebreaker: boolean;
  mode: 'local' | 'online';
  difficulty: DifficultyLevel;
  profileBindings?: Record<number, string>; // player.id -> LocalProfile.id
}): { record: MatchRecord; newlyUnlockedVeteranIds: string[] } {
  const { players, winnerId, wonByTiebreaker, mode, difficulty, profileBindings } = params;
  const sorted = [...players].sort((a, b) => {
    if (a.id === winnerId) return -1;
    if (b.id === winnerId) return 1;
    return b.score - a.score;
  });

  const winner = sorted[0];
  const summaries: MatchPlayerSummary[] = sorted.map((p, idx) => ({
    profileId: p.isBot ? undefined : profileBindings?.[p.id],
    name: p.name,
    colorId: p.color.id,
    score: p.score,
    placement: idx + 1,
    isWinner: p.id === winnerId,
    isBot: p.isBot,
    botDifficulty: p.botDifficulty,
  }));

  const record: MatchRecord = {
    id: `match-${Date.now()}-${Math.random().toString(36).slice(2, 6)}`,
    date: new Date().toISOString(),
    mode,
    difficulty,
    winnerName: winner?.name ?? 'Jugador',
    wonByTiebreaker,
    players: summaries,
  };

  // Save match history (keep latest 40 matches)
  const history = loadMatchHistory();
  try {
    window.localStorage.setItem(
      HISTORY_KEY,
      JSON.stringify([record, ...history].slice(0, 40))
    );
  } catch {
    // ignore storage quota errors
  }

  const newlyUnlockedVeteranIds: string[] = [];

  // Update stats for linked local human profiles (never bots)
  const profiles = loadProfiles();
  if (profiles.length > 0) {
    const nowIso = new Date().toISOString();
    const updatedProfiles = profiles.map((prof) => {
      const boundPlayer = sorted.find(
        (p) =>
          !p.isBot &&
          (profileBindings?.[p.id] === prof.id ||
            (!profileBindings?.[p.id] &&
              p.name.trim().toLowerCase() === prof.username.trim().toLowerCase()))
      );
      if (!boundPlayer) return prof;

      const nextMatchesPlayed = prof.matchesPlayed + 1;
      const existingAch = prof.achievements ?? {};
      let nextAch = existingAch;
      if (nextMatchesPlayed >= 5 && !existingAch.veteran_5) {
        nextAch = { ...existingAch, veteran_5: nowIso };
        newlyUnlockedVeteranIds.push(prof.id);
      }

      return {
        ...prof,
        matchesPlayed: nextMatchesPlayed,
        wins: prof.wins + (boundPlayer.id === winnerId ? 1 : 0),
        totalPoints: prof.totalPoints + boundPlayer.score,
        totalCorrect: prof.totalCorrect + boundPlayer.correctAnswers,
        totalQuestions: prof.totalQuestions + boundPlayer.questionsAnswered,
        achievements: nextAch,
      };
    });
    saveProfiles(updatedProfiles);
  }

  return { record, newlyUnlockedVeteranIds };
}
