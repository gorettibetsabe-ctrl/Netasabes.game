import { FormEvent, useCallback, useEffect, useMemo, useRef, useState } from 'react';
import {
  BookOpen,
  Bot,
  Calculator,
  CheckCircle2,
  Clock,
  Feather,
  FlaskConical,
  Globe,
  Palette,
  Shield,
  XCircle,
} from 'lucide-react';
import { motion } from 'motion/react';
import { CATEGORY_META } from '../data/board';
import {
  buildQuestionOptions,
  DIFFICULTY_META,
  isAnswerCorrect,
  normalizeAnswer,
  QUESTIONS_BANK,
} from '../data/questions';
import {
  AnswerMode,
  CategoryId,
  DifficultyLevel,
  Player,
  PublicQuestionPayload,
  QuestionResolution,
  TriviaQuestion,
} from '../types/game';
import { gameAudio } from '../utils/sound';
import { ConfettiBurst } from './ConfettiBurst';
import { PlayerTokenIcon } from './PlayerTokenIcon';

interface QuestionModalProps {
  question: TriviaQuestion | PublicQuestionPayload;
  player: Player;
  answerMode?: AnswerMode;
  isTiebreaker?: boolean;
  tiebreakerRound?: number;
  onComplete?: (correct: boolean, timedOut: boolean) => void;
  onlineMode?: boolean;
  isMyTurn?: boolean;
  deadlineAt?: number | null;
  serverResolution?: QuestionResolution | null;
  onSubmitOnline?: (answer: string) => void;
  onContinueOnline?: () => void;
}

const TOTAL_SECONDS = 30;
const OPTION_LETTERS = ['A', 'B', 'C', 'D'] as const;

function getBotAccuracy(botLevel: DifficultyLevel, questionLevel: DifficultyLevel): number {
  const matrix: Record<DifficultyLevel, Record<DifficultyLevel, number>> = {
    easy: { easy: 0.5, medium: 0.4, hard: 0.3 },
    medium: { easy: 0.78, medium: 0.68, hard: 0.52 },
    hard: { easy: 0.94, medium: 0.88, hard: 0.8 },
  };
  return matrix[botLevel][questionLevel];
}

function pickBotWrongAnswer(question: TriviaQuestion): string {
  const sameCategoryOthers = QUESTIONS_BANK.filter(
    (q) =>
      q.category === question.category &&
      q.id !== question.id &&
      q.displayAnswer.toLowerCase() !== question.displayAnswer.toLowerCase()
  );
  if (sameCategoryOthers.length > 0) {
    const pick =
      sameCategoryOthers[Math.floor(Math.random() * sameCategoryOthers.length)];
    return pick.displayAnswer;
  }
  return 'No estoy seguro';
}

function CategoryIcon({ category }: { category: CategoryId }) {
  const props = { className: 'w-5 h-5 shrink-0', 'aria-hidden': true as const };
  switch (category) {
    case 'historia':
      return <Shield {...props} />;
    case 'matematicas':
      return <Calculator {...props} />;
    case 'filosofia':
      return <Feather {...props} />;
    case 'ciencias':
      return <FlaskConical {...props} />;
    case 'arte':
      return <Palette {...props} />;
    case 'cultura_general':
      return <BookOpen {...props} />;
    case 'geografia':
      return <Globe {...props} />;
  }
}

export function QuestionModal({
  question,
  player,
  answerMode = 'multiple_choice',
  isTiebreaker = false,
  tiebreakerRound = 1,
  onComplete,
  onlineMode = false,
  isMyTurn = true,
  deadlineAt = null,
  serverResolution = null,
  onSubmitOnline,
  onContinueOnline,
}: QuestionModalProps) {
  const [answer, setAnswer] = useState('');
  const [selectedOption, setSelectedOption] = useState<string | null>(null);
  const [localSecondsLeft, setLocalSecondsLeft] = useState(TOTAL_SECONDS);
  const [localResult, setLocalResult] = useState<'pending' | 'correct' | 'wrong' | 'timeout'>(
    'pending'
  );
  const [onlineSecondsLeft, setOnlineSecondsLeft] = useState(TOTAL_SECONDS);
  const inputRef = useRef<HTMLInputElement>(null);
  const lastSoundResolutionRef = useRef<string | null>(null);
  const completedRef = useRef<boolean>(false);

  const mcOptions = useMemo(() => {
    if (answerMode !== 'multiple_choice') return [];
    if (onlineMode) {
      return (question as PublicQuestionPayload).options ?? [];
    }
    return buildQuestionOptions(question as TriviaQuestion);
  }, [answerMode, onlineMode, question]);

  const isMultipleChoice = answerMode === 'multiple_choice' && mcOptions.length >= 2;
  const isLocalBotTurn = !onlineMode && Boolean(player.isBot);
  const meta = CATEGORY_META[question.category];
  const diffLabel = DIFFICULTY_META[question.difficulty].label;

  const fireCompleteOnce = useCallback(
    (correct: boolean, timedOut: boolean) => {
      if (completedRef.current) return;
      completedRef.current = true;
      onComplete?.(correct, timedOut);
    },
    [onComplete]
  );

  useEffect(() => {
    setAnswer('');
    setSelectedOption(null);
    setLocalSecondsLeft(TOTAL_SECONDS);
    setLocalResult('pending');
    completedRef.current = false;
    gameAudio.playCardFlip();
    if (!isMultipleChoice && (!onlineMode || isMyTurn) && !player.isBot) {
      const t = window.setTimeout(() => inputRef.current?.focus(), 220);
      return () => window.clearTimeout(t);
    }
  }, [question.id, onlineMode, isMyTurn, player.isBot, isMultipleChoice]);

  // Countdown timer for local turns
  useEffect(() => {
    if (onlineMode || localResult !== 'pending') return;

    const timer = window.setInterval(() => {
      setLocalSecondsLeft((prev) => {
        if (prev <= 1) {
          window.clearInterval(timer);
          setLocalResult('timeout');
          gameAudio.playWrong();
          return 0;
        }
        const next = prev - 1;
        if (next <= 10) {
          gameAudio.playTimerTick(next <= 5);
        }
        return next;
      });
    }, 1000);

    return () => window.clearInterval(timer);
  }, [onlineMode, localResult]);

  // Automated thinking & answering for AI Bots
  useEffect(() => {
    if (!isLocalBotTurn || localResult !== 'pending') return;

    const botLevel = player.botDifficulty ?? 'medium';
    const baseDelay =
      botLevel === 'hard' ? 1150 : botLevel === 'medium' ? 1500 : 1850;
    const thinkMs = baseDelay + Math.floor(Math.random() * 800);

    const t = window.setTimeout(() => {
      const fullQ = question as TriviaQuestion;
      const accuracy = getBotAccuracy(botLevel, fullQ.difficulty);
      const willAnswerRight = Math.random() < accuracy;

      if (willAnswerRight) {
        const chosen = isMultipleChoice
          ? mcOptions.find((opt) => isAnswerCorrect(opt, fullQ)) ?? fullQ.displayAnswer
          : fullQ.displayAnswer;
        setSelectedOption(chosen);
        setAnswer(chosen);
        setLocalResult('correct');
        gameAudio.playCorrect();
      } else {
        let chosen: string;
        if (isMultipleChoice) {
          const wrongPool = mcOptions.filter((opt) => !isAnswerCorrect(opt, fullQ));
          chosen =
            wrongPool.length > 0
              ? wrongPool[Math.floor(Math.random() * wrongPool.length)]
              : pickBotWrongAnswer(fullQ);
        } else {
          chosen = pickBotWrongAnswer(fullQ);
        }
        setSelectedOption(chosen);
        setAnswer(chosen);
        setLocalResult('wrong');
        gameAudio.playWrong();
      }
    }, thinkMs);

    return () => window.clearTimeout(t);
  }, [isLocalBotTurn, localResult, player.botDifficulty, question, isMultipleChoice, mcOptions]);

  // Auto-continue after showing AI Bot result briefly
  useEffect(() => {
    if (!isLocalBotTurn || localResult === 'pending') return;
    const t = window.setTimeout(() => {
      fireCompleteOnce(localResult === 'correct', localResult === 'timeout');
    }, 1700);
    return () => window.clearTimeout(t);
  }, [isLocalBotTurn, localResult, fireCompleteOnce]);

  useEffect(() => {
    if (!onlineMode || !deadlineAt || serverResolution) return;

    const updateRemaining = () => {
      const ms = Math.max(0, deadlineAt - Date.now());
      const secs = Math.ceil(ms / 1000);
      setOnlineSecondsLeft((prev) => {
        if (secs !== prev && secs <= 10 && secs > 0) {
          gameAudio.playTimerTick(secs <= 5);
        }
        return secs;
      });
    };

    updateRemaining();
    const interval = window.setInterval(updateRemaining, 250);
    return () => window.clearInterval(interval);
  }, [onlineMode, deadlineAt, serverResolution]);

  useEffect(() => {
    if (!onlineMode || !serverResolution) return;
    const key = `${question.id}-${serverResolution.playerId}`;
    if (lastSoundResolutionRef.current === key) return;
    lastSoundResolutionRef.current = key;

    if (serverResolution.correct) {
      gameAudio.playCorrect();
    } else {
      gameAudio.playWrong();
    }
  }, [onlineMode, serverResolution, question.id]);

  const submitAnswerValue = (rawValue: string) => {
    if (isLocalBotTurn || !rawValue.trim()) return;
    gameAudio.playClick();
    setSelectedOption(rawValue);
    setAnswer(rawValue);

    if (onlineMode) {
      if (!isMyTurn || serverResolution) return;
      onSubmitOnline?.(rawValue);
      return;
    }

    if (localResult !== 'pending') return;
    const fullQ = question as TriviaQuestion;
    const ok = isAnswerCorrect(rawValue, fullQ);
    if (ok) {
      setLocalResult('correct');
      gameAudio.playCorrect();
    } else {
      setLocalResult('wrong');
      gameAudio.playWrong();
    }
  };

  const handleSubmit = (e: FormEvent) => {
    e.preventDefault();
    submitAnswerValue(answer);
  };

  const secondsLeft = onlineMode ? (serverResolution ? 0 : onlineSecondsLeft) : localSecondsLeft;
  const resolvedState = onlineMode
    ? serverResolution
      ? serverResolution.correct
        ? 'correct'
        : serverResolution.timedOut
          ? 'timeout'
          : 'wrong'
      : 'pending'
    : localResult;

  const displayAnswer = onlineMode
    ? serverResolution?.displayAnswer ?? ''
    : (question as TriviaQuestion).displayAnswer;
  const submittedText = onlineMode
    ? serverResolution?.submittedAnswer ?? ''
    : (selectedOption ?? answer).trim();

  const progressPct = Math.max(0, Math.min(100, (secondsLeft / TOTAL_SECONDS) * 100));
  const isWarning = secondsLeft <= 10 && secondsLeft > 5 && resolvedState === 'pending';
  const isCritical = secondsLeft <= 5 && resolvedState === 'pending';

  const canHumanInteract =
    resolvedState === 'pending' && !isLocalBotTurn && (!onlineMode || isMyTurn);

  return (
    <div
      className="fixed inset-0 z-50 bg-black/85 backdrop-blur-sm flex items-center justify-center p-4"
      role="dialog"
      aria-modal="true"
      aria-labelledby="question-title"
      style={{ perspective: '1200px' }}
    >
      <ConfettiBurst active={resolvedState === 'correct'} intensity="burst" />

      <motion.div
        key={question.id}
        initial={{ rotateY: 180, scale: 0.9, opacity: 0.4 }}
        animate={{ rotateY: 0, scale: 1, opacity: 1 }}
        transition={{ duration: 0.42, ease: [0.16, 1, 0.3, 1] }}
        style={{
          transformStyle: 'preserve-3d',
          borderColor: meta.accentHex,
          boxShadow: `0 0 42px ${meta.accentHex}44, 0 24px 60px rgba(0,0,0,0.95)`,
        }}
        className="relative w-full max-w-lg max-h-[92vh] overflow-y-auto bg-black text-white rounded-2xl border-2"
      >
        {/* Category Header Bar */}
        <div
          className="px-5 py-4 flex items-center justify-between gap-3"
          style={{
            backgroundColor: meta.accentHex,
            color: meta.textOnAccent,
          }}
        >
          <div className="flex items-center gap-2.5 min-w-0">
            <CategoryIcon category={question.category} />
            <div className="min-w-0">
              <p className="text-xs font-semibold opacity-85 truncate">
                {isTiebreaker
                  ? `Desempate · Ronda ${tiebreakerRound} · ${diffLabel}`
                  : `Casilla de categoría · ${diffLabel}`}
              </p>
              <h2 className="font-display text-xl font-bold leading-tight truncate">
                {meta.label}
              </h2>
            </div>
          </div>

          <div
            className={`flex items-center gap-1.5 px-3 py-1.5 rounded-full font-mono text-sm font-bold tabular-nums shrink-0 transition-colors ${
              isCritical
                ? 'bg-rose-600 text-white animate-pulse shadow-[0_0_16px_rgba(225,29,72,0.75)]'
                : isWarning
                  ? 'bg-amber-400 text-black shadow-sm'
                  : 'bg-black/25 text-current'
            }`}
          >
            <Clock className="w-4 h-4 shrink-0" aria-hidden="true" />
            <span>{secondsLeft}s</span>
          </div>
        </div>

        {/* Visual 30s Timer Progress Bar */}
        <div className="w-full h-2 bg-neutral-900 overflow-hidden">
          <div
            className={`h-full transition-all duration-300 linear ${
              isCritical
                ? 'bg-rose-500'
                : isWarning
                  ? 'bg-amber-400'
                  : 'bg-emerald-400'
            }`}
            style={{
              width: `${progressPct}%`,
              boxShadow: isCritical
                ? '0 0 10px #f43f5e'
                : isWarning
                  ? '0 0 10px #fbbf24'
                  : 'none',
            }}
          />
        </div>

        {/* Body */}
        <div className="relative p-5 sm:p-6 bg-black">
          <svg
            viewBox="0 0 24 24"
            className="w-3.5 h-3.5 text-white/30 absolute top-4 right-5 pointer-events-none"
            fill="currentColor"
            aria-hidden="true"
          >
            <path d="M12 0 L14.8 9.2 L24 12 L14.8 14.8 L12 24 L9.2 14.8 L0 12 L9.2 9.2 Z" />
          </svg>

          <div className="flex items-center justify-between gap-2 text-sm text-neutral-300 mb-3">
            <div className="flex items-center gap-2">
              <PlayerTokenIcon color={player.color} size="sm" />
              <span>
                Turno de <strong className="text-white">{player.name}</strong>
              </span>
              {player.isBot && (
                <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-full bg-cyan-400/15 border border-cyan-400/35 text-[10px] font-bold text-cyan-300">
                  <Bot className="w-3 h-3" aria-hidden="true" />
                  Bot {DIFFICULTY_META[player.botDifficulty ?? 'medium'].label}
                </span>
              )}
            </div>
            {isWarning && (
              <span className="text-xs font-bold text-amber-400">¡Últimos 10s!</span>
            )}
            {isCritical && (
              <span className="text-xs font-bold text-rose-400">¡Tiempo límite!</span>
            )}
          </div>

          <h3
            id="question-title"
            className="font-sans text-xl sm:text-2xl font-bold text-white leading-snug text-balance"
          >
            {question.prompt}
          </h3>

          {/* Status banners when waiting on Bot or remote player */}
          {resolvedState === 'pending' && isLocalBotTurn && (
            <div className="mt-4 rounded-xl bg-neutral-950 border border-cyan-400/40 px-4 py-3 flex items-center gap-3">
              <div className="w-8 h-8 rounded-full bg-cyan-400/15 border border-cyan-400/40 flex items-center justify-center shrink-0 animate-pulse">
                <Bot className="w-4 h-4 text-cyan-300" aria-hidden="true" />
              </div>
              <div>
                <p className="font-display font-bold text-sm text-white">
                  {player.name} está pensando su respuesta...
                </p>
                <p className="text-xs text-neutral-400">
                  Responderá automáticamente en unos segundos.
                </p>
              </div>
            </div>
          )}

          {resolvedState === 'pending' && onlineMode && !isMyTurn && (
            <div className="mt-4 rounded-xl bg-neutral-950 border border-white/15 px-4 py-3 text-sm text-neutral-200">
              <p className="font-semibold text-white">
                Esperando respuesta de {player.name}...
              </p>
              <p className="text-xs text-neutral-400 mt-0.5">
                El marcador y el resultado se sincronizarán automáticamente.
              </p>
            </div>
          )}

          {/* Multiple Choice Options Grid (A, B, C, D) */}
          {isMultipleChoice && (
            <div className="mt-5 grid grid-cols-1 sm:grid-cols-2 gap-2.5">
              {mcOptions.map((option, idx) => {
                const letter = OPTION_LETTERS[idx] ?? String(idx + 1);
                const isResolved = resolvedState !== 'pending';
                const normOpt = normalizeAnswer(option);
                const isCorrectOption =
                  isResolved && normalizeAnswer(displayAnswer) === normOpt;
                const isSelectedOption =
                  submittedText.length > 0 && normalizeAnswer(submittedText) === normOpt;

                let cardStyle =
                  'bg-neutral-950 border-white/20 text-white hover:bg-neutral-900 hover:border-white/60';
                let badgeStyle = 'bg-white/10 text-neutral-200 border-white/20';

                if (isResolved) {
                  if (isCorrectOption) {
                    cardStyle =
                      'bg-emerald-950/70 border-emerald-400 text-emerald-100 shadow-[0_0_18px_rgba(52,211,153,0.22)]';
                    badgeStyle = 'bg-emerald-400 text-black border-emerald-300';
                  } else if (isSelectedOption) {
                    cardStyle =
                      'bg-rose-950/70 border-rose-400 text-rose-100 shadow-[0_0_18px_rgba(244,63,94,0.2)]';
                    badgeStyle = 'bg-rose-500 text-white border-rose-400';
                  } else {
                    cardStyle = 'bg-neutral-950/60 border-white/10 text-neutral-500 opacity-55';
                    badgeStyle = 'bg-white/5 text-neutral-500 border-white/10';
                  }
                } else if (!canHumanInteract) {
                  cardStyle = 'bg-neutral-950/75 border-white/15 text-neutral-300';
                }

                return (
                  <button
                    key={`${question.id}-opt-${idx}`}
                    type="button"
                    disabled={!canHumanInteract}
                    onClick={() => submitAnswerValue(option)}
                    className={`group w-full text-left px-3.5 py-3 rounded-xl border-2 flex items-center gap-3 transition-all ${cardStyle} ${
                      canHumanInteract ? 'cursor-pointer active:scale-[0.99]' : 'cursor-default'
                    }`}
                  >
                    <span
                      className={`font-display w-7 h-7 rounded-lg border text-xs font-bold flex items-center justify-center shrink-0 transition-colors ${badgeStyle}`}
                    >
                      {letter}
                    </span>
                    <span className="text-sm font-semibold leading-snug flex-1">
                      {option}
                    </span>
                    {isResolved && isCorrectOption && (
                      <CheckCircle2
                        className="w-4 h-4 text-emerald-400 shrink-0"
                        aria-hidden="true"
                      />
                    )}
                    {isResolved && !isCorrectOption && isSelectedOption && (
                      <XCircle
                        className="w-4 h-4 text-rose-400 shrink-0"
                        aria-hidden="true"
                      />
                    )}
                  </button>
                );
              })}
            </div>
          )}

          {/* Typed Answer Input (when AnswerMode === 'typed') */}
          {!isMultipleChoice && resolvedState === 'pending' && canHumanInteract && (
            <form onSubmit={handleSubmit} className="mt-5 space-y-3">
              <div>
                <label htmlFor="trivia-answer-input" className="sr-only">
                  Tu respuesta
                </label>
                <input
                  id="trivia-answer-input"
                  ref={inputRef}
                  type="text"
                  value={answer}
                  onChange={(e) => setAnswer(e.target.value)}
                  placeholder="Escribe tu respuesta aquí..."
                  autoComplete="off"
                  className="w-full px-4 py-3 rounded-xl bg-neutral-950 border-2 border-white/25 focus:border-white focus:outline-none text-base text-white placeholder:text-neutral-500 transition-colors"
                />
                <p className="text-xs text-neutral-400 mt-1.5">
                  No importan mayúsculas ni acentos. Presiona Enter para enviar.
                </p>
              </div>

              <button
                type="submit"
                disabled={!answer.trim()}
                style={{
                  backgroundColor: answer.trim() ? meta.accentHex : undefined,
                  color: answer.trim() ? meta.textOnAccent : undefined,
                }}
                className="font-display w-full min-h-[46px] px-5 py-2.5 rounded-xl disabled:bg-neutral-900 disabled:text-neutral-600 font-bold text-base transition-all hover:brightness-110 hover:shadow-[0_0_24px_rgba(255,255,255,0.2)] cursor-pointer disabled:cursor-not-allowed whitespace-nowrap shrink-0"
              >
                Comprobar respuesta
              </button>
            </form>
          )}

          {/* Resolution Banner */}
          {resolvedState !== 'pending' && (
            <div className="mt-5 space-y-4">
              {resolvedState === 'correct' ? (
                <div className="rounded-xl bg-emerald-950/60 border border-emerald-400/60 shadow-[0_0_20px_rgba(52,211,153,0.18)] p-4 flex items-start gap-3">
                  <CheckCircle2
                    className="w-6 h-6 text-emerald-400 shrink-0 mt-0.5"
                    aria-hidden="true"
                  />
                  <div>
                    <p className="font-display font-bold text-emerald-300 text-base">
                      ¡Correcto! +1 punto para {player.name}
                    </p>
                    <p className="text-sm text-emerald-100 mt-0.5">
                      Respuesta: <strong>{displayAnswer}</strong>
                    </p>
                  </div>
                </div>
              ) : (
                <div className="rounded-xl bg-rose-950/60 border border-rose-400/60 shadow-[0_0_20px_rgba(244,63,94,0.18)] p-4 flex items-start gap-3">
                  <XCircle
                    className="w-6 h-6 text-rose-400 shrink-0 mt-0.5"
                    aria-hidden="true"
                  />
                  <div>
                    <p className="font-display font-bold text-rose-300 text-base">
                      {resolvedState === 'timeout'
                        ? '¡Se acabó el tiempo! Sin puntos'
                        : 'Respuesta incorrecta · Sin puntos'}
                    </p>
                    {submittedText && (
                      <p className="text-xs text-rose-200/80 mt-0.5">
                        Respondió: “{submittedText}”
                      </p>
                    )}
                    <p className="text-sm text-white mt-1">
                      Respuesta correcta: <strong>{displayAnswer}</strong>
                    </p>
                  </div>
                </div>
              )}

              {!onlineMode || isMyTurn ? (
                <button
                  type="button"
                  autoFocus={!isLocalBotTurn}
                  onClick={() => {
                    gameAudio.playClick();
                    if (onlineMode) {
                      onContinueOnline?.();
                    } else {
                      fireCompleteOnce(resolvedState === 'correct', resolvedState === 'timeout');
                    }
                  }}
                  className="font-display w-full min-h-[46px] px-5 py-2.5 rounded-xl bg-white hover:bg-neutral-200 hover:shadow-[0_0_22px_rgba(255,255,255,0.3)] text-black font-bold text-base transition-all cursor-pointer whitespace-nowrap shrink-0"
                >
                  {isLocalBotTurn ? 'Continuar ahora' : 'Continuar'}
                </button>
              ) : (
                <p className="text-center text-xs text-neutral-400">
                  Esperando a que {player.name} continúe...
                </p>
              )}
            </div>
          )}
        </div>
      </motion.div>
    </div>
  );
}

