import type { ExtraCard } from '../types/game.ts';

export const EXTRA_CARDS: ExtraCard[] = [
  // Retos
  {
    id: 'extra-reto-1',
    title: 'Reto Relámpago: Capitales',
    description:
      'Di en voz alta 5 capitales de países americanos en menos de 10 segundos. El grupo valida si lo lograste.',
    effectType: 'CHALLENGE',
    value: 1,
    effectLabel: 'Si lo logras: +1 punto',
  },
  {
    id: 'extra-reto-2',
    title: 'Reto Relámpago: Sin Vocal',
    description:
      'Describe tu animal favorito durante 10 segundos sin mencionar su nombre para que otro jugador lo adivine.',
    effectType: 'CHALLENGE',
    value: 1,
    effectLabel: 'Si lo logras: +1 punto',
  },
  {
    id: 'extra-reto-3',
    title: 'Reto Mental: Cálculo Express',
    description:
      'Resuelve mentalmente frente a los demás sin usar papel: ¿Cuánto es 18 × 4 - 12?',
    effectType: 'CHALLENGE',
    value: 1,
    effectLabel: 'Respuesta correcta (60): +1 punto',
  },
  {
    id: 'extra-reto-4',
    title: 'Reto de Memoria',
    description:
      'Menciona 4 elementos químicos de la tabla periódica en 10 segundos sin repetir ninguno.',
    effectType: 'CHALLENGE',
    value: 1,
    effectLabel: 'Si lo logras: +1 punto',
  },

  // Premios / Puntos extra
  {
    id: 'extra-premio-1',
    title: 'Bono de Sabiduría',
    description:
      '¡Golpe de suerte! La mesa reconoce tu dominio del tablero y recibes un punto directo.',
    effectType: 'BONUS_POINTS',
    value: 1,
    effectLabel: '+1 punto inmediato',
  },
  {
    id: 'extra-premio-2',
    title: 'Premio Doble',
    description:
      'Encontraste el comodín dorado del tablero. Suma dos puntos directamente a tu marcador.',
    effectType: 'BONUS_POINTS',
    value: 2,
    effectLabel: '+2 puntos inmediatos',
  },
  {
    id: 'extra-premio-3',
    title: 'Punto de Cortesía',
    description:
      'Un respiro en la competencia: sumas un punto extra sin responder pregunta.',
    effectType: 'BONUS_POINTS',
    value: 1,
    effectLabel: '+1 punto inmediato',
  },

  // Penalizaciones
  {
    id: 'extra-pen-1',
    title: 'Trampa del Tablero',
    description:
      'Caíste en una casilla de penalización. Pierdes 1 punto de tu marcador (nunca baja de 0).',
    effectType: 'LOSE_POINTS',
    value: 1,
    effectLabel: '-1 punto',
  },
  {
    id: 'extra-pen-2',
    title: 'Pausa Obligada',
    description:
      '¡Atasco en el camino! Pierdes tu próximo turno mientras reorganizas tu estrategia.',
    effectType: 'SKIP_TURN',
    value: 1,
    effectLabel: 'Pierdes tu siguiente turno',
  },
  {
    id: 'extra-pen-3',
    title: 'Multa de Conocimiento',
    description:
      'Un tropiezo inesperado te cuesta 1 punto en el marcador actual (mínimo 0).',
    effectType: 'LOSE_POINTS',
    value: 1,
    effectLabel: '-1 punto',
  },

  // Avanzar / Retroceder casillas
  {
    id: 'extra-mov-1',
    title: 'Viento a Favor',
    description:
      'Aprovechas el impulso del tablero y avanzas 2 casillas adicionales en sentido horario.',
    effectType: 'MOVE_FORWARD',
    value: 2,
    effectLabel: 'Avanzas 2 casillas',
  },
  {
    id: 'extra-mov-2',
    title: 'Atajo Veloz',
    description:
      '¡Despegue inmediato! Tu ficha avanza 3 casillas hacia adelante en el recorrido.',
    effectType: 'MOVE_FORWARD',
    value: 3,
    effectLabel: 'Avanzas 3 casillas',
  },
  {
    id: 'extra-mov-3',
    title: 'Paso en Falso',
    description:
      'El camino se resbala y debes retroceder 2 casillas en el tablero.',
    effectType: 'MOVE_BACKWARD',
    value: 2,
    effectLabel: 'Retrocedes 2 casillas',
  },
  {
    id: 'extra-mov-4',
    title: 'Desvío Inesperado',
    description:
      'Un desvío te obliga a volver 3 casillas atrás en tu recorrido.',
    effectType: 'MOVE_BACKWARD',
    value: 3,
    effectLabel: 'Retrocedes 3 casillas',
  },

  // Repetir tiro de dado
  {
    id: 'extra-roll-1',
    title: 'Tiro Extra',
    description:
      '¡La suerte está de tu lado! Conservas el turno y vuelves a lanzar el dado inmediatamente.',
    effectType: 'EXTRA_ROLL',
    value: 1,
    effectLabel: 'Repites tiro de dado',
  },
  {
    id: 'extra-roll-2',
    title: 'Turno Continuo',
    description:
      'No sueltes el dado todavía: tienes derecho a un lanzamiento adicional ahora mismo.',
    effectType: 'EXTRA_ROLL',
    value: 1,
    effectLabel: 'Repites tiro de dado',
  },
];

export function pickRandomExtraCard(lastCardId?: string): ExtraCard {
  const pool = lastCardId
    ? EXTRA_CARDS.filter((c) => c.id !== lastCardId)
    : EXTRA_CARDS;
  return pool[Math.floor(Math.random() * pool.length)];
}
