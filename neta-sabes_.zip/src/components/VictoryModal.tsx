import { Bot, RotateCcw, Trophy } from 'lucide-react';
import { motion } from 'motion/react';
import { DIFFICULTY_META } from '../data/questions';
import { Player } from '../types/game';
import { gameAudio } from '../utils/sound';
import { ConfettiBurst } from './ConfettiBurst';
import { PlayerTokenIcon } from './PlayerTokenIcon';

interface VictoryModalProps {
  players: Player[];
  winner: Player;
  wonByTiebreaker: boolean;
  onlineMode?: boolean;
  isHost?: boolean;
  onPlayAgainSamePlayers: () => void;
  onResetToSetup: () => void;
}

export function VictoryModal({
  players,
  winner,
  wonByTiebreaker,
  onlineMode = false,
  isHost = true,
  onPlayAgainSamePlayers,
  onResetToSetup,
}: VictoryModalProps) {
  const sorted = [...players].sort((a, b) => {
    if (a.id === winner.id) return -1;
    if (b.id === winner.id) return 1;
    return b.score - a.score;
  });

  return (
    <div
      className="fixed inset-0 z-50 bg-black/85 backdrop-blur-sm flex items-center justify-center p-4"
      role="dialog"
      aria-modal="true"
      aria-labelledby="victory-title"
    >
      <ConfettiBurst active={true} intensity="celebration" />

      <motion.div
        initial={{ opacity: 0, scale: 0.92, y: 12 }}
        animate={{ opacity: 1, scale: 1, y: 0 }}
        transition={{ duration: 0.3, ease: [0.16, 1, 0.3, 1] }}
        className="relative z-10 w-full max-w-lg bg-black text-white rounded-2xl border-2 border-yellow-400 shadow-[0_0_50px_rgba(250,204,21,0.28)] overflow-hidden"
      >
        <div className="relative bg-yellow-400 text-black px-6 py-5 text-center overflow-hidden">
          {/* Curved orbital line & 4-point sparkles */}
          <svg
            viewBox="0 0 400 120"
            className="absolute inset-0 w-full h-full pointer-events-none opacity-25"
            fill="none"
            aria-hidden="true"
          >
            <path
              d="M -20 95 C 90 15, 310 15, 420 95"
              stroke="#000000"
              strokeWidth="1.5"
            />
          </svg>
          <svg
            viewBox="0 0 24 24"
            className="w-4 h-4 text-black/60 absolute top-4 left-6 pointer-events-none"
            fill="currentColor"
            aria-hidden="true"
          >
            <path d="M12 0 L14.8 9.2 L24 12 L14.8 14.8 L12 24 L9.2 14.8 L0 12 L9.2 9.2 Z" />
          </svg>
          <svg
            viewBox="0 0 24 24"
            className="w-5 h-5 text-black/60 absolute top-5 right-7 pointer-events-none"
            fill="currentColor"
            aria-hidden="true"
          >
            <path d="M12 0 L14.8 9.2 L24 12 L14.8 14.8 L12 24 L9.2 14.8 L0 12 L9.2 9.2 Z" />
          </svg>

          <div className="relative z-10 w-12 h-12 rounded-full bg-black/10 mx-auto flex items-center justify-center mb-2">
            <Trophy className="w-6 h-6 text-black" aria-hidden="true" />
          </div>
          <p className="relative z-10 text-xs font-bold uppercase tracking-wider opacity-80">
            {wonByTiebreaker ? 'Campeón por desempate' : 'Fin de la partida'}
          </p>
          <h2 id="victory-title" className="relative z-10 font-display text-3xl font-bold mt-0.5">
            ¡Ganó {winner.name}!
          </h2>
          <p className="relative z-10 text-sm font-semibold mt-1 tabular-nums">
            {winner.score} {winner.score === 1 ? 'punto' : 'puntos'} finales
          </p>
        </div>

        <div className="p-5 sm:p-6 bg-black">
          <h3 className="font-display text-xs font-semibold text-neutral-400 mb-3">
            Clasificación final
          </h3>

          <ul className="space-y-2">
            {sorted.map((p, idx) => (
              <li
                key={p.id}
                className={`flex items-center justify-between gap-3 px-3.5 py-2.5 rounded-xl border ${
                  p.id === winner.id
                    ? 'bg-yellow-400/10 border-yellow-400/70 shadow-[0_0_16px_rgba(250,204,21,0.16)]'
                    : 'bg-neutral-950 border-white/15'
                }`}
              >
                <div className="flex items-center gap-3 min-w-0">
                  <span className="font-display font-bold text-sm text-neutral-400 w-5 tabular-nums">
                    #{idx + 1}
                  </span>
                  <PlayerTokenIcon color={p.color} size="sm" />
                  <div className="min-w-0">
                    <div className="flex items-center gap-1.5 flex-wrap">
                      <p className="font-display font-bold text-sm text-white truncate">
                        {p.name}
                      </p>
                      {p.isBot && (
                        <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-full bg-cyan-400/15 border border-cyan-400/35 text-[10px] font-bold text-cyan-300 whitespace-nowrap shrink-0">
                          <Bot className="w-2.5 h-2.5" aria-hidden="true" />
                          {DIFFICULTY_META[p.botDifficulty ?? 'medium'].label}
                        </span>
                      )}
                    </div>
                    <p className="text-xs text-neutral-400 tabular-nums">
                      {p.correctAnswers} aciertos de {p.questionsAnswered} preguntas
                    </p>
                  </div>
                </div>
                <span className="px-3 py-1 rounded-full bg-white/10 border border-white/15 font-display text-base font-bold text-white tabular-nums shrink-0">
                  {p.score}{' '}
                  <span className="text-xs font-sans font-normal text-neutral-300">pts</span>
                </span>
              </li>
            ))}
          </ul>

          <div className="mt-6 grid grid-cols-1 sm:grid-cols-2 gap-2.5">
            {(!onlineMode || isHost) ? (
              <button
                type="button"
                onClick={() => {
                  gameAudio.playClick();
                  onPlayAgainSamePlayers();
                }}
                className="font-display min-h-[46px] px-4 py-2.5 rounded-xl bg-yellow-400 hover:bg-yellow-300 hover:shadow-[0_0_24px_rgba(250,204,21,0.45)] text-black font-bold text-sm inline-flex items-center justify-center gap-2 transition-all cursor-pointer whitespace-nowrap shrink-0"
              >
                <RotateCcw className="w-4 h-4 shrink-0" aria-hidden="true" />
                <span>Jugar otra partida</span>
              </button>
            ) : (
              <div className="min-h-[46px] px-4 py-2.5 rounded-xl bg-neutral-950 border border-white/15 text-neutral-300 text-xs font-medium flex items-center justify-center text-center">
                Esperando al anfitrión...
              </div>
            )}
            <button
              type="button"
              onClick={() => {
                gameAudio.playClick();
                onResetToSetup();
              }}
              className="font-display min-h-[46px] px-4 py-2.5 rounded-xl bg-neutral-950 hover:bg-neutral-900 border border-white/20 hover:border-white/45 text-white font-semibold text-sm transition-all cursor-pointer whitespace-nowrap shrink-0"
            >
              {onlineMode ? 'Salir de la sala' : 'Cambiar jugadores'}
            </button>
          </div>
        </div>
      </motion.div>
    </div>
  );
}
