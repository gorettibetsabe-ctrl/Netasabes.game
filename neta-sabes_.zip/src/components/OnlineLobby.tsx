import { useState } from 'react';
import { Check, Copy, Keyboard, Link2, ListChecks, LogOut, Play, Users } from 'lucide-react';
import { BOARD_IMAGE_PATH, PLAYER_COLORS } from '../data/board';
import { ANSWER_MODE_META, DIFFICULTY_META } from '../data/questions';
import { AnswerMode, DifficultyLevel, OnlineRoomSnapshot } from '../types/game';
import { gameAudio } from '../utils/sound';
import { PlayerTokenIcon } from './PlayerTokenIcon';

interface OnlineLobbyProps {
  room: OnlineRoomSnapshot;
  myClientId: string;
  onUpdateProfile: (name: string, colorId: string) => void;
  onChangeDifficulty: (difficulty: DifficultyLevel) => void;
  onChangeAnswerMode: (mode: AnswerMode) => void;
  onStartGame: () => void;
  onLeaveRoom: () => void;
  errorMsg: string | null;
}

export function OnlineLobby({
  room,
  myClientId,
  onUpdateProfile,
  onChangeDifficulty,
  onChangeAnswerMode,
  onStartGame,
  onLeaveRoom,
  errorMsg,
}: OnlineLobbyProps) {
  const me = room.players.find((p) => p.clientId === myClientId);
  const [nameInput, setNameInput] = useState(me?.name ?? '');
  const [copiedCode, setCopiedCode] = useState(false);
  const [copiedLink, setCopiedLink] = useState(false);

  const isHost = room.hostClientId === myClientId;
  const takenColors = new Set(
    room.players.filter((p) => p.clientId !== myClientId).map((p) => p.color.id)
  );

  const inviteUrl =
    typeof window !== 'undefined'
      ? `${window.location.origin}/?sala=${room.roomCode}`
      : `?sala=${room.roomCode}`;

  const copyText = async (text: string, which: 'code' | 'link') => {
    gameAudio.playClick();
    try {
      await navigator.clipboard.writeText(text);
      if (which === 'code') {
        setCopiedCode(true);
        setTimeout(() => setCopiedCode(false), 1800);
      } else {
        setCopiedLink(true);
        setTimeout(() => setCopiedLink(false), 1800);
      }
    } catch {
      // Clipboard blocked in restricted frames
    }
  };

  return (
    <div className="relative z-10 min-h-screen flex items-center justify-center p-4 sm:p-6 lg:p-8">
      <div className="w-full max-w-5xl grid grid-cols-1 lg:grid-cols-12 gap-6 lg:gap-8 items-stretch">
        {/* Left: Invite & Room Info */}
        <div className="lg:col-span-5 bg-black border border-white/20 rounded-2xl p-5 sm:p-6 flex flex-col justify-between gap-5 shadow-[0_0_40px_rgba(255,255,255,0.05)]">
          <div>
            <div className="flex items-center justify-between gap-2">
              <h1 className="font-display text-2xl font-bold text-white">
                Sala en línea
              </h1>
              <button
                type="button"
                onClick={() => {
                  gameAudio.playClick();
                  onLeaveRoom();
                }}
                className="font-display min-h-[36px] px-3 py-1.5 rounded-full bg-neutral-950 hover:bg-neutral-900 border border-white/20 text-xs font-semibold text-neutral-300 inline-flex items-center gap-1.5 transition-colors cursor-pointer whitespace-nowrap shrink-0"
              >
                <LogOut className="w-3.5 h-3.5 shrink-0" aria-hidden="true" />
                <span>Salir</span>
              </button>
            </div>

            <div className="mt-5 rounded-xl bg-neutral-950 border border-yellow-400/50 shadow-[0_0_24px_rgba(250,204,21,0.12)] p-4 text-center">
              <p className="text-xs font-medium text-neutral-400">
                Código para invitar amigos
              </p>
              <p className="font-mono text-3xl sm:text-4xl font-extrabold tracking-[0.22em] text-yellow-400 mt-1.5 select-all">
                {room.roomCode}
              </p>

              <div className="mt-4 grid grid-cols-2 gap-2">
                <button
                  type="button"
                  onClick={() => copyText(room.roomCode, 'code')}
                  className="font-display min-h-[40px] px-3 py-2 rounded-xl bg-black hover:bg-neutral-900 border border-white/20 text-xs font-semibold text-white inline-flex items-center justify-center gap-1.5 transition-colors cursor-pointer whitespace-nowrap shrink-0"
                >
                  {copiedCode ? (
                    <Check className="w-3.5 h-3.5 text-emerald-400 shrink-0" aria-hidden="true" />
                  ) : (
                    <Copy className="w-3.5 h-3.5 shrink-0" aria-hidden="true" />
                  )}
                  <span>{copiedCode ? 'Copiado' : 'Copiar código'}</span>
                </button>
                <button
                  type="button"
                  onClick={() => copyText(inviteUrl, 'link')}
                  className="font-display min-h-[40px] px-3 py-2 rounded-xl bg-yellow-400/15 hover:bg-yellow-400/25 border border-yellow-400/50 text-xs font-semibold text-yellow-300 inline-flex items-center justify-center gap-1.5 transition-colors cursor-pointer whitespace-nowrap shrink-0"
                >
                  {copiedLink ? (
                    <Check className="w-3.5 h-3.5 text-emerald-400 shrink-0" aria-hidden="true" />
                  ) : (
                    <Link2 className="w-3.5 h-3.5 shrink-0" aria-hidden="true" />
                  )}
                  <span>{copiedLink ? 'Enlace copiado' : 'Copiar enlace'}</span>
                </button>
              </div>
            </div>

            <div className="mt-5 aspect-square w-full max-w-[220px] mx-auto rounded-xl overflow-hidden bg-black border border-white/20">
              <img
                src={BOARD_IMAGE_PATH}
                alt="Tablero Neta sabes?"
                referrerPolicy="no-referrer"
                className="w-full h-full object-contain"
              />
            </div>
          </div>

          <div className="border-t border-white/15 pt-3.5 text-xs text-neutral-400">
            Comparte el código o enlace con hasta 3 amigos para jugar en tiempo real.
          </div>
        </div>

        {/* Right: Players, Profile & Difficulty */}
        <div className="lg:col-span-7 bg-black border border-white/20 rounded-2xl p-5 sm:p-7 flex flex-col justify-between shadow-[0_0_40px_rgba(255,255,255,0.05)]">
          <div className="space-y-5">
            <div className="flex flex-wrap items-center justify-between gap-3 border-b border-white/15 pb-4">
              <div>
                <h2 className="font-display text-xl font-bold text-white flex items-center gap-2">
                  <Users className="w-5 h-5 text-yellow-400 shrink-0" aria-hidden="true" />
                  <span>Jugadores en sala ({room.players.length}/4)</span>
                </h2>
                <p className="text-xs text-neutral-400 mt-0.5">
                  Mínimo 2 jugadores para comenzar la partida
                </p>
              </div>
            </div>

            {/* Difficulty selector */}
            <div className="rounded-xl bg-neutral-950 border border-purple-500/40 p-4">
              <div className="flex flex-wrap items-center justify-between gap-3">
                <div>
                  <p className="font-display text-xs font-bold text-white">
                    Nivel de dificultad
                  </p>
                  <p className="text-xs text-neutral-400 mt-0.5">
                    {DIFFICULTY_META[room.difficulty].description}
                  </p>
                </div>

                {isHost ? (
                  <div className="flex items-center gap-1 p-1 bg-black border border-white/15 rounded-xl">
                    {(['easy', 'medium', 'hard'] as DifficultyLevel[]).map((lvl) => (
                      <button
                        key={lvl}
                        type="button"
                        onClick={() => {
                          gameAudio.playClick();
                          onChangeDifficulty(lvl);
                        }}
                        className={`font-display px-3 py-1.5 rounded-lg text-xs font-bold transition-all cursor-pointer whitespace-nowrap shrink-0 ${
                          room.difficulty === lvl
                            ? 'bg-purple-500 text-white shadow-[0_0_12px_rgba(168,85,247,0.4)]'
                            : 'text-neutral-300 hover:text-white'
                        }`}
                      >
                        {DIFFICULTY_META[lvl].label}
                      </button>
                    ))}
                  </div>
                ) : (
                  <span className="px-3 py-1 rounded-full bg-purple-500/20 border border-purple-400/40 font-display text-xs font-bold text-purple-300">
                    {DIFFICULTY_META[room.difficulty].label}
                  </span>
                )}
              </div>
            </div>

            {/* Answer mode selector */}
            <div className="rounded-xl bg-neutral-950 border border-cyan-400/40 p-4">
              <div className="flex flex-wrap items-center justify-between gap-3">
                <div>
                  <p className="font-display text-xs font-bold text-white">
                    Modo de respuesta
                  </p>
                  <p className="text-xs text-neutral-400 mt-0.5">
                    {ANSWER_MODE_META[room.answerMode].description}
                  </p>
                </div>

                {isHost ? (
                  <div className="flex items-center gap-1 p-1 bg-black border border-white/15 rounded-xl">
                    <button
                      type="button"
                      onClick={() => {
                        gameAudio.playClick();
                        onChangeAnswerMode('multiple_choice');
                      }}
                      className={`font-display px-3 py-1.5 rounded-lg text-xs font-bold inline-flex items-center gap-1.5 transition-all cursor-pointer whitespace-nowrap shrink-0 ${
                        room.answerMode === 'multiple_choice'
                          ? 'bg-cyan-400 text-black shadow-[0_0_12px_rgba(34,211,238,0.4)]'
                          : 'text-neutral-300 hover:text-white'
                      }`}
                    >
                      <ListChecks className="w-3.5 h-3.5 shrink-0" aria-hidden="true" />
                      <span>Opción múltiple</span>
                    </button>
                    <button
                      type="button"
                      onClick={() => {
                        gameAudio.playClick();
                        onChangeAnswerMode('typed');
                      }}
                      className={`font-display px-3 py-1.5 rounded-lg text-xs font-bold inline-flex items-center gap-1.5 transition-all cursor-pointer whitespace-nowrap shrink-0 ${
                        room.answerMode === 'typed'
                          ? 'bg-cyan-400 text-black shadow-[0_0_12px_rgba(34,211,238,0.4)]'
                          : 'text-neutral-300 hover:text-white'
                      }`}
                    >
                      <Keyboard className="w-3.5 h-3.5 shrink-0" aria-hidden="true" />
                      <span>Escribir</span>
                    </button>
                  </div>
                ) : (
                  <span className="px-3 py-1 rounded-full bg-cyan-400/20 border border-cyan-400/40 font-display text-xs font-bold text-cyan-300">
                    {ANSWER_MODE_META[room.answerMode].label}
                  </span>
                )}
              </div>
            </div>

            {/* My profile editor */}
            {me && (
              <div className="rounded-xl bg-neutral-950 border border-yellow-400/40 p-4">
                <p className="font-display text-xs font-bold text-yellow-300 mb-2.5">
                  Tu ficha en la partida
                </p>
                <div className="flex flex-col sm:flex-row sm:items-center gap-3">
                  <div className="flex items-center gap-2.5 flex-1">
                    <PlayerTokenIcon color={me.color} size="md" />
                    <input
                      type="text"
                      maxLength={18}
                      value={nameInput}
                      onChange={(e) => {
                        setNameInput(e.target.value);
                        onUpdateProfile(e.target.value, me.color.id);
                      }}
                      placeholder="Tu nombre"
                      className="w-full px-3 py-2 rounded-xl bg-black border border-white/20 focus:border-yellow-400 focus:outline-none text-sm font-medium text-white"
                    />
                  </div>

                  <div className="flex items-center gap-2 shrink-0">
                    {PLAYER_COLORS.map((c) => {
                      const selected = me.color.id === c.id;
                      const isTaken = takenColors.has(c.id);
                      return (
                        <button
                          key={c.id}
                          type="button"
                          disabled={isTaken}
                          onClick={() => onUpdateProfile(nameInput || me.name, c.id)}
                          aria-label={`Color ${c.name}`}
                          className={`w-8 h-8 rounded-full transition-transform ${
                            selected
                              ? 'ring-2 ring-white scale-110 cursor-default'
                              : isTaken
                                ? 'opacity-20 cursor-not-allowed'
                                : 'opacity-65 hover:opacity-100 cursor-pointer'
                          }`}
                          style={{ backgroundColor: c.hex }}
                        />
                      );
                    })}
                  </div>
                </div>
              </div>
            )}

            {/* Player roster */}
            <ul className="space-y-2">
              {room.players.map((p) => {
                const isSelf = p.clientId === myClientId;
                return (
                  <li
                    key={p.id}
                    className="flex items-center justify-between gap-3 px-3.5 py-2.5 rounded-xl bg-neutral-950 border border-white/15"
                  >
                    <div className="flex items-center gap-3 min-w-0">
                      <PlayerTokenIcon color={p.color} size="sm" />
                      <div className="min-w-0">
                        <p className="font-display text-sm font-bold text-white truncate">
                          {p.name} {isSelf ? '(Tú)' : ''}
                        </p>
                        <p className="text-xs text-neutral-400">
                          {p.isHost ? 'Anfitrión' : 'Invitado'} · {p.color.name}
                        </p>
                      </div>
                    </div>
                    <span className="px-2.5 py-0.5 rounded-full bg-emerald-500/15 border border-emerald-400/40 text-[11px] font-semibold text-emerald-300 whitespace-nowrap shrink-0">
                      {p.connected === false ? 'Reconectando...' : 'Listo'}
                    </span>
                  </li>
                );
              })}
            </ul>

            {errorMsg && (
              <p className="text-xs font-medium text-rose-300 bg-rose-950/60 border border-rose-500/50 rounded-xl px-3 py-2">
                {errorMsg}
              </p>
            )}
          </div>

          <div className="mt-6">
            {isHost ? (
              <button
                type="button"
                disabled={room.players.length < 2}
                onClick={onStartGame}
                className="font-display w-full min-h-[48px] px-6 py-3 rounded-xl bg-yellow-400 hover:bg-yellow-300 hover:shadow-[0_0_26px_rgba(250,204,21,0.45)] disabled:bg-neutral-900 disabled:text-neutral-600 text-black font-bold text-base inline-flex items-center justify-center gap-2 transition-all cursor-pointer disabled:cursor-not-allowed whitespace-nowrap shrink-0"
              >
                <Play className="w-5 h-5 fill-current shrink-0" aria-hidden="true" />
                <span>
                  {room.players.length < 2
                    ? 'Esperando al menos 2 jugadores...'
                    : 'Iniciar partida'}
                </span>
              </button>
            ) : (
              <div className="w-full min-h-[48px] px-6 py-3 rounded-xl bg-neutral-950 border border-white/15 text-neutral-300 text-sm font-medium flex items-center justify-center text-center">
                Esperando a que el anfitrión inicie la partida...
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}
