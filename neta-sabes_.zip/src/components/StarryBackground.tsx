const SPARKLES = [
  { top: '7%', left: '7%', size: 18, delay: '0s' },
  { top: '13%', left: '89%', size: 22, delay: '0.8s' },
  { top: '27%', left: '16%', size: 11, delay: '1.5s' },
  { top: '33%', left: '80%', size: 13, delay: '0.4s' },
  { top: '49%', left: '4%', size: 15, delay: '1.9s' },
  { top: '57%', left: '94%', size: 18, delay: '1.1s' },
  { top: '72%', left: '11%', size: 20, delay: '0.2s' },
  { top: '82%', left: '86%', size: 12, delay: '1.6s' },
  { top: '91%', left: '33%', size: 14, delay: '0.9s' },
  { top: '19%', left: '51%', size: 10, delay: '2.1s' },
  { top: '66%', left: '63%', size: 11, delay: '0.7s' },
  { top: '43%', left: '41%', size: 9, delay: '1.3s' },
];

const STAR_DOTS = [
  { top: '11%', left: '29%', delay: '0.3s' },
  { top: '21%', left: '69%', delay: '1.2s' },
  { top: '39%', left: '13%', delay: '0.7s' },
  { top: '52%', left: '87%', delay: '1.8s' },
  { top: '76%', left: '47%', delay: '0.5s' },
  { top: '87%', left: '72%', delay: '1.4s' },
  { top: '93%', left: '15%', delay: '0.9s' },
  { top: '15%', left: '42%', delay: '2.2s' },
  { top: '62%', left: '26%', delay: '1.0s' },
];

export function StarryBackground() {
  return (
    <div
      aria-hidden="true"
      className="fixed inset-0 pointer-events-none overflow-hidden z-0 bg-black"
    >
      {/* Thin curved orbital accent lines matching the board's center artwork */}
      <svg
        viewBox="0 0 1440 900"
        preserveAspectRatio="xMidYMid slice"
        className="absolute inset-0 w-full h-full opacity-25"
        fill="none"
      >
        <path
          d="M -120 260 C 260 110, 680 120, 1180 280"
          stroke="rgba(255,255,255,0.22)"
          strokeWidth="1.2"
        />
        <path
          d="M 240 860 C 620 710, 1020 710, 1540 540"
          stroke="rgba(255,255,255,0.18)"
          strokeWidth="1.2"
        />
        <ellipse
          cx="720"
          cy="450"
          rx="540"
          ry="210"
          transform="rotate(-11 720 450)"
          stroke="rgba(255,255,255,0.1)"
          strokeWidth="1"
        />
      </svg>

      {SPARKLES.map((star, idx) => (
        <svg
          key={idx}
          viewBox="0 0 24 24"
          className="absolute text-white animate-twinkle"
          style={{
            top: star.top,
            left: star.left,
            width: star.size,
            height: star.size,
            animationDelay: star.delay,
          }}
          fill="currentColor"
        >
          <path d="M12 0 L14.8 9.2 L24 12 L14.8 14.8 L12 24 L9.2 14.8 L0 12 L9.2 9.2 Z" />
        </svg>
      ))}

      {STAR_DOTS.map((dot, idx) => (
        <span
          key={idx}
          className="absolute w-1 h-1 rounded-full bg-white/70 animate-twinkle"
          style={{ top: dot.top, left: dot.left, animationDelay: dot.delay }}
        />
      ))}
    </div>
  );
}
