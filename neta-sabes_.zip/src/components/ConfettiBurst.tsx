import { useEffect, useRef } from 'react';

interface ConfettiBurstProps {
  active: boolean;
  intensity?: 'burst' | 'celebration';
}

const COLORS = [
  '#EF4444', // Historia
  '#F97316', // Matemáticas
  '#A855F7', // Filosofía
  '#22C55E', // Ciencias
  '#EC4899', // Arte
  '#FACC15', // Cultura General
  '#06B6D4', // Geografía
  '#FFFFFF',
];

interface Particle {
  x: number;
  y: number;
  vx: number;
  vy: number;
  size: number;
  color: string;
  rotation: number;
  vr: number;
  alpha: number;
}

export function ConfettiBurst({ active, intensity = 'burst' }: ConfettiBurstProps) {
  const canvasRef = useRef<HTMLCanvasElement>(null);

  useEffect(() => {
    if (!active) return;
    if (window.matchMedia('(prefers-reduced-motion: reduce)').matches) return;

    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    const resize = () => {
      canvas.width = window.innerWidth;
      canvas.height = window.innerHeight;
    };
    resize();

    const count = intensity === 'celebration' ? 110 : 48;
    const particles: Particle[] = Array.from({ length: count }, () => {
      const fromTop = intensity === 'celebration';
      return {
        x: fromTop
          ? Math.random() * canvas.width
          : canvas.width * 0.5 + (Math.random() - 0.5) * 140,
        y: fromTop ? -20 - Math.random() * 140 : canvas.height * 0.45,
        vx: (Math.random() - 0.5) * (fromTop ? 4 : 11),
        vy: fromTop ? 2.5 + Math.random() * 4.5 : -4 - Math.random() * 8,
        size: 6 + Math.random() * 6,
        color: COLORS[Math.floor(Math.random() * COLORS.length)],
        rotation: Math.random() * Math.PI * 2,
        vr: (Math.random() - 0.5) * 0.2,
        alpha: 1,
      };
    });

    let animId = 0;
    let frames = 0;
    const maxFrames = intensity === 'celebration' ? 210 : 95;

    const render = () => {
      frames += 1;
      ctx.clearRect(0, 0, canvas.width, canvas.height);

      for (const p of particles) {
        p.x += p.vx;
        p.y += p.vy;
        p.vy += 0.16;
        p.rotation += p.vr;
        if (frames > maxFrames * 0.65) {
          p.alpha = Math.max(0, p.alpha - 0.03);
        }

        ctx.save();
        ctx.globalAlpha = p.alpha;
        ctx.translate(p.x, p.y);
        ctx.rotate(p.rotation);
        ctx.fillStyle = p.color;
        ctx.fillRect(-p.size / 2, -p.size / 4, p.size, p.size * 0.55);
        ctx.restore();
      }

      if (frames < maxFrames) {
        animId = window.requestAnimationFrame(render);
      } else {
        ctx.clearRect(0, 0, canvas.width, canvas.height);
      }
    };

    animId = window.requestAnimationFrame(render);
    return () => {
      window.cancelAnimationFrame(animId);
      ctx.clearRect(0, 0, canvas.width, canvas.height);
    };
  }, [active, intensity]);

  if (!active) return null;

  return (
    <canvas
      ref={canvasRef}
      aria-hidden="true"
      className="fixed inset-0 pointer-events-none z-[70]"
    />
  );
}
