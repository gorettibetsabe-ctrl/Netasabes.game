export type CategoryId =
  | 'historia'
  | 'matematicas'
  | 'filosofia'
  | 'ciencias'
  | 'arte'
  | 'cultura_general'
  | 'geografia';

export type DifficultyLevel = 'easy' | 'medium' | 'hard';

export type AnswerMode = 'multiple_choice' | 'typed';

export type TileType = 'SALIDA' | 'EXTRA' | CategoryId;

export interface BoardTile {
  index: number;
  type: TileType;
  label: string;
  x: number; // percentage 0..100
  y: number; // percentage 0..100
  isCorner?: boolean;
}

export interface CategoryMeta {
  id: CategoryId | 'SALIDA' | 'EXTRA';
  label: string;
  accentHex: string;
  textOnAccent: string;
  softBgClass: string;
  borderClass: string;
  badgeTextClass: string;
}

export interface PlayerColorOption {
  id: string;
  name: string;
  hex: string;
  ringHex: string;
  textHex: string;
  shape: 'circle' | 'diamond' | 'triangle' | 'star';
}

export interface Player {
  id: number;
  clientId?: string;
  name: string;
  color: PlayerColorOption;
  position: number; // 0..35
  score: number;
  completedLap: boolean;
  skipNextTurn: boolean;
  correctAnswers: number;
  questionsAnswered: number;
  connected?: boolean;
  isHost?: boolean;
  isBot?: boolean;
  botDifficulty?: DifficultyLevel;
}

export interface TriviaQuestion {
  id: string;
  category: CategoryId;
  difficulty: DifficultyLevel;
  prompt: string;
  displayAnswer: string;
  acceptedAnswers: string[];
  hint?: string;
}

/** Question payload safe to broadcast during active play (answer withheld until resolved) */
export interface PublicQuestionPayload {
  id: string;
  category: CategoryId;
  difficulty: DifficultyLevel;
  prompt: string;
  options?: string[];
}

export interface QuestionResolution {
  correct: boolean;
  timedOut: boolean;
  submittedAnswer: string;
  displayAnswer: string;
  playerId: number;
}

export type ExtraCardEffectType =
  | 'CHALLENGE'
  | 'BONUS_POINTS'
  | 'LOSE_POINTS'
  | 'SKIP_TURN'
  | 'MOVE_FORWARD'
  | 'MOVE_BACKWARD'
  | 'EXTRA_ROLL';

export interface ExtraCard {
  id: string;
  title: string;
  description: string;
  effectType: ExtraCardEffectType;
  value?: number; // points or steps
  effectLabel: string;
}

export type GamePhase =
  | 'SETUP'
  | 'LOBBY_WAITING'
  | 'STARTER_REVEAL'
  | 'READY_TO_ROLL'
  | 'ROLLING'
  | 'MOVING'
  | 'QUESTION'
  | 'EXTRA_CARD'
  | 'TIEBREAKER_INTRO'
  | 'TIEBREAKER_QUESTION'
  | 'GAME_OVER';

export interface TurnEvent {
  id: string;
  playerName: string;
  playerHex: string;
  summary: string;
}

export interface OnlineRoomSnapshot {
  roomCode: string;
  hostClientId: string;
  difficulty: DifficultyLevel;
  answerMode: AnswerMode;
  phase: GamePhase;
  players: Player[];
  starterIndex: number;
  currentPlayerIndex: number;
  roundNumber: number;
  finalRoundTriggered: boolean;
  diceValue: number;
  statusMessage: string;
  events: TurnEvent[];
  activeQuestion: PublicQuestionPayload | null;
  questionDeadlineAt: number | null; // epoch ms for synchronized countdown
  questionResolution: QuestionResolution | null;
  activeExtraCard: ExtraCard | null;
  tiebreakerIds: number[];
  tiebreakerPointer: number;
  tiebreakerRound: number;
  tiebreakerScores: Record<number, number>;
  winnerId: number | null;
  wonByTiebreaker: boolean;
}
