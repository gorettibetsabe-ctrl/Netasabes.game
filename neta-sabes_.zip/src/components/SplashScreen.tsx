import { useEffect, useState } from 'react';
import { motion } from 'motion/react';

interface SplashScreenProps {
  onComplete: () => void;
}

export function SplashScreen({ onComplete }: SplashScreenProps) {
  const [progress, setProgress] = useState(0);

  useEffect(() => {
    const start = performance.now();
    const duration = 1650;
    let rafId = 0;

    const tick = (now: number) => {
      const elapsed = now - start;
      const pct = Math.min(100, (elapsed / duration) * 100);
      setProgress(pct);
      if (elapsed < duration) {
        rafId = window.requestAnimationFrame(tick);
      } else {
        onComplete();
      }
    };

    rafId = window.requestAnimationFrame(tick);
    return () => window.cancelAnimationFrame(rafId);
  }, [onComplete]);

  return (
    <div
      onClick={onComplete}
      className="fixed inset-0 z-50 bg-black text-white flex flex-col items-center justify-center p-6 cursor-pointer select-none overflow-hidden"
    >
      <div className="relative flex flex-col items-center">
        {/* Curved orbital swoosh lines mirroring the center artwork of the board */}
        <svg
          viewBox="0 0 360 220"
          className="w-80 sm:w-96 h-48 sm:h-56 pointer-events-none"
          fill="none"
          aria-hidden="true"
        >
          <motion.path
            d="M 48 128 C 12 104, 34 52, 118 44 C 214 35, 316 62, 312 108 C 308 154, 210 184, 110 174"
            stroke="rgba(255,255,255,0.55)"
            strokeWidth="2"
            strokeLinecap="round"
            initial={{ pathLength: 0, opacity: 0 }}
            animate={{ pathLength: 1, opacity: 1 }}
            transition={{ duration: 0.9, ease: [0.16, 1, 0.3, 1] }}
          />
          <motion.path
            d="M 78 168 C 145 192, 248 186, 304 146"
            stroke="rgba(255,255,255,0.35)"
            strokeWidth="1.5"
            strokeLinecap="round"
            initial={{ pathLength: 0, opacity: 0 }}
            animate={{ pathLength: 1, opacity: 1 }}
            transition={{ duration: 0.8, delay: 0.2 }}
          />
        </svg>

        {/* 4-point sparkles */}
        <motion.svg
          viewBox="0 0 24 24"
          className="w-7 h-7 text-white absolute top-4 left-6"
          fill="currentColor"
          initial={{ scale: 0, rotate: -45, opacity: 0 }}
          animate={{ scale: [0, 1.2, 1], rotate: 0, opacity: 1 }}
          transition={{ duration: 0.55, delay: 0.1 }}
          aria-hidden="true"
        >
          <path d="M12 0 L14.8 9.2 L24 12 L14.8 14.8 L12 24 L9.2 14.8 L0 12 L9.2 9.2 Z" />
        </motion.svg>

        <motion.svg
          viewBox="0 0 24 24"
          className="w-5 h-5 text-yellow-300 absolute top-6 right-8"
          fill="currentColor"
          initial={{ scale: 0, opacity: 0 }}
          animate={{ scale: [0, 1.25, 1], opacity: 0.95 }}
          transition={{ duration: 0.55, delay: 0.26 }}
          aria-hidden="true"
        >
          <path d="M12 0 L14.8 9.2 L24 12 L14.8 14.8 L12 24 L9.2 14.8 L0 12 L9.2 9.2 Z" />
        </motion.svg>

        <motion.svg
          viewBox="0 0 24 24"
          className="w-6 h-6 text-cyan-300 absolute bottom-28 right-4"
          fill="currentColor"
          initial={{ scale: 0, opacity: 0 }}
          animate={{ scale: [0, 1.2, 1], opacity: 0.9 }}
          transition={{ duration: 0.55, delay: 0.38 }}
          aria-hidden="true"
        >
          <path d="M12 0 L14.8 9.2 L24 12 L14.8 14.8 L12 24 L9.2 14.8 L0 12 L9.2 9.2 Z" />
        </motion.svg>

        {/* Centered Fredoka Emblem */}
        <motion.div
          initial={{ opacity: 0, scale: 0.86, y: 8 }}
          animate={{ opacity: 1, scale: 1, y: 0 }}
          transition={{ duration: 0.5, ease: [0.16, 1, 0.3, 1] }}
          className="absolute top-12 sm:top-14 text-center"
        >
          <div className="inline-block -rotate-4">
            <h1 className="font-display text-5xl sm:text-6xl font-bold tracking-tight text-white leading-[0.9] drop-shadow-[0_0_28px_rgba(255,255,255,0.28)]">
              Neta
              <br />
              sabes?
            </h1>
          </div>
        </motion.div>

        <p className="text-xs sm:text-sm text-neutral-400 tracking-wide mt-1">
          Edición Digital · Trivia &amp; Retos
        </p>

        {/* Saturated 7-Category Progress Bar */}
        <div className="w-56 sm:w-64 h-1.5 bg-white/15 rounded-full overflow-hidden mt-6">
          <div
            className="h-full transition-all duration-75"
            style={{
              width: `${progress}%`,
              background:
                'linear-gradient(90deg, #EF4444, #F97316, #A855F7, #22C55E, #EC4899, #FACC15, #06B6D4)',
            }}
          />
        </div>

        {/* Category Color Dots */}
        <div className="flex items-center gap-2.5 mt-4">
          {[
            '#EF4444',
            '#F97316',
            '#A855F7',
            '#22C55E',
            '#EC4899',
            '#FACC15',
            '#06B6D4',
          ].map((hex, i) => (
            <motion.span
              key={hex}
              className="w-2.5 h-2.5 rounded-full shadow-sm"
              style={{ backgroundColor: hex, boxShadow: `0 0 8px ${hex}` }}
              initial={{ scale: 0 }}
              animate={{ scale: 1 }}
              transition={{ delay: 0.14 + i * 0.055, duration: 0.25 }}
            />
          ))}
        </div>
      </div>

      <p className="absolute bottom-6 text-xs text-neutral-500">
        Toca en cualquier lugar para continuar
      </p>
    </div>
  );
}
