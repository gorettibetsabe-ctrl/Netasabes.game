import { Clock, Dices, Flag, Sparkles, Swords, X } from 'lucide-react';
import { motion } from 'motion/react';
import { CATEGORY_META } from '../data/board';
import { CategoryId } from '../types/game';
import { gameAudio } from '../utils/sound';

interface HowToPlayModalProps {
  onClose: () => void;
}

const CATEGORIES: CategoryId[] = [
  'historia',
  'matematicas',
  'filosofia',
  'ciencias',
  'arte',
  'cultura_general',
  'geografia',
];

export function HowToPlayModal({ onClose }: HowToPlayModalProps) {
  return (
    <div
      className="fixed inset-0 z-50 bg-black/85 backdrop-blur-sm flex items-center justify-center p-4"
      role="dialog"
      aria-modal="true"
      aria-labelledby="how-to-play-title"
    >
      <motion.div
        initial={{ opacity: 0, scale: 0.95, y: 8 }}
        animate={{ opacity: 1, scale: 1, y: 0 }}
        transition={{ duration: 0.2 }}
        className="w-full max-w-2xl max-h-[90vh] overflow-y-auto bg-black text-white rounded-2xl border-2 border-cyan-400/70 shadow-[0_0_40px_rgba(34,211,238,0.2)]"
      >
        <div className="sticky top-0 bg-black/95 backdrop-blur border-b border-white/15 px-6 py-4 flex items-center justify-between gap-4 z-10">
          <div>
            <h2 id="how-to-play-title" className="font-display text-2xl font-bold text-white">
              Cómo jugar «Neta sabes?»
            </h2>
            <p className="text-xs text-neutral-400 mt-0.5">
              Reglas oficiales del tablero en sentido horario
            </p>
          </div>
          <button
            type="button"
            onClick={() => {
              gameAudio.playClick();
              onClose();
            }}
            aria-label="Cerrar instrucciones"
            className="w-10 h-10 rounded-xl bg-neutral-950 hover:bg-neutral-900 border border-white/15 flex items-center justify-center text-neutral-300 hover:text-white transition-colors cursor-pointer shrink-0"
          >
            <X className="w-5 h-5" aria-hidden="true" />
          </button>
        </div>

        <div className="p-6 space-y-5 text-sm text-neutral-300 leading-relaxed">
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div className="rounded-xl bg-neutral-950 border border-red-500/40 p-4">
              <div className="flex items-center gap-2 text-white font-display font-bold mb-1.5">
                <Dices className="w-4 h-4 text-red-400 shrink-0" aria-hidden="true" />
                <span>1. Inicio y turnos</span>
              </div>
              <p className="text-xs text-neutral-300 leading-relaxed">
                De 2 a 4 jugadores colocan su ficha en <strong>SALIDA</strong>. El sistema
                sortea al azar quién comienza. En tu turno lanzas el dado virtual 3D y tu
                ficha avanza en sentido horario.
              </p>
            </div>

            <div className="rounded-xl bg-neutral-950 border border-cyan-400/40 p-4">
              <div className="flex items-center gap-2 text-white font-display font-bold mb-1.5">
                <Clock className="w-4 h-4 text-cyan-400 shrink-0" aria-hidden="true" />
                <span>2. Preguntas de 30 segundos</span>
              </div>
              <p className="text-xs text-neutral-300 leading-relaxed">
                Tienes 30 segundos para responder eligiendo entre 4 opciones (
                <strong>A, B, C o D</strong>) o escribiendo la respuesta según el modo de la
                partida (sin importar mayúsculas ni acentos). Si aciertas sumas{' '}
                <strong>+1 punto</strong>; si fallas o expira el reloj, pasa el turno.
              </p>
            </div>

            <div className="rounded-xl bg-neutral-950 border border-white/40 p-4">
              <div className="flex items-center gap-2 text-white font-display font-bold mb-1.5">
                <Sparkles className="w-4 h-4 text-white shrink-0" aria-hidden="true" />
                <span>3. Casillas blancas EXTRA</span>
              </div>
              <p className="text-xs text-neutral-300 leading-relaxed">
                Al caer en una casilla blanca se voltea una tarjeta aleatoria: retos
                rápidos, premios de puntos extra, penalizaciones, avanzar/retroceder
                casillas o repetir el tiro de dado.
              </p>
            </div>

            <div className="rounded-xl bg-neutral-950 border border-green-500/40 p-4">
              <div className="flex items-center gap-2 text-white font-display font-bold mb-1.5">
                <Flag className="w-4 h-4 text-green-400 shrink-0" aria-hidden="true" />
                <span>4. Cierre de ronda y victoria</span>
              </div>
              <p className="text-xs text-neutral-300 leading-relaxed">
                Cuando alguien da la vuelta completa y llega o pasa por{' '}
                <strong>SALIDA</strong>, se termina la ronda actual para que todos tengan
                los mismos turnos. Quien tenga más puntos gana.
              </p>
            </div>
          </div>

          <div className="rounded-xl bg-neutral-950 border border-purple-500/40 p-4">
            <div className="flex items-center gap-2 text-white font-display font-bold mb-2">
              <Swords className="w-4 h-4 text-purple-400 shrink-0" aria-hidden="true" />
              <span>Desempate y dificultades</span>
            </div>
            <p className="text-xs text-neutral-300 leading-relaxed">
              Si dos o más jugadores empatan en el primer lugar, se lanza una ronda de
              desempate con preguntas de 30 s solo para los empatados hasta definir un
              campeón único. Antes de iniciar puedes elegir dificultad{' '}
              <strong>Fácil</strong>, <strong>Medio</strong> o <strong>Difícil</strong>.
            </p>
          </div>

          <div>
            <p className="font-display text-xs font-semibold text-neutral-400 mb-2.5">
              Las 7 categorías del tablero
            </p>
            <div className="flex flex-wrap gap-2 text-xs">
              {CATEGORIES.map((cat) => (
                <span
                  key={cat}
                  className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-full bg-neutral-950 border text-white font-medium"
                  style={{ borderColor: `${CATEGORY_META[cat].accentHex}88` }}
                >
                  <span
                    className="w-2.5 h-2.5 rounded-full shrink-0"
                    style={{ backgroundColor: CATEGORY_META[cat].accentHex }}
                    aria-hidden="true"
                  />
                  <span>{CATEGORY_META[cat].label}</span>
                </span>
              ))}
            </div>
          </div>
        </div>

        <div className="border-t border-white/15 px-6 py-4 flex justify-end">
          <button
            type="button"
            onClick={() => {
              gameAudio.playClick();
              onClose();
            }}
            className="font-display min-h-[42px] px-6 py-2 rounded-xl bg-cyan-400 hover:bg-cyan-300 hover:shadow-[0_0_20px_rgba(34,211,238,0.45)] text-black font-bold text-sm transition-all cursor-pointer whitespace-nowrap shrink-0"
          >
            Entendido
          </button>
        </div>
      </motion.div>
    </div>
  );
}
