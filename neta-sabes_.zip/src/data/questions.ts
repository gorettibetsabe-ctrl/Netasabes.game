import type { AnswerMode, CategoryId, DifficultyLevel, TriviaQuestion } from '../types/game.ts';

export const DIFFICULTY_META: Record<
  DifficultyLevel,
  { id: DifficultyLevel; label: string; description: string }
> = {
  easy: {
    id: 'easy',
    label: 'Fácil',
    description: 'Cultura común y preguntas accesibles para todo público.',
  },
  medium: {
    id: 'medium',
    label: 'Medio',
    description: 'Nivel clásico equilibrado con datos históricos y científicos.',
  },
  hard: {
    id: 'hard',
    label: 'Difícil',
    description: 'Datos específicos, fechas precisas y conceptos avanzados.',
  },
};

export const ANSWER_MODE_META: Record<
  AnswerMode,
  { id: AnswerMode; label: string; shortLabel: string; description: string }
> = {
  multiple_choice: {
    id: 'multiple_choice',
    label: 'Opción múltiple',
    shortLabel: 'A–D',
    description: 'Elige entre 4 opciones (A, B, C o D) en cada pregunta.',
  },
  typed: {
    id: 'typed',
    label: 'Escribir respuesta',
    shortLabel: 'Escrita',
    description: 'Escribe la respuesta exacta sin importar mayúsculas ni acentos.',
  },
};

/**
 * Normaliza una cadena para comparar respuestas ignorando mayúsculas,
 * acentos/diacríticos, puntuación y espacios múltiples.
 */
export function normalizeAnswer(input: string): string {
  return input
    .toLowerCase()
    .normalize('NFD')
    .replace(/[\u0300-\u036f]/g, '')
    .replace(/[¡!¿?.,;:'"()\-_/]/g, ' ')
    .replace(/\s+/g, ' ')
    .trim();
}

function stripLeadingArticle(normalized: string): string {
  return normalized.replace(/^(el|la|los|las|un|una|unos|unas)\s+/, '').trim();
}

export function isAnswerCorrect(userInput: string, question: TriviaQuestion): boolean {
  const normUser = normalizeAnswer(userInput);
  if (!normUser) return false;

  const normUserNoArticle = stripLeadingArticle(normUser);
  const candidates = [question.displayAnswer, ...question.acceptedAnswers];

  return candidates.some((candidate) => {
    const normCand = normalizeAnswer(candidate);
    const normCandNoArticle = stripLeadingArticle(normCand);
    return (
      normUser === normCand ||
      (normUserNoArticle.length > 0 && normUserNoArticle === normCandNoArticle)
    );
  });
}

export const QUESTIONS_BANK: TriviaQuestion[] = [
  // ================= HISTORIA =================
  // Fácil (7)
  {
    id: 'hist-e1',
    category: 'historia',
    difficulty: 'easy',
    prompt: '¿En qué año llegó Cristóbal Colón a América?',
    displayAnswer: '1492',
    acceptedAnswers: ['1492'],
  },
  {
    id: 'hist-e2',
    category: 'historia',
    difficulty: 'easy',
    prompt: '¿Qué barco de pasajeros se hundió en 1912 tras chocar con un iceberg?',
    displayAnswer: 'Titanic',
    acceptedAnswers: ['titanic', 'rms titanic'],
  },
  {
    id: 'hist-e3',
    category: 'historia',
    difficulty: 'easy',
    prompt: '¿Quién fue el primer presidente de Estados Unidos?',
    displayAnswer: 'George Washington',
    acceptedAnswers: ['george washington', 'washington'],
  },
  {
    id: 'hist-e4',
    category: 'historia',
    difficulty: 'easy',
    prompt: '¿Qué civilización construyó Machu Picchu en los Andes?',
    displayAnswer: 'Inca',
    acceptedAnswers: ['inca', 'incas', 'imperio inca', 'civilizacion inca'],
  },
  {
    id: 'hist-e5',
    category: 'historia',
    difficulty: 'easy',
    prompt: '¿En qué año llegó el ser humano a la Luna por primera vez?',
    displayAnswer: '1969',
    acceptedAnswers: ['1969'],
  },
  {
    id: 'hist-e6',
    category: 'historia',
    difficulty: 'easy',
    prompt: '¿Qué famosa reina gobernó el Antiguo Egipto y se alió con Marco Antonio?',
    displayAnswer: 'Cleopatra',
    acceptedAnswers: ['cleopatra', 'cleopatra vii'],
  },
  {
    id: 'hist-e7',
    category: 'historia',
    difficulty: 'easy',
    prompt: '¿En qué año terminó la Segunda Guerra Mundial?',
    displayAnswer: '1945',
    acceptedAnswers: ['1945'],
  },
  // Medio (7)
  {
    id: 'hist-m1',
    category: 'historia',
    difficulty: 'medium',
    prompt: '¿En qué año inició la Revolución Mexicana?',
    displayAnswer: '1910',
    acceptedAnswers: ['1910'],
  },
  {
    id: 'hist-m2',
    category: 'historia',
    difficulty: 'medium',
    prompt: '¿En qué país comenzó la Revolución Industrial en el siglo XVIII?',
    displayAnswer: 'Inglaterra (Reino Unido)',
    acceptedAnswers: ['inglaterra', 'reino unido', 'gran bretana'],
  },
  {
    id: 'hist-m3',
    category: 'historia',
    difficulty: 'medium',
    prompt: '¿En qué año cayó el Muro de Berlín?',
    displayAnswer: '1989',
    acceptedAnswers: ['1989'],
  },
  {
    id: 'hist-m4',
    category: 'historia',
    difficulty: 'medium',
    prompt: '¿Cuál era la capital del Imperio Mexica (Azteca)?',
    displayAnswer: 'Tenochtitlan',
    acceptedAnswers: ['tenochtitlan', 'mexico tenochtitlan'],
  },
  {
    id: 'hist-m5',
    category: 'historia',
    difficulty: 'medium',
    prompt: '¿Qué emperador francés fue derrotado definitivamente en Waterloo?',
    displayAnswer: 'Napoleón Bonaparte',
    acceptedAnswers: ['napoleon bonaparte', 'napoleon'],
  },
  {
    id: 'hist-m6',
    category: 'historia',
    difficulty: 'medium',
    prompt: '¿Quién inventó la imprenta de tipos móviles en Europa alrededor de 1440?',
    displayAnswer: 'Johannes Gutenberg',
    acceptedAnswers: ['johannes gutenberg', 'gutenberg'],
  },
  {
    id: 'hist-m7',
    category: 'historia',
    difficulty: 'medium',
    prompt: '¿Qué líder sudafricano luchó contra el apartheid y llegó a ser presidente en 1994?',
    displayAnswer: 'Nelson Mandela',
    acceptedAnswers: ['nelson mandela', 'mandela'],
  },
  // Difícil (7)
  {
    id: 'hist-h1',
    category: 'historia',
    difficulty: 'hard',
    prompt: '¿Qué ciudad fue destruida por la erupción del monte Vesubio en el año 79 d. C.?',
    displayAnswer: 'Pompeya',
    acceptedAnswers: ['pompeya'],
  },
  {
    id: 'hist-h2',
    category: 'historia',
    difficulty: 'hard',
    prompt: '¿Qué antiguo pueblo mesopotámico desarrolló la escritura cuneiforme?',
    displayAnswer: 'Sumerios',
    acceptedAnswers: ['sumerios', 'sumeria', 'los sumerios'],
  },
  {
    id: 'hist-h3',
    category: 'historia',
    difficulty: 'hard',
    prompt: '¿En qué tratado de 1494 España y Portugal se repartieron las tierras descubiertas?',
    displayAnswer: 'Tratado de Tordesillas',
    acceptedAnswers: ['tordesillas', 'tratado de tordesillas'],
  },
  {
    id: 'hist-h4',
    category: 'historia',
    difficulty: 'hard',
    prompt: '¿En qué ciudad se firmó la Declaración de Independencia de Estados Unidos?',
    displayAnswer: 'Filadelfia',
    acceptedAnswers: ['filadelfia', 'philadelphia'],
  },
  {
    id: 'hist-h5',
    category: 'historia',
    difficulty: 'hard',
    prompt: '¿Qué emperador romano legalizó el cristianismo mediante el Edicto de Milán en el año 313?',
    displayAnswer: 'Constantino I',
    acceptedAnswers: ['constantino', 'constantino i', 'constantino el grande'],
  },
  {
    id: 'hist-h6',
    category: 'historia',
    difficulty: 'hard',
    prompt: '¿Qué guerra enfrentó a las casas de Lancaster y York en Inglaterra en el siglo XV?',
    displayAnswer: 'Guerra de las Dos Rosas',
    acceptedAnswers: ['guerra de las dos rosas', 'las dos rosas', 'guerra de las rosas'],
  },
  {
    id: 'hist-h7',
    category: 'historia',
    difficulty: 'hard',
    prompt: '¿En qué año se promulgó la Carta Magna en Inglaterra bajo el rey Juan Sin Tierra?',
    displayAnswer: '1215',
    acceptedAnswers: ['1215'],
  },

  // ================= MATEMÁTICAS =================
  // Fácil (7)
  {
    id: 'mat-e1',
    category: 'matematicas',
    difficulty: 'easy',
    prompt: '¿Cuál es el resultado de 12 × 12?',
    displayAnswer: '144',
    acceptedAnswers: ['144', 'ciento cuarenta y cuatro'],
  },
  {
    id: 'mat-e2',
    category: 'matematicas',
    difficulty: 'easy',
    prompt: '¿Cuánto suman los ángulos internos de cualquier triángulo (en grados)?',
    displayAnswer: '180',
    acceptedAnswers: ['180', '180 grados', 'ciento ochenta'],
  },
  {
    id: 'mat-e3',
    category: 'matematicas',
    difficulty: 'easy',
    prompt: '¿Cuántos lados tiene un hexágono?',
    displayAnswer: '6',
    acceptedAnswers: ['6', 'seis'],
  },
  {
    id: 'mat-e4',
    category: 'matematicas',
    difficulty: 'easy',
    prompt: '¿Cuánto es el 50% de 180?',
    displayAnswer: '90',
    acceptedAnswers: ['90', 'noventa'],
  },
  {
    id: 'mat-e5',
    category: 'matematicas',
    difficulty: 'easy',
    prompt: '¿Cómo se llama el triángulo que tiene sus tres lados de igual longitud?',
    displayAnswer: 'Equilátero',
    acceptedAnswers: ['equilatero', 'triangulo equilatero'],
  },
  {
    id: 'mat-e6',
    category: 'matematicas',
    difficulty: 'easy',
    prompt: '¿Cuántos minutos hay en 3 horas y media?',
    displayAnswer: '210',
    acceptedAnswers: ['210', '210 minutos', 'doscientos diez'],
  },
  {
    id: 'mat-e7',
    category: 'matematicas',
    difficulty: 'easy',
    prompt: '¿Cuál es el resultado de 7 × 8 - 6?',
    displayAnswer: '50',
    acceptedAnswers: ['50', 'cincuenta'],
  },
  // Medio (7)
  {
    id: 'mat-m1',
    category: 'matematicas',
    difficulty: 'medium',
    prompt: '¿Cuál es el único número primo que es par?',
    displayAnswer: '2',
    acceptedAnswers: ['2', 'dos'],
  },
  {
    id: 'mat-m2',
    category: 'matematicas',
    difficulty: 'medium',
    prompt: '¿Cuál es la raíz cuadrada de 169?',
    displayAnswer: '13',
    acceptedAnswers: ['13', 'trece'],
  },
  {
    id: 'mat-m3',
    category: 'matematicas',
    difficulty: 'medium',
    prompt: 'Si un producto cuesta 200 pesos y tiene 25% de descuento, ¿cuánto pagas?',
    displayAnswer: '150',
    acceptedAnswers: ['150', '150 pesos', 'ciento cincuenta'],
  },
  {
    id: 'mat-m4',
    category: 'matematicas',
    difficulty: 'medium',
    prompt: '¿Qué número sigue en la sucesión de Fibonacci: 1, 1, 2, 3, 5, 8, 13, ...?',
    displayAnswer: '21',
    acceptedAnswers: ['21', 'veintiuno'],
  },
  {
    id: 'mat-m5',
    category: 'matematicas',
    difficulty: 'medium',
    prompt: '¿Cuál es el perímetro de un cuadrado cuya área es 49 cm² (en cm)?',
    displayAnswer: '28',
    acceptedAnswers: ['28', '28 cm', 'veintiocho'],
  },
  {
    id: 'mat-m6',
    category: 'matematicas',
    difficulty: 'medium',
    prompt: '¿Cuál es el valor de x en la ecuación 3x - 6 = 15?',
    displayAnswer: '7',
    acceptedAnswers: ['7', 'siete', 'x=7', 'x = 7'],
  },
  {
    id: 'mat-m7',
    category: 'matematicas',
    difficulty: 'medium',
    prompt: '¿Cuántos lados tiene un dodecágono?',
    displayAnswer: '12',
    acceptedAnswers: ['12', 'doce'],
  },
  // Difícil (7)
  {
    id: 'mat-h1',
    category: 'matematicas',
    difficulty: 'hard',
    prompt: '¿Cuánto es 5! (factorial de 5) más 4! (factorial de 4)?',
    displayAnswer: '144',
    acceptedAnswers: ['144', 'ciento cuarenta y cuatro'],
  },
  {
    id: 'mat-h2',
    category: 'matematicas',
    difficulty: 'hard',
    prompt: '¿Cuál es el máximo común divisor de 84 y 126?',
    displayAnswer: '42',
    acceptedAnswers: ['42', 'cuarenta y dos'],
  },
  {
    id: 'mat-h3',
    category: 'matematicas',
    difficulty: 'hard',
    prompt: '¿Cuál es el logaritmo en base 2 de 256?',
    displayAnswer: '8',
    acceptedAnswers: ['8', 'ocho'],
  },
  {
    id: 'mat-h4',
    category: 'matematicas',
    difficulty: 'hard',
    prompt: '¿Cuánto vale la suma de los primeros 10 números naturales (del 1 al 10)?',
    displayAnswer: '55',
    acceptedAnswers: ['55', 'cincuenta y cinco'],
  },
  {
    id: 'mat-h5',
    category: 'matematicas',
    difficulty: 'hard',
    prompt: '¿Cuál es la derivada de f(x) = x³ evaluada en x = 4?',
    displayAnswer: '48',
    acceptedAnswers: ['48', 'cuarenta y ocho'],
  },
  {
    id: 'mat-h6',
    category: 'matematicas',
    difficulty: 'hard',
    prompt: '¿Cómo se llama el poliedro regular de 20 caras triangulares?',
    displayAnswer: 'Icosaedro',
    acceptedAnswers: ['icosaedro'],
  },
  {
    id: 'mat-h7',
    category: 'matematicas',
    difficulty: 'hard',
    prompt: 'Si lanzas dos dados de 6 caras, ¿cuántas combinaciones posibles suman exactamente 7?',
    displayAnswer: '6',
    acceptedAnswers: ['6', 'seis'],
  },

  // ================= FILOSOFÍA =================
  // Fácil (7)
  {
    id: 'fil-e1',
    category: 'filosofia',
    difficulty: 'easy',
    prompt: '¿Qué filósofo escribió la famosa frase "Solo sé que no sé nada"?',
    displayAnswer: 'Sócrates',
    acceptedAnswers: ['socrates'],
  },
  {
    id: 'fil-e2',
    category: 'filosofia',
    difficulty: 'easy',
    prompt: '¿Quién formuló el célebre "Pienso, luego existo"?',
    displayAnswer: 'René Descartes',
    acceptedAnswers: ['rene descartes', 'descartes'],
  },
  {
    id: 'fil-e3',
    category: 'filosofia',
    difficulty: 'easy',
    prompt: '¿Qué filósofo griego propuso la "Alegoría de la caverna"?',
    displayAnswer: 'Platón',
    acceptedAnswers: ['platon'],
  },
  {
    id: 'fil-e4',
    category: 'filosofia',
    difficulty: 'easy',
    prompt: '¿Cómo se llama la rama de la filosofía que estudia la moral, el bien y el mal?',
    displayAnswer: 'Ética',
    acceptedAnswers: ['etica'],
  },
  {
    id: 'fil-e5',
    category: 'filosofia',
    difficulty: 'easy',
    prompt: '¿Quién fue el maestro de Alejandro Magno y fundador del Liceo en Atenas?',
    displayAnswer: 'Aristóteles',
    acceptedAnswers: ['aristoteles'],
  },
  {
    id: 'fil-e6',
    category: 'filosofia',
    difficulty: 'easy',
    prompt: '¿Cómo se llama la rama de la filosofía que estudia la belleza y el arte?',
    displayAnswer: 'Estética',
    acceptedAnswers: ['estetica'],
  },
  {
    id: 'fil-e7',
    category: 'filosofia',
    difficulty: 'easy',
    prompt: '¿Qué pensador chino es autor de las enseñanzas conocidas como "Analectas"?',
    displayAnswer: 'Confucio',
    acceptedAnswers: ['confucio'],
  },
  // Medio (7)
  {
    id: 'fil-m1',
    category: 'filosofia',
    difficulty: 'medium',
    prompt: '¿Qué filósofo alemán escribió "Así habló Zaratustra"?',
    displayAnswer: 'Friedrich Nietzsche',
    acceptedAnswers: ['friedrich nietzsche', 'nietzsche'],
  },
  {
    id: 'fil-m2',
    category: 'filosofia',
    difficulty: 'medium',
    prompt: '¿Qué filósofo italiano del Renacimiento escribió "El príncipe"?',
    displayAnswer: 'Nicolás Maquiavelo',
    acceptedAnswers: ['nicolas maquiavelo', 'maquiavelo'],
  },
  {
    id: 'fil-m3',
    category: 'filosofia',
    difficulty: 'medium',
    prompt: '¿Qué método socrático consiste en hacer preguntas para que el interlocutor descubra la verdad?',
    displayAnswer: 'Mayéutica',
    acceptedAnswers: ['mayeutica'],
  },
  {
    id: 'fil-m4',
    category: 'filosofia',
    difficulty: 'medium',
    prompt: '¿Qué filósofa francesa escribió "El segundo sexo"?',
    displayAnswer: 'Simone de Beauvoir',
    acceptedAnswers: ['simone de beauvoir', 'beauvoir', 'de beauvoir'],
  },
  {
    id: 'fil-m5',
    category: 'filosofia',
    difficulty: 'medium',
    prompt: '¿Qué filósofo francés dijo "El hombre está condenado a ser libre"?',
    displayAnswer: 'Jean-Paul Sartre',
    acceptedAnswers: ['jean paul sartre', 'sartre', 'jean-paul sartre'],
  },
  {
    id: 'fil-m6',
    category: 'filosofia',
    difficulty: 'medium',
    prompt: '¿Qué corriente filosófica sostiene que todo conocimiento proviene de la experiencia sensorial?',
    displayAnswer: 'Empirismo',
    acceptedAnswers: ['empirismo'],
  },
  {
    id: 'fil-m7',
    category: 'filosofia',
    difficulty: 'medium',
    prompt: '¿Qué filósofo griego vivió en un tonel y rechazaba las convenciones sociales?',
    displayAnswer: 'Diógenes',
    acceptedAnswers: ['diogenes', 'diogenes de sinope', 'diogenes el cinico'],
  },
  // Difícil (7)
  {
    id: 'fil-h1',
    category: 'filosofia',
    difficulty: 'hard',
    prompt: '¿Qué filósofo prusiano formuló el "imperativo categórico"?',
    displayAnswer: 'Immanuel Kant',
    acceptedAnswers: ['immanuel kant', 'kant', 'manuel kant'],
  },
  {
    id: 'fil-h2',
    category: 'filosofia',
    difficulty: 'hard',
    prompt: '¿Cómo se llama la rama de la filosofía que estudia el conocimiento, su origen y validez?',
    displayAnswer: 'Epistemología',
    acceptedAnswers: ['epistemologia', 'gnoseologia', 'teoria del conocimiento'],
  },
  {
    id: 'fil-h3',
    category: 'filosofia',
    difficulty: 'hard',
    prompt: '¿Qué escuela filosófica antigua fundó Zenón de Citio, enfocada en el autocontrol y la virtud?',
    displayAnswer: 'Estoicismo',
    acceptedAnswers: ['estoicismo', 'estoica', 'escuela estoica'],
  },
  {
    id: 'fil-h4',
    category: 'filosofia',
    difficulty: 'hard',
    prompt: '¿Qué filósofo presocrático afirmó que "nadie se baña dos veces en el mismo río"?',
    displayAnswer: 'Heráclito',
    acceptedAnswers: ['heraclito', 'heraclito de efeso'],
  },
  {
    id: 'fil-h5',
    category: 'filosofia',
    difficulty: 'hard',
    prompt: '¿Qué filósofo inglés escribió "Leviatán" en 1651 sobre el contrato social?',
    displayAnswer: 'Thomas Hobbes',
    acceptedAnswers: ['thomas hobbes', 'hobbes'],
  },
  {
    id: 'fil-h6',
    category: 'filosofia',
    difficulty: 'hard',
    prompt: '¿Qué filósofo austríaco publicó el "Tractatus Logico-Philosophicus"?',
    displayAnswer: 'Ludwig Wittgenstein',
    acceptedAnswers: ['ludwig wittgenstein', 'wittgenstein'],
  },
  {
    id: 'fil-h7',
    category: 'filosofia',
    difficulty: 'hard',
    prompt: '¿Qué filósofo neerlandés de origen sefardí escribió "Ética demostrada según el orden geométrico"?',
    displayAnswer: 'Baruch Spinoza',
    acceptedAnswers: ['spinoza', 'baruch spinoza'],
  },

  // ================= CIENCIAS =================
  // Fácil (7)
  {
    id: 'cie-e1',
    category: 'ciencias',
    difficulty: 'easy',
    prompt: '¿Cuál es el planeta más grande del Sistema Solar?',
    displayAnswer: 'Júpiter',
    acceptedAnswers: ['jupiter'],
  },
  {
    id: 'cie-e2',
    category: 'ciencias',
    difficulty: 'easy',
    prompt: '¿Cuál es la estrella más cercana a la Tierra?',
    displayAnswer: 'El Sol',
    acceptedAnswers: ['sol', 'el sol'],
  },
  {
    id: 'cie-e3',
    category: 'ciencias',
    difficulty: 'easy',
    prompt: '¿Cuál es el mamífero más grande que existe en la Tierra?',
    displayAnswer: 'Ballena azul',
    acceptedAnswers: ['ballena azul', 'la ballena azul'],
  },
  {
    id: 'cie-e4',
    category: 'ciencias',
    difficulty: 'easy',
    prompt: '¿A qué temperatura hierve el agua al nivel del mar en grados Celsius?',
    displayAnswer: '100',
    acceptedAnswers: ['100', '100 grados', 'cien', '100 c'],
  },
  {
    id: 'cie-e5',
    category: 'ciencias',
    difficulty: 'easy',
    prompt: '¿Qué gas necesitan las plantas para realizar la fotosíntesis?',
    displayAnswer: 'Dióxido de carbono (CO2)',
    acceptedAnswers: ['dioxido de carbono', 'co2', 'anhidrido carbonico'],
  },
  {
    id: 'cie-e6',
    category: 'ciencias',
    difficulty: 'easy',
    prompt: '¿Cuál es el hueso más largo del cuerpo humano?',
    displayAnswer: 'Fémur',
    acceptedAnswers: ['femur'],
  },
  {
    id: 'cie-e7',
    category: 'ciencias',
    difficulty: 'easy',
    prompt: '¿Cuántos huesos tiene aproximadamente el cuerpo humano adulto?',
    displayAnswer: '206',
    acceptedAnswers: ['206', 'doscientos seis'],
  },
  // Medio (7)
  {
    id: 'cie-m1',
    category: 'ciencias',
    difficulty: 'medium',
    prompt: '¿Cuál es el símbolo químico del oro en la tabla periódica?',
    displayAnswer: 'Au',
    acceptedAnswers: ['au'],
  },
  {
    id: 'cie-m2',
    category: 'ciencias',
    difficulty: 'medium',
    prompt: '¿Qué elemento químico tiene el símbolo Fe?',
    displayAnswer: 'Hierro',
    acceptedAnswers: ['hierro', 'fierro'],
  },
  {
    id: 'cie-m3',
    category: 'ciencias',
    difficulty: 'medium',
    prompt: '¿Qué organelo celular produce la mayor parte de la energía (ATP) de la célula?',
    displayAnswer: 'Mitocondria',
    acceptedAnswers: ['mitocondria', 'mitocondrias'],
  },
  {
    id: 'cie-m4',
    category: 'ciencias',
    difficulty: 'medium',
    prompt: '¿Qué científico propuso la teoría de la evolución por selección natural?',
    displayAnswer: 'Charles Darwin',
    acceptedAnswers: ['charles darwin', 'darwin'],
  },
  {
    id: 'cie-m5',
    category: 'ciencias',
    difficulty: 'medium',
    prompt: '¿Qué órgano del cuerpo humano produce la insulina?',
    displayAnswer: 'Páncreas',
    acceptedAnswers: ['pancreas'],
  },
  {
    id: 'cie-m6',
    category: 'ciencias',
    difficulty: 'medium',
    prompt: '¿Qué física ganó dos premios Nobel: uno en Física y otro en Química?',
    displayAnswer: 'Marie Curie',
    acceptedAnswers: ['marie curie', 'curie', 'maria curie'],
  },
  {
    id: 'cie-m7',
    category: 'ciencias',
    difficulty: 'medium',
    prompt: '¿Cuál es el gas más abundante en la atmósfera terrestre?',
    displayAnswer: 'Nitrógeno',
    acceptedAnswers: ['nitrogeno', 'n2'],
  },
  // Difícil (7)
  {
    id: 'cie-h1',
    category: 'ciencias',
    difficulty: 'hard',
    prompt: '¿Cuál es el metal más abundante en la corteza terrestre?',
    displayAnswer: 'Aluminio',
    acceptedAnswers: ['aluminio'],
  },
  {
    id: 'cie-h2',
    category: 'ciencias',
    difficulty: 'hard',
    prompt: '¿Cómo se llama el cambio de estado de sólido directamente a gas sin pasar por líquido?',
    displayAnswer: 'Sublimación',
    acceptedAnswers: ['sublimacion'],
  },
  {
    id: 'cie-h3',
    category: 'ciencias',
    difficulty: 'hard',
    prompt: '¿Qué científico descubrió la penicilina en 1928?',
    displayAnswer: 'Alexander Fleming',
    acceptedAnswers: ['alexander fleming', 'fleming'],
  },
  {
    id: 'cie-h4',
    category: 'ciencias',
    difficulty: 'hard',
    prompt: '¿Qué partícula elemental media la interacción electromagnética y forma la luz?',
    displayAnswer: 'Fotón',
    acceptedAnswers: ['foton', 'fotones'],
  },
  {
    id: 'cie-h5',
    category: 'ciencias',
    difficulty: 'hard',
    prompt: '¿Cuál es el número atómico del carbono en la tabla periódica?',
    displayAnswer: '6',
    acceptedAnswers: ['6', 'seis'],
  },
  {
    id: 'cie-h6',
    category: 'ciencias',
    difficulty: 'hard',
    prompt: '¿Qué astrónomo formuló las tres leyes del movimiento planetario en el siglo XVII?',
    displayAnswer: 'Johannes Kepler',
    acceptedAnswers: ['johannes kepler', 'kepler'],
  },
  {
    id: 'cie-h7',
    category: 'ciencias',
    difficulty: 'hard',
    prompt: '¿Qué proteína transporta el oxígeno en los glóbulos rojos de la sangre?',
    displayAnswer: 'Hemoglobina',
    acceptedAnswers: ['hemoglobina'],
  },

  // ================= ARTE =================
  // Fácil (7)
  {
    id: 'art-e1',
    category: 'arte',
    difficulty: 'easy',
    prompt: '¿Quién pintó "La noche estrellada"?',
    displayAnswer: 'Vincent van Gogh',
    acceptedAnswers: ['vincent van gogh', 'van gogh'],
  },
  {
    id: 'art-e2',
    category: 'arte',
    difficulty: 'easy',
    prompt: '¿En qué museo de París se exhibe "La Mona Lisa"?',
    displayAnswer: 'Museo del Louvre',
    acceptedAnswers: ['louvre', 'museo del louvre', 'el louvre'],
  },
  {
    id: 'art-e3',
    category: 'arte',
    difficulty: 'easy',
    prompt: '¿Qué pintora mexicana es célebre por sus autorretratos y su Casa Azul en Coyoacán?',
    displayAnswer: 'Frida Kahlo',
    acceptedAnswers: ['frida kahlo', 'kahlo'],
  },
  {
    id: 'art-e4',
    category: 'arte',
    difficulty: 'easy',
    prompt: '¿Quién pintó "La última cena" en Milán?',
    displayAnswer: 'Leonardo da Vinci',
    acceptedAnswers: ['leonardo da vinci', 'da vinci', 'leonardo'],
  },
  {
    id: 'art-e5',
    category: 'arte',
    difficulty: 'easy',
    prompt: '¿Cuántas cuerdas tiene normalmente un violín estándar?',
    displayAnswer: '4',
    acceptedAnswers: ['4', 'cuatro'],
  },
  {
    id: 'art-e6',
    category: 'arte',
    difficulty: 'easy',
    prompt: '¿Quién compuso la "Novena Sinfonía" y "Para Elisa"?',
    displayAnswer: 'Ludwig van Beethoven',
    acceptedAnswers: ['beethoven', 'ludwig van beethoven'],
  },
  {
    id: 'art-e7',
    category: 'arte',
    difficulty: 'easy',
    prompt: '¿Qué pintor español creó el famoso cuadro "Guernica"?',
    displayAnswer: 'Pablo Picasso',
    acceptedAnswers: ['pablo picasso', 'picasso'],
  },
  // Medio (7)
  {
    id: 'art-m1',
    category: 'arte',
    difficulty: 'medium',
    prompt: '¿Quién esculpió el famoso "David" de mármol en Florencia?',
    displayAnswer: 'Miguel Ángel',
    acceptedAnswers: ['miguel angel', 'michelangelo', 'buonarroti'],
  },
  {
    id: 'art-m2',
    category: 'arte',
    difficulty: 'medium',
    prompt: '¿Qué movimiento artístico lideró Salvador Dalí con relojes derretidos y paisajes oníricos?',
    displayAnswer: 'Surrealismo',
    acceptedAnswers: ['surrealismo'],
  },
  {
    id: 'art-m3',
    category: 'arte',
    difficulty: 'medium',
    prompt: '¿Quién es el autor de la pintura "El grito"?',
    displayAnswer: 'Edvard Munch',
    acceptedAnswers: ['edvard munch', 'munch'],
  },
  {
    id: 'art-m4',
    category: 'arte',
    difficulty: 'medium',
    prompt: '¿Qué arquitecto catalán diseñó la Basílica de la Sagrada Familia en Barcelona?',
    displayAnswer: 'Antoni Gaudí',
    acceptedAnswers: ['antoni gaudi', 'antonio gaudi', 'gaudi'],
  },
  {
    id: 'art-m5',
    category: 'arte',
    difficulty: 'medium',
    prompt: '¿Qué escultor francés creó la obra "El pensador"?',
    displayAnswer: 'Auguste Rodin',
    acceptedAnswers: ['auguste rodin', 'rodin'],
  },
  {
    id: 'art-m6',
    category: 'arte',
    difficulty: 'medium',
    prompt: '¿Quién pintó "Las meninas"?',
    displayAnswer: 'Diego Velázquez',
    acceptedAnswers: ['diego velazquez', 'velazquez'],
  },
  {
    id: 'art-m7',
    category: 'arte',
    difficulty: 'medium',
    prompt: '¿Qué artista estadounidense es ícono del Pop Art por sus latas de sopa Campbell?',
    displayAnswer: 'Andy Warhol',
    acceptedAnswers: ['andy warhol', 'warhol'],
  },
  // Difícil (7)
  {
    id: 'art-h1',
    category: 'arte',
    difficulty: 'hard',
    prompt: '¿Qué pintor neerlandés realizó "La joven de la perla"?',
    displayAnswer: 'Johannes Vermeer',
    acceptedAnswers: ['johannes vermeer', 'vermeer', 'jan vermeer'],
  },
  {
    id: 'art-h2',
    category: 'arte',
    difficulty: 'hard',
    prompt: '¿Quién pintó "El nacimiento de Venus"?',
    displayAnswer: 'Sandro Botticelli',
    acceptedAnswers: ['sandro botticelli', 'botticelli'],
  },
  {
    id: 'art-h3',
    category: 'arte',
    difficulty: 'hard',
    prompt: '¿Qué técnica pictórica mezcla pigmentos con agua sobre yeso húmedo en una pared?',
    displayAnswer: 'Fresco',
    acceptedAnswers: ['fresco', 'pintura al fresco'],
  },
  {
    id: 'art-h4',
    category: 'arte',
    difficulty: 'hard',
    prompt: '¿Qué pintor flamenco del Renacimiento creó el tríptico "El jardín de las delicias"?',
    displayAnswer: 'El Bosco',
    acceptedAnswers: ['el bosco', 'bosco', 'hieronymus bosch', 'jheronimus bosch'],
  },
  {
    id: 'art-h5',
    category: 'arte',
    difficulty: 'hard',
    prompt: '¿Qué estilo arquitectónico se caracteriza por arcos apuntados, bóvedas de crucería y arbotantes?',
    displayAnswer: 'Gótico',
    acceptedAnswers: ['gotico', 'arte gotico', 'arquitectura gotica'],
  },
  {
    id: 'art-h6',
    category: 'arte',
    difficulty: 'hard',
    prompt: '¿Qué pintor ruso es considerado uno de los pioneros del arte abstracto y escribió "De lo espiritual en el arte"?',
    displayAnswer: 'Vasili Kandinski',
    acceptedAnswers: ['kandinski', 'kandinsky', 'vasili kandinski', 'wassily kandinsky'],
  },
  {
    id: 'art-h7',
    category: 'arte',
    difficulty: 'hard',
    prompt: '¿En qué siglo vivió y compuso Antonio Vivaldi "Las cuatro estaciones"?',
    displayAnswer: 'Siglo XVIII',
    acceptedAnswers: ['xviii', 'siglo xviii', '18', 'siglo 18'],
  },

  // ================= CULTURA GENERAL =================
  // Fácil (7)
  {
    id: 'cul-e1',
    category: 'cultura_general',
    difficulty: 'easy',
    prompt: '¿Quién escribió "Don Quijote de la Mancha"?',
    displayAnswer: 'Miguel de Cervantes',
    acceptedAnswers: ['miguel de cervantes', 'cervantes', 'miguel de cervantes saavedra'],
  },
  {
    id: 'cul-e2',
    category: 'cultura_general',
    difficulty: 'easy',
    prompt: '¿Cuántos anillos tiene la bandera olímpica?',
    displayAnswer: '5',
    acceptedAnswers: ['5', 'cinco'],
  },
  {
    id: 'cul-e3',
    category: 'cultura_general',
    difficulty: 'easy',
    prompt: '¿Cuál es el idioma oficial de Brasil?',
    displayAnswer: 'Portugués',
    acceptedAnswers: ['portugues'],
  },
  {
    id: 'cul-e4',
    category: 'cultura_general',
    difficulty: 'easy',
    prompt: '¿Cuántos días tiene un año bisiesto?',
    displayAnswer: '366',
    acceptedAnswers: ['366', 'trescientos sesenta y seis'],
  },
  {
    id: 'cul-e5',
    category: 'cultura_general',
    difficulty: 'easy',
    prompt: '¿Qué fruta se utiliza tradicionalmente para elaborar la sidra?',
    displayAnswer: 'Manzana',
    acceptedAnswers: ['manzana', 'manzanas'],
  },
  {
    id: 'cul-e6',
    category: 'cultura_general',
    difficulty: 'easy',
    prompt: '¿Qué empresa creó la consola PlayStation?',
    displayAnswer: 'Sony',
    acceptedAnswers: ['sony'],
  },
  {
    id: 'cul-e7',
    category: 'cultura_general',
    difficulty: 'easy',
    prompt: '¿Qué instrumento musical toca comúnmente Lisa Simpson?',
    displayAnswer: 'Saxofón',
    acceptedAnswers: ['saxofon', 'saxo'],
  },
  // Medio (7)
  {
    id: 'cul-m1',
    category: 'cultura_general',
    difficulty: 'medium',
    prompt: '¿Quién escribió "Cien años de soledad"?',
    displayAnswer: 'Gabriel García Márquez',
    acceptedAnswers: ['gabriel garcia marquez', 'garcia marquez'],
  },
  {
    id: 'cul-m2',
    category: 'cultura_general',
    difficulty: 'medium',
    prompt: '¿En la mitología griega, quién es el dios del mar?',
    displayAnswer: 'Poseidón',
    acceptedAnswers: ['poseidon'],
  },
  {
    id: 'cul-m3',
    category: 'cultura_general',
    difficulty: 'medium',
    prompt: '¿Cuántas casillas tiene un tablero de ajedrez estándar?',
    displayAnswer: '64',
    acceptedAnswers: ['64', 'sesenta y cuatro'],
  },
  {
    id: 'cul-m4',
    category: 'cultura_general',
    difficulty: 'medium',
    prompt: '¿Cuál es la moneda oficial de Japón?',
    displayAnswer: 'Yen',
    acceptedAnswers: ['yen', 'yen japones'],
  },
  {
    id: 'cul-m5',
    category: 'cultura_general',
    difficulty: 'medium',
    prompt: '¿Quién escribió la tragedia "Romeo y Julieta"?',
    displayAnswer: 'William Shakespeare',
    acceptedAnswers: ['william shakespeare', 'shakespeare'],
  },
  {
    id: 'cul-m6',
    category: 'cultura_general',
    difficulty: 'medium',
    prompt: '¿Quién escribió "El principito"?',
    displayAnswer: 'Antoine de Saint-Exupéry',
    acceptedAnswers: ['antoine de saint exupery', 'saint exupery', 'antoine de saint-exupery'],
  },
  {
    id: 'cul-m7',
    category: 'cultura_general',
    difficulty: 'medium',
    prompt: '¿Cómo se llama el libro sagrado del islam?',
    displayAnswer: 'Corán',
    acceptedAnswers: ['coran', 'el coran'],
  },
  // Difícil (7)
  {
    id: 'cul-h1',
    category: 'cultura_general',
    difficulty: 'hard',
    prompt: '¿Cuántas teclas blancas y negras tiene un piano estándar completo?',
    displayAnswer: '88',
    acceptedAnswers: ['88', 'ochenta y ocho'],
  },
  {
    id: 'cul-h2',
    category: 'cultura_general',
    difficulty: 'hard',
    prompt: '¿En qué deporte se utiliza un volante llamado "shuttlecock" o "gallito"?',
    displayAnswer: 'Bádminton',
    acceptedAnswers: ['badminton'],
  },
  {
    id: 'cul-h3',
    category: 'cultura_general',
    difficulty: 'hard',
    prompt: '¿En qué país surgió originalmente el arte marcial del taekwondo?',
    displayAnswer: 'Corea (Corea del Sur)',
    acceptedAnswers: ['corea', 'corea del sur'],
  },
  {
    id: 'cul-h4',
    category: 'cultura_general',
    difficulty: 'hard',
    prompt: '¿Qué escritor irlandés es autor de la novela "Ulises"?',
    displayAnswer: 'James Joyce',
    acceptedAnswers: ['james joyce', 'joyce'],
  },
  {
    id: 'cul-h5',
    category: 'cultura_general',
    difficulty: 'hard',
    prompt: '¿Cómo se llama el sistema de escritura táctil inventado en el siglo XIX para personas ciegas?',
    displayAnswer: 'Braille',
    acceptedAnswers: ['braille', 'sistema braille'],
  },
  {
    id: 'cul-h6',
    category: 'cultura_general',
    difficulty: 'hard',
    prompt: '¿Cuál es el nombre de la espada legendaria del rey Arturo?',
    displayAnswer: 'Excalibur',
    acceptedAnswers: ['excalibur'],
  },
  {
    id: 'cul-h7',
    category: 'cultura_general',
    difficulty: 'hard',
    prompt: '¿Qué premio internacional es considerado el equivalente al Nobel en matemáticas?',
    displayAnswer: 'Medalla Fields',
    acceptedAnswers: ['medalla fields', 'fields'],
  },

  // ================= GEOGRAFÍA =================
  // Fácil (7)
  {
    id: 'geo-e1',
    category: 'geografia',
    difficulty: 'easy',
    prompt: '¿Cuál es el país más grande del mundo por superficie?',
    displayAnswer: 'Rusia',
    acceptedAnswers: ['rusia', 'federacion rusa'],
  },
  {
    id: 'geo-e2',
    category: 'geografia',
    difficulty: 'easy',
    prompt: '¿En qué continente se encuentra el desierto del Sahara?',
    displayAnswer: 'África',
    acceptedAnswers: ['africa'],
  },
  {
    id: 'geo-e3',
    category: 'geografia',
    difficulty: 'easy',
    prompt: '¿Cuál es la capital de Japón?',
    displayAnswer: 'Tokio',
    acceptedAnswers: ['tokio', 'tokyo'],
  },
  {
    id: 'geo-e4',
    category: 'geografia',
    difficulty: 'easy',
    prompt: '¿Qué país tiene forma de bota en el mapa de Europa?',
    displayAnswer: 'Italia',
    acceptedAnswers: ['italia'],
  },
  {
    id: 'geo-e5',
    category: 'geografia',
    difficulty: 'easy',
    prompt: '¿En qué país se encuentran las pirámides de Guiza?',
    displayAnswer: 'Egipto',
    acceptedAnswers: ['egipto'],
  },
  {
    id: 'geo-e6',
    category: 'geografia',
    difficulty: 'easy',
    prompt: '¿Cuál es la capital de Alemania?',
    displayAnswer: 'Berlín',
    acceptedAnswers: ['berlin'],
  },
  {
    id: 'geo-e7',
    category: 'geografia',
    difficulty: 'easy',
    prompt: '¿Cuál es el océano más grande y profundo de la Tierra?',
    displayAnswer: 'Océano Pacífico',
    acceptedAnswers: ['pacifico', 'oceano pacifico'],
  },
  // Medio (7)
  {
    id: 'geo-m1',
    category: 'geografia',
    difficulty: 'medium',
    prompt: '¿Cuál es la capital de Canadá?',
    displayAnswer: 'Ottawa',
    acceptedAnswers: ['ottawa'],
  },
  {
    id: 'geo-m2',
    category: 'geografia',
    difficulty: 'medium',
    prompt: '¿Cuál es la capital de Australia?',
    displayAnswer: 'Canberra',
    acceptedAnswers: ['canberra'],
  },
  {
    id: 'geo-m3',
    category: 'geografia',
    difficulty: 'medium',
    prompt: '¿Cuál es el río más largo de América del Sur?',
    displayAnswer: 'Amazonas',
    acceptedAnswers: ['amazonas', 'rio amazonas'],
  },
  {
    id: 'geo-m4',
    category: 'geografia',
    difficulty: 'medium',
    prompt: '¿Cuál es la montaña más alta del mundo sobre el nivel del mar?',
    displayAnswer: 'Monte Everest',
    acceptedAnswers: ['everest', 'monte everest'],
  },
  {
    id: 'geo-m5',
    category: 'geografia',
    difficulty: 'medium',
    prompt: '¿Cuál es la capital de Colombia?',
    displayAnswer: 'Bogotá',
    acceptedAnswers: ['bogota'],
  },
  {
    id: 'geo-m6',
    category: 'geografia',
    difficulty: 'medium',
    prompt: '¿En qué estado de México está la zona arqueológica de Chichén Itzá?',
    displayAnswer: 'Yucatán',
    acceptedAnswers: ['yucatan'],
  },
  {
    id: 'geo-m7',
    category: 'geografia',
    difficulty: 'medium',
    prompt: '¿Cuál es la capital de Corea del Sur?',
    displayAnswer: 'Seúl',
    acceptedAnswers: ['seul', 'seoul'],
  },
  // Difícil (7)
  {
    id: 'geo-h1',
    category: 'geografia',
    difficulty: 'hard',
    prompt: '¿Qué estrecho separa a Europa (España) de África (Marruecos)?',
    displayAnswer: 'Estrecho de Gibraltar',
    acceptedAnswers: ['gibraltar', 'estrecho de gibraltar'],
  },
  {
    id: 'geo-h2',
    category: 'geografia',
    difficulty: 'hard',
    prompt: '¿Entre qué dos países se encuentra principalmente la cordillera de los Pirineos?',
    displayAnswer: 'España y Francia',
    acceptedAnswers: ['espana y francia', 'francia y espana'],
  },
  {
    id: 'geo-h3',
    category: 'geografia',
    difficulty: 'hard',
    prompt: '¿Cuál es la capital de Suiza (sede del gobierno federal)?',
    displayAnswer: 'Berna',
    acceptedAnswers: ['berna'],
  },
  {
    id: 'geo-h4',
    category: 'geografia',
    difficulty: 'hard',
    prompt: '¿Cuál es la capital de Turquía?',
    displayAnswer: 'Ankara',
    acceptedAnswers: ['ankara'],
  },
  {
    id: 'geo-h5',
    category: 'geografia',
    difficulty: 'hard',
    prompt: '¿Qué lago es el más profundo del mundo y se encuentra en Siberia?',
    displayAnswer: 'Lago Baikal',
    acceptedAnswers: ['baikal', 'lago baikal'],
  },
  {
    id: 'geo-h6',
    category: 'geografia',
    difficulty: 'hard',
    prompt: '¿Cuál es el único país de América del Sur cuyo idioma oficial es el neerlandés?',
    displayAnswer: 'Surinam',
    acceptedAnswers: ['surinam', 'suriname'],
  },
  {
    id: 'geo-h7',
    category: 'geografia',
    difficulty: 'hard',
    prompt: '¿En qué océano se encuentra la Fosa de las Marianas, el punto más profundo conocido?',
    displayAnswer: 'Océano Pacífico',
    acceptedAnswers: ['pacifico', 'oceano pacifico'],
  },
];

export function pickQuestionForCategory(
  category: CategoryId,
  usedIds: Set<string>,
  difficulty: DifficultyLevel = 'medium'
): TriviaQuestion {
  const pool = QUESTIONS_BANK.filter(
    (q) => q.category === category && q.difficulty === difficulty
  );
  const unused = pool.filter((q) => !usedIds.has(q.id));
  const candidates = unused.length > 0 ? unused : pool;
  const idx = Math.floor(Math.random() * candidates.length);
  return candidates[idx];
}

export function pickAnyQuestion(
  usedIds: Set<string>,
  difficulty: DifficultyLevel = 'medium'
): TriviaQuestion {
  const pool = QUESTIONS_BANK.filter((q) => q.difficulty === difficulty);
  const unused = pool.filter((q) => !usedIds.has(q.id));
  const candidates = unused.length > 0 ? unused : pool;
  const idx = Math.floor(Math.random() * candidates.length);
  return candidates[idx];
}

function shuffleStrings(items: string[]): string[] {
  const copy = [...items];
  for (let i = copy.length - 1; i > 0; i--) {
    const j = Math.floor(Math.random() * (i + 1));
    [copy[i], copy[j]] = [copy[j], copy[i]];
  }
  return copy;
}

function classifyAnswerFormat(value: string): 'year' | 'number' | 'text' {
  const trimmed = value.trim();
  if (/^\d{4}$/.test(trimmed)) return 'year';
  if (/^-?\d+([.,]\d+)?$/.test(trimmed)) return 'number';
  return 'text';
}

function buildNumericDistractors(answer: string, kind: 'year' | 'number'): string[] {
  const normalizedNum = Number(answer.trim().replace(',', '.'));
  if (!Number.isFinite(normalizedNum)) return [];

  const isInteger = Number.isInteger(normalizedNum);
  const useComma = answer.includes(',');
  const offsets =
    kind === 'year'
      ? [-24, -12, -5, 4, 9, 17, 32]
      : Math.abs(normalizedNum) <= 15
        ? [-3, -2, -1, 1, 2, 3, 4]
        : [-15, -8, -4, 4, 8, 12, 20];

  const results: string[] = [];
  for (const delta of shuffleStrings(offsets.map(String)).map(Number)) {
    const candidateNum = normalizedNum + delta;
    if (kind === 'year' && (candidateNum < 100 || candidateNum > 2026)) continue;
    if (normalizedNum > 0 && candidateNum <= 0) continue;

    const formatted = isInteger
      ? String(Math.round(candidateNum))
      : useComma
        ? candidateNum.toFixed(2).replace(/\.?0+$/, '').replace('.', ',')
        : candidateNum.toFixed(2).replace(/\.?0+$/, '');

    if (formatted !== answer.trim()) {
      results.push(formatted);
    }
  }
  return results;
}

/**
 * Construye 4 opciones únicas y plausibles (1 correcta + 3 distractores)
 * respetando categoría y formato de respuesta para modo Opción múltiple.
 */
export function buildQuestionOptions(question: TriviaQuestion): string[] {
  const correct = question.displayAnswer;
  const format = classifyAnswerFormat(correct);
  const picked: string[] = [correct];
  const seenNormalized = new Set<string>([normalizeAnswer(correct)]);

  const tryAddCandidate = (raw: string): boolean => {
    const norm = normalizeAnswer(raw);
    if (!norm || seenNormalized.has(norm) || isAnswerCorrect(raw, question)) {
      return false;
    }
    seenNormalized.add(norm);
    picked.push(raw);
    return picked.length >= 4;
  };

  const sameCatSameFormat = shuffleStrings(
    QUESTIONS_BANK.filter(
      (q) =>
        q.id !== question.id &&
        q.category === question.category &&
        classifyAnswerFormat(q.displayAnswer) === format
    ).map((q) => q.displayAnswer)
  );
  for (const cand of sameCatSameFormat) {
    if (tryAddCandidate(cand)) break;
  }

  if (picked.length < 4 && (format === 'year' || format === 'number')) {
    for (const cand of buildNumericDistractors(correct, format)) {
      if (tryAddCandidate(cand)) break;
    }
  }

  if (picked.length < 4) {
    const anyCatSameFormat = shuffleStrings(
      QUESTIONS_BANK.filter(
        (q) =>
          q.id !== question.id && classifyAnswerFormat(q.displayAnswer) === format
      ).map((q) => q.displayAnswer)
    );
    for (const cand of anyCatSameFormat) {
      if (tryAddCandidate(cand)) break;
    }
  }

  if (picked.length < 4) {
    const sameCatAny = shuffleStrings(
      QUESTIONS_BANK.filter(
        (q) => q.id !== question.id && q.category === question.category
      ).map((q) => q.displayAnswer)
    );
    for (const cand of sameCatAny) {
      if (tryAddCandidate(cand)) break;
    }
  }

  if (picked.length < 4) {
    const anyBank = shuffleStrings(
      QUESTIONS_BANK.filter((q) => q.id !== question.id).map((q) => q.displayAnswer)
    );
    for (const cand of anyBank) {
      if (tryAddCandidate(cand)) break;
    }
  }

  return shuffleStrings(picked);
}

