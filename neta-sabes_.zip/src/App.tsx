import { useCallback, useEffect, useRef, useState } from 'react';
import { Bot, Check, Link2, RotateCcw, Sparkles, Swords, Volume2, VolumeX } from 'lucide-react';
import { AchievementToast, AchievementToastItem } from './components/AchievementToast';
import { BoardView } from './components/BoardView';
import { DiceRoller } from './components/DiceRoller';
import { ExtraCardModal } from './components/ExtraCardModal';
import { HowToPlayModal } from './components/HowToPlayModal';
import { MainMenu } from './components/MainMenu';
import { OnlineLobby } from './components/OnlineLobby';
import { PlayerTokenIcon } from './components/PlayerTokenIcon';
import { ProfilesHistoryModal } from './components/ProfilesHistoryModal';
import { QuestionModal } from './components/QuestionModal';
import { ScoreboardPanel } from './components/ScoreboardPanel';
import { PlayerDraft, SetupScreen } from './components/SetupScreen';
import { SplashScreen } from './components/SplashScreen';
import { StarryBackground } from './components/StarryBackground';
import { VictoryModal } from './components/VictoryModal';
import { AchievementId, getAchievementById } from './data/achievements';
import { BOARD_TILES, CATEGORY_META, TOTAL_TILES } from './data/board';
import { pickRandomExtraCard } from './data/extraCards';
import { DIFFICULTY_META, pickAnyQuestion, pickQuestionForCategory } from './data/questions';
import {
  AnswerMode,
  DifficultyLevel,
  ExtraCard,
  GamePhase,
  OnlineRoomSnapshot,
  Player,
  TriviaQuestion,
  TurnEvent,
} from './types/game';
import {
  loadMatchHistory,
  loadProfiles,
  LocalProfile,
  MatchRecord,
  recordCompletedMatch,
  unlockProfileAchievement,
} from './utils/profilesStorage';
import { gameAudio } from './utils/sound';

function generateLocalClientId(): string {
  if (typeof crypto !== 'undefined' && typeof crypto.randomUUID === 'function') {
    return crypto.randomUUID();
  }
  return `client-${Date.now()}-${Math.random().toString(36).slice(2, 10)}`;
}

function readRoomCodeFromUrl(): string {
  if (typeof window === 'undefined') return '';
  const param = new URLSearchParams(window.location.search).get('sala') || '';
  const cleaned = param.toUpperCase().replace(/[^A-Z0-9]/g, '');
  return cleaned.length === 6 ? cleaned : '';
}

export default function App() {
  const [showSplash, setShowSplash] = useState<boolean>(true);
  const [menuView, setMenuView] = useState<'MENU' | 'SETUP'>('MENU');
  const [howToPlayOpen, setHowToPlayOpen] = useState<boolean>(false);
  const [profilesOpen, setProfilesOpen] = useState<boolean>(false);

  const [profiles, setProfiles] = useState<LocalProfile[]>(() => loadProfiles());
  const [matchHistory, setMatchHistory] = useState<MatchRecord[]>(() =>
    loadMatchHistory()
  );
  const profileBindingsRef = useRef<Record<number, string>>({});
  const onlineMyProfileIdRef = useRef<string | undefined>(undefined);
  const recordedMatchKeyRef = useRef<string | null>(null);

  const [playMode, setPlayMode] = useState<'local' | 'online'>('local');
  const [onlineRoom, setOnlineRoom] = useState<OnlineRoomSnapshot | null>(null);
  const [onlineConnecting, setOnlineConnecting] = useState<boolean>(false);
  const [onlineError, setOnlineError] = useState<string | null>(null);
  const [copiedInviteInGame, setCopiedInviteInGame] = useState<boolean>(false);

  const clientIdRef = useRef<string>(generateLocalClientId());
  const sessionTokenRef = useRef<string>('');
  const wsRef = useRef<WebSocket | null>(null);
  const intentionalLeaveRef = useRef<boolean>(false);
  const reconnectTimerRef = useRef<number | null>(null);
  const activeRoomCodeRef = useRef<string | null>(null);
  const prevOnlineSnapshotRef = useRef<OnlineRoomSnapshot | null>(null);

  const [phase, setPhase] = useState<GamePhase>('SETUP');
  const [difficulty, setDifficulty] = useState<DifficultyLevel>('medium');
  const [answerMode, setAnswerMode] = useState<AnswerMode>('multiple_choice');
  const [players, setPlayers] = useState<Player[]>([]);
  const [starterIndex, setStarterIndex] = useState<number>(0);
  const [currentPlayerIndex, setCurrentPlayerIndex] = useState<number>(0);
  const [roundNumber, setRoundNumber] = useState<number>(1);
  const [finalRoundTriggered, setFinalRoundTriggered] = useState<boolean>(false);

  const [diceValue, setDiceValue] = useState<number>(1);
  const [statusMessage, setStatusMessage] = useState<string>('Lanza el dado para avanzar');
  const [events, setEvents] = useState<TurnEvent[]>([]);

  const [activeQuestion, setActiveQuestion] = useState<TriviaQuestion | null>(null);
  const [activeExtraCard, setActiveExtraCard] = useState<ExtraCard | null>(null);
  const [lastExtraCardId, setLastExtraCardId] = useState<string | undefined>(undefined);

  const [tiebreakerIds, setTiebreakerIds] = useState<number[]>([]);
  const [tiebreakerPointer, setTiebreakerPointer] = useState<number>(0);
  const [tiebreakerRound, setTiebreakerRound] = useState<number>(1);
  const [tiebreakerScores, setTiebreakerScores] = useState<Record<number, number>>({});

  const [winnerId, setWinnerId] = useState<number | null>(null);
  const [wonByTiebreaker, setWonByTiebreaker] = useState<boolean>(false);
  const [muted, setMuted] = useState<boolean>(false);
  const [confirmResetOpen, setConfirmResetOpen] = useState<boolean>(false);

  const usedQuestionIdsRef = useRef<Set<string>>(new Set());
  const timersRef = useRef<number[]>([]);
  const initialRoomCode = useRef<string>(readRoomCodeFromUrl());

  const [achievementQueue, setAchievementQueue] = useState<AchievementToastItem[]>([]);
  const streaksRef = useRef<Record<number, number>>({});
  const sessionUnlockedRef = useRef<Set<string>>(new Set());
  const lastChimedToastKeyRef = useRef<string | null>(null);

  const enqueueAchievementToast = useCallback(
    (playerName: string, achievementId: AchievementId) => {
      const def = getAchievementById(achievementId);
      if (!def) return;
      setAchievementQueue((prev) => [
        ...prev,
        {
          key: `${achievementId}-${Date.now()}-${Math.random().toString(36).slice(2, 6)}`,
          achievement: def,
          playerName,
        },
      ]);
    },
    []
  );

  const triggerAchievementForPlayer = useCallback(
    (player: Player, achievementId: AchievementId, explicitProfileId?: string) => {
      if (player.isBot) return;

      const boundId = explicitProfileId ?? profileBindingsRef.current[player.id];
      const matchedProfile =
        boundId ??
        loadProfiles().find(
          (prof) =>
            prof.username.trim().toLowerCase() === player.name.trim().toLowerCase()
        )?.id;

      if (matchedProfile) {
        const { unlockedNow, profiles: updated } = unlockProfileAchievement(
          matchedProfile,
          achievementId
        );
        if (!unlockedNow) return;
        setProfiles(updated);
      } else {
        const sessionKey = `${player.id}:${achievementId}`;
        if (sessionUnlockedRef.current.has(sessionKey)) return;
        sessionUnlockedRef.current.add(sessionKey);
      }

      enqueueAchievementToast(player.name, achievementId);
    },
    [enqueueAchievementToast]
  );

  // Manage Xbox-style bottom-center achievement toast queue & chime sound
  useEffect(() => {
    const active = achievementQueue[0];
    if (!active) {
      lastChimedToastKeyRef.current = null;
      return;
    }
    if (lastChimedToastKeyRef.current !== active.key) {
      lastChimedToastKeyRef.current = active.key;
      gameAudio.playAchievement();
    }
    const timer = window.setTimeout(() => {
      setAchievementQueue((prev) => prev.slice(1));
    }, 4200);
    return () => window.clearTimeout(timer);
  }, [achievementQueue]);

  const clearAllTimers = useCallback(() => {
    timersRef.current.forEach((id) => window.clearTimeout(id));
    timersRef.current = [];
  }, []);

  const closeSocketCleanly = useCallback(() => {
    intentionalLeaveRef.current = true;
    activeRoomCodeRef.current = null;
    sessionTokenRef.current = '';
    if (reconnectTimerRef.current !== null) {
      window.clearTimeout(reconnectTimerRef.current);
      reconnectTimerRef.current = null;
    }
    if (wsRef.current) {
      try {
        wsRef.current.close();
      } catch {
        // ignore close error
      }
      wsRef.current = null;
    }
  }, []);

  useEffect(() => {
    return () => {
      clearAllTimers();
      closeSocketCleanly();
    };
  }, [clearAllTimers, closeSocketCleanly]);

  useEffect(() => {
    if (playMode !== 'online' || !onlineRoom) {
      prevOnlineSnapshotRef.current = null;
      return;
    }
    const prev = prevOnlineSnapshotRef.current;
    prevOnlineSnapshotRef.current = onlineRoom;

    if (onlineRoom.phase === 'LOBBY_WAITING' || onlineRoom.phase === 'STARTER_REVEAL') {
      recordedMatchKeyRef.current = null;
      if (prev?.phase === 'LOBBY_WAITING' && onlineRoom.phase === 'STARTER_REVEAL') {
        streaksRef.current = {};
        sessionUnlockedRef.current.clear();
      }
    }

    const me = onlineRoom.players.find((p) => p.clientId === clientIdRef.current);
    const prevMe = prev?.players.find((p) => p.clientId === clientIdRef.current);
    const myProfileId = onlineMyProfileIdRef.current;

    if (me && prevMe) {
      if (me.completedLap && !prevMe.completedLap) {
        triggerAchievementForPlayer(me, 'complete_lap', myProfileId);
      }
      if (me.score >= 6 && prevMe.score < 6) {
        triggerAchievementForPlayer(me, 'high_scorer', myProfileId);
      }
    }

    if (
      me &&
      onlineRoom.questionResolution &&
      !prev?.questionResolution &&
      onlineRoom.questionResolution.playerId === me.id
    ) {
      if (onlineRoom.questionResolution.correct) {
        const nextStreak = (streaksRef.current[me.id] ?? 0) + 1;
        streaksRef.current[me.id] = nextStreak;
        if (nextStreak >= 3) {
          triggerAchievementForPlayer(me, 'streak_3', myProfileId);
        }
      } else {
        streaksRef.current[me.id] = 0;
      }
    }

    if (onlineRoom.phase === 'GAME_OVER' && onlineRoom.winnerId !== null) {
      const matchKey = `online-${onlineRoom.roomCode}-${onlineRoom.roundNumber}-${onlineRoom.winnerId}`;
      if (recordedMatchKeyRef.current !== matchKey) {
        recordedMatchKeyRef.current = matchKey;
        const bindings: Record<number, string> = {};
        if (myProfileId && me) {
          bindings[me.id] = myProfileId;
        }
        const { newlyUnlockedVeteranIds } = recordCompletedMatch({
          players: onlineRoom.players,
          winnerId: onlineRoom.winnerId,
          wonByTiebreaker: onlineRoom.wonByTiebreaker,
          mode: 'online',
          difficulty: onlineRoom.difficulty,
          profileBindings: bindings,
        });
        setProfiles(loadProfiles());
        setMatchHistory(loadMatchHistory());

        if (me && onlineRoom.winnerId === me.id) {
          triggerAchievementForPlayer(me, 'first_win', myProfileId);
          if (onlineRoom.wonByTiebreaker) {
            triggerAchievementForPlayer(me, 'tiebreaker_champ', myProfileId);
          }
        }
        if (me && myProfileId && newlyUnlockedVeteranIds.includes(myProfileId)) {
          enqueueAchievementToast(me.name, 'veteran_5');
        }
      }
    }

    if (!prev) return;

    if (prev.phase !== 'ROLLING' && onlineRoom.phase === 'ROLLING') {
      gameAudio.playDiceRoll();
    } else if (onlineRoom.phase === 'MOVING') {
      const moved = onlineRoom.players.some(
        (p, idx) => prev.players[idx] && p.position !== prev.players[idx].position
      );
      if (moved) gameAudio.playStep();
    } else if (prev.phase !== 'EXTRA_CARD' && onlineRoom.phase === 'EXTRA_CARD') {
      gameAudio.playExtraCard();
    } else if (prev.phase !== 'GAME_OVER' && onlineRoom.phase === 'GAME_OVER') {
      gameAudio.playVictory();
    }
  }, [onlineRoom, playMode, triggerAchievementForPlayer, enqueueAchievementToast]);

  useEffect(() => {
    if (playMode !== 'local' || phase !== 'GAME_OVER' || winnerId === null) return;
    const matchKey = `local-${roundNumber}-${winnerId}-${players.map((p) => p.score).join('-')}`;
    if (recordedMatchKeyRef.current === matchKey) return;
    recordedMatchKeyRef.current = matchKey;

    const { newlyUnlockedVeteranIds } = recordCompletedMatch({
      players,
      winnerId,
      wonByTiebreaker,
      mode: 'local',
      difficulty,
      profileBindings: profileBindingsRef.current,
    });
    setProfiles(loadProfiles());
    setMatchHistory(loadMatchHistory());

    const winnerPlayer = players.find((p) => p.id === winnerId);
    if (winnerPlayer && !winnerPlayer.isBot) {
      triggerAchievementForPlayer(winnerPlayer, 'first_win');
      if (wonByTiebreaker) {
        triggerAchievementForPlayer(winnerPlayer, 'tiebreaker_champ');
      }
      if (players.some((p) => p.isBot && p.botDifficulty === 'hard')) {
        triggerAchievementForPlayer(winnerPlayer, 'beat_hard_bot');
      }
    }

    if (newlyUnlockedVeteranIds.length > 0) {
      newlyUnlockedVeteranIds.forEach((profId) => {
        const matched = players.find(
          (p) => !p.isBot && profileBindingsRef.current[p.id] === profId
        );
        if (matched) {
          enqueueAchievementToast(matched.name, 'veteran_5');
        }
      });
    }
  }, [
    difficulty,
    phase,
    playMode,
    players,
    roundNumber,
    winnerId,
    wonByTiebreaker,
    triggerAchievementForPlayer,
    enqueueAchievementToast,
  ]);

  const sendWs = useCallback((payload: Record<string, unknown>) => {
    if (wsRef.current && wsRef.current.readyState === WebSocket.OPEN) {
      wsRef.current.send(JSON.stringify(payload));
    }
  }, []);

  const connectAndSend = useCallback(
    (initialPayload: Record<string, unknown>, reconnectAttempt = 0) => {
      setOnlineConnecting(true);
      setOnlineError(null);
      intentionalLeaveRef.current = false;

      if (wsRef.current && wsRef.current.readyState === WebSocket.OPEN) {
        wsRef.current.send(JSON.stringify(initialPayload));
        setOnlineConnecting(false);
        return;
      }

      if (wsRef.current) {
        try {
          wsRef.current.close();
        } catch {
          // ignore
        }
      }

      const protocol = window.location.protocol === 'https:' ? 'wss:' : 'ws:';
      const ws = new WebSocket(`${protocol}//${window.location.host}/ws`);
      wsRef.current = ws;

      ws.onopen = () => {
        ws.send(JSON.stringify(initialPayload));
      };

      ws.onmessage = (ev) => {
        let msg: Record<string, unknown>;
        try {
          msg = JSON.parse(String(ev.data));
        } catch {
          return;
        }

        if (msg.type === 'joined_room') {
          if (typeof msg.clientId === 'string') {
            clientIdRef.current = msg.clientId;
          }
          if (typeof msg.sessionToken === 'string') {
            sessionTokenRef.current = msg.sessionToken;
          }
          const state = msg.state as OnlineRoomSnapshot;
          activeRoomCodeRef.current = state.roomCode;
          setPlayMode('online');
          setOnlineRoom(state);
          setOnlineConnecting(false);
          setOnlineError(null);
          return;
        }

        if (msg.type === 'room_state') {
          const state = msg.state as OnlineRoomSnapshot;
          setOnlineRoom(state);
          setOnlineConnecting(false);
          return;
        }

        if (msg.type === 'error') {
          setOnlineConnecting(false);
          setOnlineError(
            typeof msg.message === 'string'
              ? msg.message
              : 'Ocurrió un error de conexión.'
          );
        }
      };

      ws.onerror = () => {
        setOnlineConnecting(false);
      };

      ws.onclose = () => {
        if (intentionalLeaveRef.current) return;
        if (!activeRoomCodeRef.current) {
          setOnlineConnecting(false);
          return;
        }

        const delay = Math.min(5000, 1000 * Math.pow(2, reconnectAttempt));
        reconnectTimerRef.current = window.setTimeout(() => {
          if (!intentionalLeaveRef.current && activeRoomCodeRef.current) {
            connectAndSend(
              {
                type: 'join_room',
                roomCode: activeRoomCodeRef.current,
                clientId: clientIdRef.current,
                sessionToken: sessionTokenRef.current,
              },
              reconnectAttempt + 1
            );
          }
        }, delay);
      };
    },
    []
  );

  const handleCreateOnlineRoom = useCallback(
    (
      playerName: string,
      colorId: string,
      chosenDifficulty: DifficultyLevel,
      chosenAnswerMode: AnswerMode,
      profileId?: string
    ) => {
      onlineMyProfileIdRef.current = profileId;
      recordedMatchKeyRef.current = null;
      connectAndSend({
        type: 'create_room',
        clientId: clientIdRef.current,
        playerName,
        colorId,
        difficulty: chosenDifficulty,
        answerMode: chosenAnswerMode,
      });
    },
    [connectAndSend]
  );

  const handleJoinOnlineRoom = useCallback(
    (
      roomCode: string,
      playerName: string,
      colorId: string,
      profileId?: string
    ) => {
      onlineMyProfileIdRef.current = profileId;
      recordedMatchKeyRef.current = null;
      connectAndSend({
        type: 'join_room',
        roomCode,
        clientId: clientIdRef.current,
        playerName,
        colorId,
      });
    },
    [connectAndSend]
  );

  const handleLeaveOnlineRoom = useCallback(() => {
    sendWs({ type: 'leave_room' });
    closeSocketCleanly();
    setPlayMode('local');
    setOnlineRoom(null);
    setOnlineError(null);
    setConfirmResetOpen(false);
    setPhase('SETUP');
    setMenuView('SETUP');
    if (window.location.search.includes('sala=')) {
      window.history.replaceState({}, '', window.location.pathname);
    }
  }, [closeSocketCleanly, sendWs]);

  const scheduleTimeout = useCallback((fn: () => void, ms: number) => {
    const id = window.setTimeout(fn, ms);
    timersRef.current.push(id);
    return id;
  }, []);

  const addEvent = useCallback((player: Player, summary: string) => {
    setEvents((prev) => [
      {
        id: `${Date.now()}-${Math.random().toString(36).slice(2, 7)}`,
        playerName: player.name,
        playerHex: player.color.hex,
        summary,
      },
      ...prev.slice(0, 7),
    ]);
  }, []);

  const toggleMute = () => {
    const next = !muted;
    setMuted(next);
    gameAudio.muted = next;
    if (!next) {
      gameAudio.playClick();
    }
  };

  const startNewLocalGame = useCallback(
    (
      drafts: PlayerDraft[],
      chosenDifficulty: DifficultyLevel,
      chosenAnswerMode: AnswerMode
    ) => {
      clearAllTimers();
      usedQuestionIdsRef.current.clear();
      recordedMatchKeyRef.current = null;
      streaksRef.current = {};
      sessionUnlockedRef.current.clear();

      const bindings: Record<number, string> = {};
      const freshPlayers: Player[] = drafts.map((d, idx) => {
        const id = idx + 1;
        if (d.profileId && !d.isBot) bindings[id] = d.profileId;
        return {
          id,
          name: d.name,
          color: d.color,
          position: 0,
          score: 0,
          completedLap: false,
          skipNextTurn: false,
          correctAnswers: 0,
          questionsAnswered: 0,
          isBot: Boolean(d.isBot),
          botDifficulty: d.isBot ? d.botDifficulty ?? 'medium' : undefined,
        };
      });
      profileBindingsRef.current = bindings;

      const randomStarter = Math.floor(Math.random() * freshPlayers.length);

      setPlayMode('local');
      setDifficulty(chosenDifficulty);
      setAnswerMode(chosenAnswerMode);
      setPlayers(freshPlayers);
      setStarterIndex(randomStarter);
      setCurrentPlayerIndex(randomStarter);
      setRoundNumber(1);
      setFinalRoundTriggered(false);
      setDiceValue(1);
      setStatusMessage('Lanza el dado para avanzar');
      setEvents([]);
      setActiveQuestion(null);
      setActiveExtraCard(null);
      setLastExtraCardId(undefined);
      setTiebreakerIds([]);
      setTiebreakerPointer(0);
      setTiebreakerRound(1);
      setTiebreakerScores({});
      setWinnerId(null);
      setWonByTiebreaker(false);
      setConfirmResetOpen(false);
      setPhase('STARTER_REVEAL');
    },
    [clearAllTimers]
  );

  const evaluateEndOfGame = useCallback((finalPlayers: Player[]) => {
    const maxScore = Math.max(...finalPlayers.map((p) => p.score));
    const leaders = finalPlayers.filter((p) => p.score === maxScore);

    if (leaders.length === 1) {
      setWinnerId(leaders[0].id);
      setWonByTiebreaker(false);
      setPhase('GAME_OVER');
      gameAudio.playVictory();
      return;
    }

    const initialTbScores: Record<number, number> = {};
    leaders.forEach((l) => {
      initialTbScores[l.id] = 0;
    });
    setTiebreakerIds(leaders.map((l) => l.id));
    setTiebreakerScores(initialTbScores);
    setTiebreakerPointer(0);
    setTiebreakerRound(1);
    setPhase('TIEBREAKER_INTRO');
  }, []);

  const advanceTurn = useCallback(
    (updatedPlayers: Player[], isFinalRound: boolean) => {
      const total = updatedPlayers.length;
      let nextIdx = (currentPlayerIndex + 1) % total;
      let nextRound = roundNumber;
      const workingPlayers = updatedPlayers.map((p) => ({ ...p }));

      for (let attempts = 0; attempts <= total; attempts++) {
        if (nextIdx === starterIndex) {
          if (isFinalRound) {
            setPlayers(workingPlayers);
            evaluateEndOfGame(workingPlayers);
            return;
          }
          nextRound += 1;
        }

        if (workingPlayers[nextIdx].skipNextTurn) {
          const skippedPlayer = workingPlayers[nextIdx];
          skippedPlayer.skipNextTurn = false;
          addEvent(skippedPlayer, 'Perdió su turno por casilla EXTRA');
          nextIdx = (nextIdx + 1) % total;
        } else {
          break;
        }
      }

      setPlayers(workingPlayers);
      setRoundNumber(nextRound);
      setCurrentPlayerIndex(nextIdx);
      setStatusMessage('Lanza el dado para avanzar');
      setPhase('READY_TO_ROLL');
    },
    [addEvent, currentPlayerIndex, evaluateEndOfGame, roundNumber, starterIndex]
  );

  const movePlayerSteps = useCallback(
    (
      playerIdx: number,
      stepsDelta: number,
      options: { triggerTileOnLand: boolean; basePlayers?: Player[]; baseFinalRound?: boolean }
    ) => {
      const totalSteps = Math.abs(stepsDelta);
      const direction = stepsDelta >= 0 ? 1 : -1;
      let workingPlayers = (options.basePlayers ?? players).map((p) => ({ ...p }));
      let workingFinalRound = options.baseFinalRound ?? finalRoundTriggered;

      if (totalSteps === 0) {
        if (!options.triggerTileOnLand) {
          advanceTurn(workingPlayers, workingFinalRound);
        }
        return;
      }

      setPhase('MOVING');

      const stepOnce = (remaining: number) => {
        const target = workingPlayers[playerIdx];
        let nextPos = target.position;

        if (direction > 0) {
          const rawNext = target.position + 1;
          if (rawNext >= TOTAL_TILES) {
            nextPos = rawNext % TOTAL_TILES;
            if (!target.completedLap) {
              target.completedLap = true;
              triggerAchievementForPlayer(target, 'complete_lap');
            }
            workingFinalRound = true;
            setFinalRoundTriggered(true);
          } else {
            nextPos = rawNext;
          }
        } else {
          nextPos = Math.max(0, target.position - 1);
        }

        target.position = nextPos;
        workingPlayers = workingPlayers.map((p, i) => (i === playerIdx ? { ...target } : p));
        setPlayers(workingPlayers);
        gameAudio.playStep();

        if (remaining > 1) {
          scheduleTimeout(() => stepOnce(remaining - 1), 175);
        } else {
          const landedTile = BOARD_TILES[target.position];

          if (!options.triggerTileOnLand) {
            if (target.completedLap && options.baseFinalRound === false) {
              addEvent(target, 'Completó la vuelta al pasar por SALIDA');
            }
            scheduleTimeout(() => {
              advanceTurn(workingPlayers, workingFinalRound);
            }, 260);
            return;
          }

          if (landedTile.type === 'SALIDA') {
            addEvent(target, 'Completó la vuelta y llegó a SALIDA');
            setStatusMessage('¡Llegó a SALIDA! Se cierra la ronda.');
            scheduleTimeout(() => {
              advanceTurn(workingPlayers, workingFinalRound);
            }, 650);
            return;
          }

          if (landedTile.type === 'EXTRA') {
            const card = pickRandomExtraCard(lastExtraCardId);
            setLastExtraCardId(card.id);
            setActiveExtraCard(card);
            setStatusMessage('Casilla blanca EXTRA');
            scheduleTimeout(() => {
              gameAudio.playExtraCard();
              setPhase('EXTRA_CARD');
            }, 240);
            return;
          }

          const q = pickQuestionForCategory(
            landedTile.type,
            usedQuestionIdsRef.current,
            difficulty
          );
          usedQuestionIdsRef.current.add(q.id);
          setActiveQuestion(q);
          setStatusMessage(`Pregunta de ${CATEGORY_META[landedTile.type].label}`);
          scheduleTimeout(() => {
            setPhase('QUESTION');
          }, 240);
        }
      };

      stepOnce(totalSteps);
    },
    [
      addEvent,
      advanceTurn,
      difficulty,
      finalRoundTriggered,
      lastExtraCardId,
      players,
      scheduleTimeout,
      triggerAchievementForPlayer,
    ]
  );

  const handleLocalRollDice = useCallback(() => {
    if (phase !== 'READY_TO_ROLL') return;
    const current = players[currentPlayerIndex];
    if (!current) return;

    setPhase('ROLLING');
    setStatusMessage('Girando el dado...');
    gameAudio.playDiceRoll();

    scheduleTimeout(() => {
      const finalRoll = Math.floor(Math.random() * 6) + 1;
      setDiceValue(finalRoll);
      setStatusMessage(
        `Sacó ${finalRoll} · Avanzando ${finalRoll} ${finalRoll === 1 ? 'casilla' : 'casillas'}`
      );
      scheduleTimeout(() => {
        movePlayerSteps(currentPlayerIndex, finalRoll, { triggerTileOnLand: true });
      }, 360);
    }, 520);
  }, [currentPlayerIndex, movePlayerSteps, phase, players, scheduleTimeout]);

  const handleLocalQuestionComplete = (correct: boolean, timedOut: boolean) => {
    if (!activeQuestion) return;
    const current = players[currentPlayerIndex];
    const catLabel = CATEGORY_META[activeQuestion.category].label;
    const nextScore = correct ? current.score + 1 : current.score;

    const updatedPlayers = players.map((p, idx) => {
      if (idx !== currentPlayerIndex) return p;
      return {
        ...p,
        score: nextScore,
        correctAnswers: correct ? p.correctAnswers + 1 : p.correctAnswers,
        questionsAnswered: p.questionsAnswered + 1,
      };
    });

    if (!current.isBot) {
      if (correct) {
        const nextStreak = (streaksRef.current[current.id] ?? 0) + 1;
        streaksRef.current[current.id] = nextStreak;
        if (nextStreak >= 3) {
          triggerAchievementForPlayer(current, 'streak_3');
        }
        if (nextScore >= 6) {
          triggerAchievementForPlayer(current, 'high_scorer');
        }
      } else {
        streaksRef.current[current.id] = 0;
      }
    }

    if (correct) {
      addEvent(current, `Acertó en ${catLabel} (+1 pto)`);
    } else if (timedOut) {
      addEvent(current, `Se agotó el tiempo en ${catLabel}`);
    } else {
      addEvent(current, `Falló en ${catLabel}`);
    }

    setActiveQuestion(null);
    advanceTurn(updatedPlayers, finalRoundTriggered);
  };

  const handleLocalExtraCardResolve = useCallback(
    (challengeSucceeded = true) => {
      if (!activeExtraCard) return;
      const card = activeExtraCard;
      const current = players[currentPlayerIndex];
      setActiveExtraCard(null);

      if (card.effectType === 'EXTRA_ROLL') {
        addEvent(current, 'Casilla EXTRA: repite tiro de dado');
        setStatusMessage('¡Tiro extra! Lanza el dado nuevamente');
        setPhase('READY_TO_ROLL');
        return;
      }

      if (card.effectType === 'MOVE_FORWARD') {
        const steps = card.value ?? 2;
        addEvent(current, `Casilla EXTRA: avanza ${steps} casillas`);
        setStatusMessage(`Avanza ${steps} casillas adicionales`);
        movePlayerSteps(currentPlayerIndex, steps, {
          triggerTileOnLand: false,
          basePlayers: players,
          baseFinalRound: finalRoundTriggered,
        });
        return;
      }

      if (card.effectType === 'MOVE_BACKWARD') {
        const steps = card.value ?? 2;
        addEvent(current, `Casilla EXTRA: retrocede ${steps} casillas`);
        setStatusMessage(`Retrocede ${steps} casillas`);
        movePlayerSteps(currentPlayerIndex, -steps, {
          triggerTileOnLand: false,
          basePlayers: players,
          baseFinalRound: finalRoundTriggered,
        });
        return;
      }

      let resultingScore = current.score;
      const updatedPlayers = players.map((p, idx) => {
        if (idx !== currentPlayerIndex) return p;
        if (card.effectType === 'CHALLENGE') {
          resultingScore = challengeSucceeded ? p.score + (card.value ?? 1) : p.score;
          return {
            ...p,
            score: resultingScore,
          };
        }
        if (card.effectType === 'BONUS_POINTS') {
          resultingScore = p.score + (card.value ?? 1);
          return {
            ...p,
            score: resultingScore,
          };
        }
        if (card.effectType === 'LOSE_POINTS') {
          resultingScore = Math.max(0, p.score - (card.value ?? 1));
          return {
            ...p,
            score: resultingScore,
          };
        }
        if (card.effectType === 'SKIP_TURN') {
          return {
            ...p,
            skipNextTurn: true,
          };
        }
        return p;
      });

      if (!current.isBot && resultingScore >= 6) {
        triggerAchievementForPlayer(current, 'high_scorer');
      }

      if (card.effectType === 'CHALLENGE') {
        addEvent(
          current,
          challengeSucceeded
            ? `Superó el reto EXTRA (+${card.value ?? 1} pto)`
            : 'No superó el reto EXTRA (0 pts)'
        );
      } else if (card.effectType === 'BONUS_POINTS') {
        addEvent(current, `Casilla EXTRA: +${card.value ?? 1} punto(s)`);
      } else if (card.effectType === 'LOSE_POINTS') {
        addEvent(current, `Casilla EXTRA: -${card.value ?? 1} punto`);
      } else if (card.effectType === 'SKIP_TURN') {
        addEvent(current, 'Casilla EXTRA: pierde su próximo turno');
      }

      advanceTurn(updatedPlayers, finalRoundTriggered);
    },
    [
      activeExtraCard,
      addEvent,
      advanceTurn,
      currentPlayerIndex,
      finalRoundTriggered,
      movePlayerSteps,
      players,
      triggerAchievementForPlayer,
    ]
  );

  const startLocalTiebreakerRound = useCallback(() => {
    const q = pickAnyQuestion(usedQuestionIdsRef.current, difficulty);
    usedQuestionIdsRef.current.add(q.id);
    setActiveQuestion(q);
    setTiebreakerPointer(0);
    setPhase('TIEBREAKER_QUESTION');
  }, [difficulty]);

  const handleLocalTiebreakerAnswer = (correct: boolean, timedOut: boolean) => {
    const activeTbId = tiebreakerIds[tiebreakerPointer];
    const tbPlayer = players.find((p) => p.id === activeTbId);
    if (!tbPlayer) return;

    const nextScore = correct ? tbPlayer.score + 1 : tbPlayer.score;
    const updatedPlayers = players.map((p) => {
      if (p.id !== activeTbId) return p;
      return {
        ...p,
        score: nextScore,
        correctAnswers: correct ? p.correctAnswers + 1 : p.correctAnswers,
        questionsAnswered: p.questionsAnswered + 1,
      };
    });

    if (!tbPlayer.isBot) {
      if (correct) {
        const nextStreak = (streaksRef.current[tbPlayer.id] ?? 0) + 1;
        streaksRef.current[tbPlayer.id] = nextStreak;
        if (nextStreak >= 3) {
          triggerAchievementForPlayer(tbPlayer, 'streak_3');
        }
        if (nextScore >= 6) {
          triggerAchievementForPlayer(tbPlayer, 'high_scorer');
        }
      } else {
        streaksRef.current[tbPlayer.id] = 0;
      }
    }

    const nextTbScores = {
      ...tiebreakerScores,
      [activeTbId]: (tiebreakerScores[activeTbId] ?? 0) + (correct ? 1 : 0),
    };

    setPlayers(updatedPlayers);
    setTiebreakerScores(nextTbScores);

    if (correct) {
      addEvent(tbPlayer, 'Acertó en desempate (+1 pto)');
    } else {
      addEvent(
        tbPlayer,
        timedOut ? 'Se agotó el tiempo en desempate' : 'Falló en desempate'
      );
    }

    if (tiebreakerPointer + 1 < tiebreakerIds.length) {
      const nextQ = pickAnyQuestion(usedQuestionIdsRef.current, difficulty);
      usedQuestionIdsRef.current.add(nextQ.id);
      setActiveQuestion(nextQ);
      setTiebreakerPointer(tiebreakerPointer + 1);
      return;
    }

    setActiveQuestion(null);
    const maxTb = Math.max(...tiebreakerIds.map((id) => nextTbScores[id] ?? 0));
    const remainingLeaders = tiebreakerIds.filter(
      (id) => (nextTbScores[id] ?? 0) === maxTb
    );

    if (remainingLeaders.length === 1) {
      setWinnerId(remainingLeaders[0]);
      setWonByTiebreaker(true);
      setPhase('GAME_OVER');
      gameAudio.playVictory();
      return;
    }

    const resetScores: Record<number, number> = {};
    remainingLeaders.forEach((id) => {
      resetScores[id] = 0;
    });
    setTiebreakerIds(remainingLeaders);
    setTiebreakerScores(resetScores);
    setTiebreakerPointer(0);
    setTiebreakerRound((r) => r + 1);
    setPhase('TIEBREAKER_INTRO');
  };

  // Automate AI Bot turns smoothly in local play
  useEffect(() => {
    if (playMode !== 'local' || showSplash) return;

    if (phase === 'STARTER_REVEAL' && players[starterIndex]?.isBot) {
      const t = window.setTimeout(() => {
        setPhase('READY_TO_ROLL');
      }, 1350);
      return () => window.clearTimeout(t);
    }

    if (phase === 'READY_TO_ROLL' && players[currentPlayerIndex]?.isBot) {
      const t = window.setTimeout(() => {
        handleLocalRollDice();
      }, 750);
      return () => window.clearTimeout(t);
    }

    if (phase === 'TIEBREAKER_INTRO') {
      const tied = players.filter((p) => tiebreakerIds.includes(p.id));
      if (tied.length > 0 && tied.every((p) => p.isBot)) {
        const t = window.setTimeout(() => {
          startLocalTiebreakerRound();
        }, 1600);
        return () => window.clearTimeout(t);
      }
    }
  }, [
    playMode,
    showSplash,
    phase,
    players,
    starterIndex,
    currentPlayerIndex,
    tiebreakerIds,
    handleLocalRollDice,
    startLocalTiebreakerRound,
  ]);

  const resetLocalToSetup = () => {
    clearAllTimers();
    setConfirmResetOpen(false);
    setActiveQuestion(null);
    setActiveExtraCard(null);
    setPhase('SETUP');
    setMenuView('SETUP');
  };

  if (showSplash) {
    return (
      <>
        <StarryBackground />
        <SplashScreen onComplete={() => setShowSplash(false)} />
      </>
    );
  }

  // ================= ONLINE MULTIPLAYER ACTIVE ROOM =================
  if (playMode === 'online' && onlineRoom) {
    const myClientId = clientIdRef.current;

    if (onlineRoom.phase === 'LOBBY_WAITING') {
      return (
        <>
          <StarryBackground />
          <OnlineLobby
            room={onlineRoom}
            myClientId={myClientId}
            onUpdateProfile={(name, colorId) =>
              sendWs({ type: 'update_lobby_profile', playerName: name, colorId })
            }
            onChangeDifficulty={(lvl) =>
              sendWs({ type: 'set_difficulty', difficulty: lvl })
            }
            onChangeAnswerMode={(mode) =>
              sendWs({ type: 'set_answer_mode', answerMode: mode })
            }
            onStartGame={() => {
              gameAudio.playClick();
              sendWs({ type: 'start_game' });
            }}
            onLeaveRoom={handleLeaveOnlineRoom}
            errorMsg={onlineError}
          />
        </>
      );
    }

    const isHost = onlineRoom.hostClientId === myClientId;
    const currentPlayer =
      onlineRoom.players[onlineRoom.currentPlayerIndex] ?? onlineRoom.players[0];
    const isMyTurn = currentPlayer?.clientId === myClientId;
    const starterPlayer = onlineRoom.players[onlineRoom.starterIndex];
    const isStarterOrHost = starterPlayer?.clientId === myClientId || isHost;
    const tiebreakerPlayer =
      onlineRoom.players.find(
        (p) => p.id === onlineRoom.tiebreakerIds[onlineRoom.tiebreakerPointer]
      ) ?? currentPlayer;
    const isMyTiebreakerTurn = tiebreakerPlayer?.clientId === myClientId;
    const tiedPlayers = onlineRoom.players.filter((p) =>
      onlineRoom.tiebreakerIds.includes(p.id)
    );
    const winner =
      onlineRoom.players.find((p) => p.id === onlineRoom.winnerId) ??
      onlineRoom.players[0];

    const copyInviteInGame = async () => {
      gameAudio.playClick();
      try {
        await navigator.clipboard.writeText(
          `${window.location.origin}/?sala=${onlineRoom.roomCode}`
        );
        setCopiedInviteInGame(true);
        setTimeout(() => setCopiedInviteInGame(false), 1800);
      } catch {
        // ignore clipboard denial
      }
    };

    return (
      <div className="relative min-h-screen bg-black text-white flex flex-col">
        <StarryBackground />

        <header className="relative z-40 border-b border-white/15 bg-black/95 backdrop-blur sticky top-0">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 py-3 flex items-center justify-between gap-4">
            <span className="font-display text-xl sm:text-2xl font-bold tracking-tight text-white whitespace-nowrap shrink-0">
              Neta sabes?
            </span>

            <div className="flex items-center gap-2 text-xs sm:text-sm text-neutral-300 truncate">
              <span className="px-2.5 py-0.5 rounded-full bg-yellow-400/15 border border-yellow-400/40 font-mono font-bold text-yellow-300 shrink-0">
                {onlineRoom.roomCode}
              </span>
              {currentPlayer && (
                <span className="inline-flex items-center gap-1.5 px-2.5 py-0.5 rounded-full bg-white/10 border border-white/15 truncate">
                  <PlayerTokenIcon color={currentPlayer.color} size="sm" />
                  <span className="truncate font-display font-semibold text-white">
                    {currentPlayer.name}
                  </span>
                </span>
              )}
              <span className="hidden md:inline px-2.5 py-0.5 rounded-full bg-purple-500/15 border border-purple-400/35 text-xs font-semibold text-purple-300">
                {DIFFICULTY_META[onlineRoom.difficulty].label}
              </span>
            </div>

            <div className="flex items-center gap-2 shrink-0">
              <button
                type="button"
                onClick={copyInviteInGame}
                className="font-display min-h-[40px] px-3 py-2 rounded-full bg-neutral-950 hover:bg-neutral-900 border border-white/20 text-white text-xs font-semibold inline-flex items-center gap-1.5 transition-colors cursor-pointer whitespace-nowrap shrink-0"
              >
                {copiedInviteInGame ? (
                  <Check className="w-4 h-4 text-emerald-400 shrink-0" aria-hidden="true" />
                ) : (
                  <Link2 className="w-4 h-4 shrink-0" aria-hidden="true" />
                )}
                <span className="hidden sm:inline">
                  {copiedInviteInGame ? 'Copiado' : 'Invitar'}
                </span>
              </button>

              <button
                type="button"
                onClick={toggleMute}
                aria-label={muted ? 'Activar sonido' : 'Silenciar sonido'}
                className="min-h-[40px] px-3 py-2 rounded-full bg-neutral-950 hover:bg-neutral-900 border border-white/20 text-white text-xs font-medium inline-flex items-center gap-1.5 transition-colors cursor-pointer whitespace-nowrap shrink-0"
              >
                {muted ? (
                  <VolumeX className="w-4 h-4 shrink-0" aria-hidden="true" />
                ) : (
                  <Volume2 className="w-4 h-4 text-yellow-400 shrink-0" aria-hidden="true" />
                )}
              </button>

              <button
                type="button"
                onClick={() => {
                  gameAudio.playClick();
                  setConfirmResetOpen(true);
                }}
                className="font-display min-h-[40px] px-3.5 py-2 rounded-full bg-neutral-950 hover:bg-neutral-900 border border-white/20 hover:border-white/45 text-white text-xs font-semibold inline-flex items-center gap-1.5 transition-all cursor-pointer whitespace-nowrap shrink-0"
              >
                <RotateCcw className="w-4 h-4 shrink-0" aria-hidden="true" />
                <span>{isHost ? 'Reiniciar' : 'Salir'}</span>
              </button>
            </div>
          </div>
        </header>

        <main className="relative z-10 flex-1 max-w-7xl w-full mx-auto px-4 sm:px-6 py-4 sm:py-6 grid grid-cols-1 lg:grid-cols-12 gap-5 lg:gap-6 items-start">
          <section className="lg:col-span-7 xl:col-span-8 flex flex-col items-center">
            <BoardView
              players={onlineRoom.players}
              currentPlayerIndex={onlineRoom.currentPlayerIndex}
              isMoving={onlineRoom.phase === 'MOVING'}
            />
          </section>

          <aside className="lg:col-span-5 xl:col-span-4 flex flex-col gap-4">
            {currentPlayer && (
              <DiceRoller
                value={onlineRoom.diceValue}
                isRolling={onlineRoom.phase === 'ROLLING'}
                canRoll={onlineRoom.phase === 'READY_TO_ROLL'}
                currentPlayer={currentPlayer}
                onRoll={() => sendWs({ type: 'roll_dice' })}
                statusMessage={onlineRoom.statusMessage}
                onlineMode={true}
                isMyTurn={isMyTurn}
              />
            )}

            <ScoreboardPanel
              players={onlineRoom.players}
              currentPlayerIndex={onlineRoom.currentPlayerIndex}
              roundNumber={onlineRoom.roundNumber}
              finalRoundTriggered={onlineRoom.finalRoundTriggered}
              difficulty={onlineRoom.difficulty}
              answerMode={onlineRoom.answerMode}
              events={onlineRoom.events}
              myClientId={myClientId}
            />
          </aside>
        </main>

        {onlineRoom.phase === 'STARTER_REVEAL' && starterPlayer && (
          <div
            className="fixed inset-0 z-50 bg-black/85 backdrop-blur-sm flex items-center justify-center p-4"
            role="dialog"
            aria-modal="true"
            aria-labelledby="online-starter-title"
          >
            <div className="w-full max-w-sm bg-black border-2 border-yellow-400/70 rounded-2xl p-6 text-center shadow-[0_0_40px_rgba(250,204,21,0.22)]">
              <div className="w-12 h-12 rounded-full bg-yellow-400/15 border border-yellow-400/40 mx-auto flex items-center justify-center mb-3">
                <Sparkles className="w-6 h-6 text-yellow-400" aria-hidden="true" />
              </div>
              <p className="text-xs font-semibold text-yellow-300">Sorteo de turno inicial</p>
              <h2
                id="online-starter-title"
                className="font-display text-2xl font-bold text-white mt-1"
              >
                ¡Empieza {starterPlayer.name}!
              </h2>
              <div className="mt-4 flex items-center justify-center gap-2.5 text-sm text-neutral-300">
                <PlayerTokenIcon color={starterPlayer.color} size="md" />
                <span>Ficha {starterPlayer.color.name} en SALIDA</span>
              </div>
              {isStarterOrHost ? (
                <button
                  type="button"
                  autoFocus
                  onClick={() => {
                    gameAudio.playClick();
                    sendWs({ type: 'confirm_starter' });
                  }}
                  className="font-display mt-6 w-full min-h-[46px] px-5 py-2.5 rounded-xl bg-yellow-400 hover:bg-yellow-300 hover:shadow-[0_0_22px_rgba(250,204,21,0.45)] text-black font-bold text-sm transition-all cursor-pointer whitespace-nowrap shrink-0"
                >
                  Comenzar primer turno
                </button>
              ) : (
                <p className="mt-5 text-xs text-neutral-400">
                  Esperando a que {starterPlayer.name} comience...
                </p>
              )}
            </div>
          </div>
        )}

        {onlineRoom.phase === 'QUESTION' &&
          onlineRoom.activeQuestion &&
          currentPlayer && (
            <QuestionModal
              question={onlineRoom.activeQuestion}
              player={currentPlayer}
              answerMode={onlineRoom.answerMode}
              onlineMode={true}
              isMyTurn={isMyTurn}
              deadlineAt={onlineRoom.questionDeadlineAt}
              serverResolution={onlineRoom.questionResolution}
              onSubmitOnline={(ans) => sendWs({ type: 'submit_answer', answer: ans })}
              onContinueOnline={() => sendWs({ type: 'continue_after_question' })}
            />
          )}

        {onlineRoom.phase === 'TIEBREAKER_QUESTION' &&
          onlineRoom.activeQuestion &&
          tiebreakerPlayer && (
            <QuestionModal
              question={onlineRoom.activeQuestion}
              player={tiebreakerPlayer}
              answerMode={onlineRoom.answerMode}
              isTiebreaker={true}
              tiebreakerRound={onlineRoom.tiebreakerRound}
              onlineMode={true}
              isMyTurn={isMyTiebreakerTurn}
              deadlineAt={onlineRoom.questionDeadlineAt}
              serverResolution={onlineRoom.questionResolution}
              onSubmitOnline={(ans) => sendWs({ type: 'submit_answer', answer: ans })}
              onContinueOnline={() => sendWs({ type: 'continue_after_question' })}
            />
          )}

        {onlineRoom.phase === 'EXTRA_CARD' &&
          onlineRoom.activeExtraCard &&
          currentPlayer && (
            <ExtraCardModal
              card={onlineRoom.activeExtraCard}
              player={currentPlayer}
              onlineMode={true}
              isMyTurn={isMyTurn}
              onResolve={(ok) =>
                sendWs({ type: 'resolve_extra_card', challengeSucceeded: ok !== false })
              }
            />
          )}

        {onlineRoom.phase === 'TIEBREAKER_INTRO' && (
          <div
            className="fixed inset-0 z-50 bg-black/85 backdrop-blur-sm flex items-center justify-center p-4"
            role="dialog"
            aria-modal="true"
            aria-labelledby="online-tiebreaker-title"
          >
            <div className="w-full max-w-md bg-black border-2 border-yellow-400/70 rounded-2xl p-6 shadow-[0_0_40px_rgba(250,204,21,0.2)]">
              <div className="flex items-center gap-3 mb-3">
                <div className="w-10 h-10 rounded-xl bg-yellow-400/15 border border-yellow-400/40 flex items-center justify-center shrink-0">
                  <Swords className="w-5 h-5 text-yellow-400" aria-hidden="true" />
                </div>
                <div>
                  <p className="text-xs font-semibold text-yellow-300">
                    Ronda de desempate {onlineRoom.tiebreakerRound}
                  </p>
                  <h2
                    id="online-tiebreaker-title"
                    className="font-display text-2xl font-bold text-white"
                  >
                    ¡Empate en el primer lugar!
                  </h2>
                </div>
              </div>

              <p className="text-sm text-neutral-300 leading-relaxed">
                Los jugadores empatados responderán una pregunta decisiva de 30 segundos:
              </p>

              <ul className="mt-4 space-y-2">
                {tiedPlayers.map((p) => (
                  <li
                    key={p.id}
                    className="flex items-center justify-between px-3 py-2 rounded-xl bg-neutral-950 border border-white/15"
                  >
                    <div className="flex items-center gap-2.5">
                      <PlayerTokenIcon color={p.color} size="sm" />
                      <span className="font-display font-bold text-sm text-white">
                        {p.name}
                      </span>
                    </div>
                    <span className="px-2.5 py-0.5 rounded-full bg-yellow-400/15 text-xs font-bold text-yellow-300 tabular-nums">
                      {p.score} pts
                    </span>
                  </li>
                ))}
              </ul>

              {isHost || tiedPlayers[0]?.clientId === myClientId ? (
                <button
                  type="button"
                  autoFocus
                  onClick={() => {
                    gameAudio.playClick();
                    sendWs({ type: 'start_tiebreaker_round' });
                  }}
                  className="font-display mt-5 w-full min-h-[46px] px-5 py-2.5 rounded-xl bg-yellow-400 hover:bg-yellow-300 hover:shadow-[0_0_22px_rgba(250,204,21,0.45)] text-black font-bold text-sm transition-all cursor-pointer whitespace-nowrap shrink-0"
                >
                  Lanzar pregunta de desempate
                </button>
              ) : (
                <p className="mt-5 text-center text-xs text-neutral-400">
                  Esperando inicio del desempate...
                </p>
              )}
            </div>
          </div>
        )}

        {onlineRoom.phase === 'GAME_OVER' && winner && (
          <VictoryModal
            players={onlineRoom.players}
            winner={winner}
            wonByTiebreaker={onlineRoom.wonByTiebreaker}
            onlineMode={true}
            isHost={isHost}
            onPlayAgainSamePlayers={() => sendWs({ type: 'return_to_lobby' })}
            onResetToSetup={handleLeaveOnlineRoom}
          />
        )}

        {confirmResetOpen && (
          <div
            className="fixed inset-0 z-50 bg-black/85 backdrop-blur-sm flex items-center justify-center p-4"
            role="dialog"
            aria-modal="true"
            aria-labelledby="online-reset-title"
          >
            <div className="w-full max-w-sm bg-black border border-white/25 rounded-2xl p-5 sm:p-6 shadow-2xl">
              <h2 id="online-reset-title" className="font-display text-xl font-bold text-white">
                {isHost ? '¿Reiniciar la sala?' : '¿Salir de la partida?'}
              </h2>
              <p className="text-sm text-neutral-300 mt-1.5">
                {isHost
                  ? 'Todos los jugadores regresarán a la sala de espera o puedes salir por completo.'
                  : 'Dejarás esta partida en línea y volverás al menú principal.'}
              </p>
              <div className="mt-5 flex flex-wrap items-center justify-end gap-2">
                <button
                  type="button"
                  onClick={() => setConfirmResetOpen(false)}
                  className="font-display min-h-[40px] px-4 py-2 rounded-xl bg-neutral-950 hover:bg-neutral-900 border border-white/20 text-white text-sm font-medium transition-colors cursor-pointer whitespace-nowrap shrink-0"
                >
                  Cancelar
                </button>
                {isHost && (
                  <button
                    type="button"
                    onClick={() => {
                      setConfirmResetOpen(false);
                      sendWs({ type: 'return_to_lobby' });
                    }}
                    className="font-display min-h-[40px] px-4 py-2 rounded-xl bg-yellow-400 hover:bg-yellow-300 text-black text-sm font-bold transition-colors cursor-pointer whitespace-nowrap shrink-0"
                  >
                    Volver a sala
                  </button>
                )}
                <button
                  type="button"
                  onClick={handleLeaveOnlineRoom}
                  className="font-display min-h-[40px] px-4 py-2 rounded-xl bg-rose-600 hover:bg-rose-500 text-white text-sm font-bold transition-colors cursor-pointer whitespace-nowrap shrink-0"
                >
                  Salir
                </button>
              </div>
            </div>
          </div>
        )}
        <AchievementToast current={achievementQueue[0] ?? null} />
      </div>
    );
  }

  // ================= MAIN MENU & SETUP =================
  if (phase === 'SETUP') {
    return (
      <div className="relative min-h-screen bg-black">
        <StarryBackground />

        {menuView === 'MENU' ? (
          <MainMenu
            inviteRoomCode={initialRoomCode.current}
            muted={muted}
            onToggleMute={toggleMute}
            onPlay={() => setMenuView('SETUP')}
            onOpenProfiles={() => setProfilesOpen(true)}
            onOpenHowToPlay={() => setHowToPlayOpen(true)}
            profileCount={profiles.length}
            matchCount={matchHistory.length}
          />
        ) : (
          <SetupScreen
            initialRoomCode={initialRoomCode.current}
            savedProfiles={profiles}
            onBackToMenu={() => setMenuView('MENU')}
            onStartLocalGame={startNewLocalGame}
            onCreateOnlineRoom={handleCreateOnlineRoom}
            onJoinOnlineRoom={handleJoinOnlineRoom}
            onlineConnecting={onlineConnecting}
            onlineError={onlineError}
          />
        )}

        {howToPlayOpen && <HowToPlayModal onClose={() => setHowToPlayOpen(false)} />}

        {profilesOpen && (
          <ProfilesHistoryModal
            profiles={profiles}
            history={matchHistory}
            onProfilesChange={setProfiles}
            onHistoryCleared={() => setMatchHistory([])}
            onClose={() => setProfilesOpen(false)}
          />
        )}
        <AchievementToast current={achievementQueue[0] ?? null} />
      </div>
    );
  }

  // ================= LOCAL PLAY VIEW =================
  const currentPlayer = players[currentPlayerIndex] ?? players[0];
  const winner = players.find((p) => p.id === winnerId) ?? players[0];
  const tiebreakerPlayer =
    players.find((p) => p.id === tiebreakerIds[tiebreakerPointer]) ?? currentPlayer;
  const tiedPlayers = players.filter((p) => tiebreakerIds.includes(p.id));

  return (
    <div className="relative min-h-screen bg-black text-white flex flex-col">
      <StarryBackground />

      <header className="relative z-40 border-b border-white/15 bg-black/95 backdrop-blur sticky top-0">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 py-3 flex items-center justify-between gap-4">
          <span className="font-display text-xl sm:text-2xl font-bold tracking-tight text-white whitespace-nowrap shrink-0">
            Neta sabes?
          </span>

          <div className="flex items-center gap-2 text-xs sm:text-sm text-neutral-300 truncate">
            {currentPlayer && (
              <>
                <span className="inline-flex items-center gap-1.5 px-3 py-0.5 rounded-full bg-white/10 border border-white/15 truncate">
                  <PlayerTokenIcon color={currentPlayer.color} size="sm" />
                  <span className="truncate font-display font-semibold text-white">
                    {currentPlayer.name}
                  </span>
                </span>
                <span className="hidden sm:inline px-2.5 py-0.5 rounded-full bg-purple-500/15 border border-purple-400/35 text-xs font-semibold text-purple-300">
                  {DIFFICULTY_META[difficulty].label}
                </span>
                {finalRoundTriggered && (
                  <span className="hidden sm:inline px-2.5 py-0.5 rounded-full bg-yellow-400 text-black text-xs font-bold whitespace-nowrap">
                    Última ronda
                  </span>
                )}
              </>
            )}
          </div>

          <div className="flex items-center gap-2 shrink-0">
            <button
              type="button"
              onClick={toggleMute}
              aria-label={muted ? 'Activar sonido' : 'Silenciar sonido'}
              className="font-display min-h-[40px] px-3.5 py-2 rounded-full bg-neutral-950 hover:bg-neutral-900 border border-white/20 text-white text-xs font-semibold inline-flex items-center gap-1.5 transition-colors cursor-pointer whitespace-nowrap shrink-0"
            >
              {muted ? (
                <VolumeX className="w-4 h-4 shrink-0" aria-hidden="true" />
              ) : (
                <Volume2 className="w-4 h-4 text-yellow-400 shrink-0" aria-hidden="true" />
              )}
              <span className="hidden sm:inline">{muted ? 'Silencio' : 'Sonido'}</span>
            </button>

            <button
              type="button"
              onClick={() => {
                gameAudio.playClick();
                setConfirmResetOpen(true);
              }}
              className="font-display min-h-[40px] px-3.5 py-2 rounded-full bg-neutral-950 hover:bg-neutral-900 border border-white/20 hover:border-white/45 text-white text-xs font-semibold inline-flex items-center gap-1.5 transition-all cursor-pointer whitespace-nowrap shrink-0"
            >
              <RotateCcw className="w-4 h-4 shrink-0" aria-hidden="true" />
              <span>Reiniciar</span>
            </button>
          </div>
        </div>
      </header>

      <main className="relative z-10 flex-1 max-w-7xl w-full mx-auto px-4 sm:px-6 py-4 sm:py-6 grid grid-cols-1 lg:grid-cols-12 gap-5 lg:gap-6 items-start">
        <section className="lg:col-span-7 xl:col-span-8 flex flex-col items-center">
          <BoardView
            players={players}
            currentPlayerIndex={currentPlayerIndex}
            isMoving={phase === 'MOVING'}
          />
        </section>

        <aside className="lg:col-span-5 xl:col-span-4 flex flex-col gap-4">
          {currentPlayer && (
            <DiceRoller
              value={diceValue}
              isRolling={phase === 'ROLLING'}
              canRoll={phase === 'READY_TO_ROLL'}
              currentPlayer={currentPlayer}
              onRoll={handleLocalRollDice}
              statusMessage={statusMessage}
            />
          )}

          <ScoreboardPanel
            players={players}
            currentPlayerIndex={currentPlayerIndex}
            roundNumber={roundNumber}
            finalRoundTriggered={finalRoundTriggered}
            difficulty={difficulty}
            answerMode={answerMode}
            events={events}
          />
        </aside>
      </main>

      {phase === 'STARTER_REVEAL' && players[starterIndex] && (
        <div
          className="fixed inset-0 z-50 bg-black/85 backdrop-blur-sm flex items-center justify-center p-4"
          role="dialog"
          aria-modal="true"
          aria-labelledby="starter-title"
        >
          <div className="w-full max-w-sm bg-black border-2 border-yellow-400/70 rounded-2xl p-6 text-center shadow-[0_0_40px_rgba(250,204,21,0.22)]">
            <div className="w-12 h-12 rounded-full bg-yellow-400/15 border border-yellow-400/40 mx-auto flex items-center justify-center mb-3">
              {players[starterIndex].isBot ? (
                <Bot className="w-6 h-6 text-cyan-300" aria-hidden="true" />
              ) : (
                <Sparkles className="w-6 h-6 text-yellow-400" aria-hidden="true" />
              )}
            </div>
            <p className="text-xs font-semibold text-yellow-300">Sorteo de turno inicial</p>
            <h2 id="starter-title" className="font-display text-2xl font-bold text-white mt-1">
              ¡Empieza {players[starterIndex].name}!
            </h2>
            <div className="mt-4 flex items-center justify-center gap-2.5 text-sm text-neutral-300">
              <PlayerTokenIcon color={players[starterIndex].color} size="md" />
              <span>Ficha {players[starterIndex].color.name} en SALIDA</span>
            </div>
            <button
              type="button"
              autoFocus
              onClick={() => {
                gameAudio.playClick();
                setPhase('READY_TO_ROLL');
              }}
              className="font-display mt-6 w-full min-h-[46px] px-5 py-2.5 rounded-xl bg-yellow-400 hover:bg-yellow-300 hover:shadow-[0_0_22px_rgba(250,204,21,0.45)] text-black font-bold text-sm transition-all cursor-pointer whitespace-nowrap shrink-0"
            >
              {players[starterIndex].isBot
                ? 'Iniciando turno del Bot...'
                : 'Comenzar primer turno'}
            </button>
          </div>
        </div>
      )}

      {phase === 'QUESTION' && activeQuestion && currentPlayer && (
        <QuestionModal
          question={activeQuestion}
          player={currentPlayer}
          answerMode={answerMode}
          onComplete={handleLocalQuestionComplete}
        />
      )}

      {phase === 'TIEBREAKER_QUESTION' && activeQuestion && tiebreakerPlayer && (
        <QuestionModal
          question={activeQuestion}
          player={tiebreakerPlayer}
          answerMode={answerMode}
          isTiebreaker={true}
          tiebreakerRound={tiebreakerRound}
          onComplete={handleLocalTiebreakerAnswer}
        />
      )}

      {phase === 'EXTRA_CARD' && activeExtraCard && currentPlayer && (
        <ExtraCardModal
          card={activeExtraCard}
          player={currentPlayer}
          onResolve={handleLocalExtraCardResolve}
        />
      )}

      {phase === 'TIEBREAKER_INTRO' && (
        <div
          className="fixed inset-0 z-50 bg-black/85 backdrop-blur-sm flex items-center justify-center p-4"
          role="dialog"
          aria-modal="true"
          aria-labelledby="tiebreaker-title"
        >
          <div className="w-full max-w-md bg-black border-2 border-yellow-400/70 rounded-2xl p-6 shadow-[0_0_40px_rgba(250,204,21,0.2)]">
            <div className="flex items-center gap-3 mb-3">
              <div className="w-10 h-10 rounded-xl bg-yellow-400/15 border border-yellow-400/40 flex items-center justify-center shrink-0">
                <Swords className="w-5 h-5 text-yellow-400" aria-hidden="true" />
              </div>
              <div>
                <p className="text-xs font-semibold text-yellow-300">
                  Ronda de desempate {tiebreakerRound}
                </p>
                <h2 id="tiebreaker-title" className="font-display text-2xl font-bold text-white">
                  ¡Empate en el primer lugar!
                </h2>
              </div>
            </div>

            <p className="text-sm text-neutral-300 leading-relaxed">
              Los siguientes jugadores terminaron empatados y responderán una pregunta
              decisiva con 30 segundos cada uno:
            </p>

            <ul className="mt-4 space-y-2">
              {tiedPlayers.map((p) => (
                <li
                  key={p.id}
                  className="flex items-center justify-between px-3 py-2 rounded-xl bg-neutral-950 border border-white/15"
                >
                  <div className="flex items-center gap-2.5">
                    <PlayerTokenIcon color={p.color} size="sm" />
                    <span className="font-display font-bold text-sm text-white">
                      {p.name}
                    </span>
                  </div>
                  <span className="px-2.5 py-0.5 rounded-full bg-yellow-400/15 text-xs font-bold text-yellow-300 tabular-nums">
                    {p.score} pts
                  </span>
                </li>
              ))}
            </ul>

            <button
              type="button"
              autoFocus
              onClick={() => {
                gameAudio.playClick();
                startLocalTiebreakerRound();
              }}
              className="font-display mt-5 w-full min-h-[46px] px-5 py-2.5 rounded-xl bg-yellow-400 hover:bg-yellow-300 hover:shadow-[0_0_22px_rgba(250,204,21,0.45)] text-black font-bold text-sm transition-all cursor-pointer whitespace-nowrap shrink-0"
            >
              Lanzar pregunta de desempate
            </button>
          </div>
        </div>
      )}

      {phase === 'GAME_OVER' && winner && (
        <VictoryModal
          players={players}
          winner={winner}
          wonByTiebreaker={wonByTiebreaker}
          onPlayAgainSamePlayers={() =>
            startNewLocalGame(
              players.map((p) => ({
                name: p.name,
                color: p.color,
                profileId: profileBindingsRef.current[p.id],
                isBot: p.isBot,
                botDifficulty: p.botDifficulty,
              })),
              difficulty,
              answerMode
            )
          }
          onResetToSetup={resetLocalToSetup}
        />
      )}

      {confirmResetOpen && (
        <div
          className="fixed inset-0 z-50 bg-black/85 backdrop-blur-sm flex items-center justify-center p-4"
          role="dialog"
          aria-modal="true"
          aria-labelledby="reset-title"
        >
          <div className="w-full max-w-sm bg-black border border-white/25 rounded-2xl p-5 sm:p-6 shadow-2xl">
            <h2 id="reset-title" className="font-display text-xl font-bold text-white">
              ¿Reiniciar la partida?
            </h2>
            <p className="text-sm text-neutral-300 mt-1.5">
              Se perderá el avance y los puntos de la partida actual.
            </p>
            <div className="mt-5 flex items-center justify-end gap-2.5">
              <button
                type="button"
                onClick={() => setConfirmResetOpen(false)}
                className="font-display min-h-[40px] px-4 py-2 rounded-xl bg-neutral-950 hover:bg-neutral-900 border border-white/20 text-white text-sm font-medium transition-colors cursor-pointer whitespace-nowrap shrink-0"
              >
                Cancelar
              </button>
              <button
                type="button"
                onClick={() => {
                  gameAudio.playClick();
                  resetLocalToSetup();
                }}
                className="font-display min-h-[40px] px-4 py-2 rounded-xl bg-rose-600 hover:bg-rose-500 text-white text-sm font-bold transition-colors cursor-pointer whitespace-nowrap shrink-0"
              >
                Sí, reiniciar
              </button>
            </div>
          </div>
        </div>
      )}

      <AchievementToast current={achievementQueue[0] ?? null} />
    </div>
  );
}
