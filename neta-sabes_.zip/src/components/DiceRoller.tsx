import { Dices } from 'lucide-react';
import { motion } from 'motion/react';
import { Player } from '../types/game';
import { gameAudio } from '../utils/sound';
import { PlayerTokenIcon } from './PlayerTokenIcon';

interface DiceRollerProps {
  value: number;
  isRolling: boolean;
  canRoll: boolean;
  currentPlayer: Player;
  onRoll: () => void;
  statusMessage: string;
  onlineMode?: boolean;
  isMyTurn?: boolean;
}

const PIP_POSITIONS: Record<number, Array<[number, number]>> = {
  1: [[50, 50]],
  2: [
    [28, 28],
    [72, 72],
  ],
  3: [
    [28, 28],
    [50, 50],
    [72, 72],
  ],
  4: [
    [28, 28],
    [72, 28],
    [28, 72],
    [72, 72],
  ],
  5: [
    [28, 28],
    [72, 28],
    [50, 50],
    [28, 72],
    [72, 72],
  ],
  6: [
    [28, 24],
    [72, 24],
    [28, 50],
    [72, 50],
    [28, 76],
    [72, 76],
  ],
};

const FACE_ROTATIONS: Record<number, { rotateX: number; rotateY: number }> = {
  1: { rotateX: 0, rotateY: 0 },
  2: { rotateX: 0, rotateY: -90 },
  3: { rotateX: -90, rotateY: 0 },
  4: { rotateX: 90, rotateY: 0 },
  5: { rotateX: 0, rotateY: 90 },
  6: { rotateX: 0, rotateY: 180 },
};

function DieFace({ faceValue, transform }: { faceValue: number; transform: string }) {
  const pips = PIP_POSITIONS[faceValue] ?? PIP_POSITIONS[1];
  return (
    <div
      className="absolute inset-0 rounded-xl bg-white border-2 border-neutral-200 shadow-inner"
      style={{
        transform,
        backfaceVisibility: 'hidden',
      }}
    >
      {pips.map(([cx, cy], idx) => (
        <span
          key={idx}
          className="absolute w-2.5 h-2.5 rounded-full bg-black -translate-x-1/2 -translate-y-1/2"
          style={{ left: `${cx}%`, top: `${cy}%` }}
        />
      ))}
    </div>
  );
}

export function DiceRoller({
  value,
  isRolling,
  canRoll,
  currentPlayer,
  onRoll,
  statusMessage,
  onlineMode = false,
  isMyTurn = true,
}: DiceRollerProps) {
  const rollBlockedByTurn = (onlineMode && !isMyTurn) || Boolean(currentPlayer.isBot);
  const targetRot = FACE_ROTATIONS[value] ?? FACE_ROTATIONS[1];

  let buttonText = 'Lanzar dado';
  if (isRolling) {
    buttonText = 'Lanzando...';
  } else if (currentPlayer.isBot) {
    buttonText = `Bot pensando...`;
  } else if (rollBlockedByTurn) {
    buttonText = `Turno de ${currentPlayer.name}`;
  }

  return (
    <div
      className="bg-black border rounded-2xl p-4 sm:p-5 transition-all"
      style={{
        borderColor: currentPlayer.color.hex,
        boxShadow: `0 0 28px ${currentPlayer.color.hex}33`,
      }}
    >
      <div className="flex items-center justify-between gap-4">
        <div className="min-w-0">
          <div className="flex items-center gap-2.5">
            <PlayerTokenIcon color={currentPlayer.color} size="sm" />
            <span className="font-display text-lg font-bold text-white truncate">
              {currentPlayer.name}
            </span>
          </div>
          <p className="text-sm text-neutral-300 mt-1">{statusMessage}</p>
        </div>

        {/* 3D Animated Cube Die */}
        <div
          aria-live="polite"
          aria-label={`Dado mostrando ${value}`}
          className="w-16 h-16 shrink-0 flex items-center justify-center"
          style={{ perspective: '420px' }}
        >
          <motion.div
            className="relative w-14 h-14"
            style={{ transformStyle: 'preserve-3d' }}
            animate={
              isRolling
                ? {
                    rotateX: [0, 220, 460],
                    rotateY: [0, 310, 620],
                    rotateZ: [0, 90, 180],
                    scale: [1, 1.12, 1],
                  }
                : {
                    rotateX: targetRot.rotateX,
                    rotateY: targetRot.rotateY,
                    rotateZ: 0,
                    scale: 1,
                  }
            }
            transition={
              isRolling
                ? { duration: 0.45, repeat: Infinity, ease: 'linear' }
                : { type: 'spring', stiffness: 260, damping: 20 }
            }
          >
            <DieFace faceValue={1} transform="translateZ(28px)" />
            <DieFace faceValue={2} transform="rotateY(90deg) translateZ(28px)" />
            <DieFace faceValue={3} transform="rotateX(90deg) translateZ(28px)" />
            <DieFace faceValue={4} transform="rotateX(-90deg) translateZ(28px)" />
            <DieFace faceValue={5} transform="rotateY(-90deg) translateZ(28px)" />
            <DieFace faceValue={6} transform="rotateY(180deg) translateZ(28px)" />
          </motion.div>
        </div>
      </div>

      <button
        type="button"
        onClick={() => {
          gameAudio.playClick();
          onRoll();
        }}
        disabled={!canRoll || isRolling || rollBlockedByTurn}
        className="font-display mt-4 w-full min-h-[48px] px-5 py-2.5 rounded-xl bg-yellow-400 hover:bg-yellow-300 hover:shadow-[0_0_24px_rgba(250,204,21,0.45)] active:scale-[0.99] disabled:bg-neutral-900 disabled:text-neutral-500 disabled:shadow-none text-black font-bold text-base inline-flex items-center justify-center gap-2 transition-all cursor-pointer disabled:cursor-not-allowed whitespace-nowrap shrink-0 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-yellow-300"
      >
        <Dices className="w-5 h-5 shrink-0" aria-hidden="true" />
        <span className="truncate">{buttonText}</span>
      </button>
    </div>
  );
}
