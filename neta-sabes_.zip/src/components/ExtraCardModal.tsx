import { useEffect, useRef } from 'react';
import {
  ArrowLeft,
  ArrowRight,
  Award,
  Bot,
  Dices,
  PauseCircle,
  Sparkles,
  TriangleAlert,
} from 'lucide-react';
import { motion } from 'motion/react';
import { ExtraCard, Player } from '../types/game';
import { gameAudio } from '../utils/sound';
import { ConfettiBurst } from './ConfettiBurst';
import { PlayerTokenIcon } from './PlayerTokenIcon';

interface ExtraCardModalProps {
  card: ExtraCard;
  player: Player;
  onlineMode?: boolean;
  isMyTurn?: boolean;
  onResolve: (challengeSucceeded?: boolean) => void;
}

function ExtraCardIcon({ type }: { type: ExtraCard['effectType'] }) {
  const cls = 'w-6 h-6 text-black shrink-0';
  switch (type) {
    case 'CHALLENGE':
      return <Sparkles className={cls} aria-hidden="true" />;
    case 'BONUS_POINTS':
      return <Award className={cls} aria-hidden="true" />;
    case 'LOSE_POINTS':
      return <TriangleAlert className={cls} aria-hidden="true" />;
    case 'SKIP_TURN':
      return <PauseCircle className={cls} aria-hidden="true" />;
    case 'MOVE_FORWARD':
      return <ArrowRight className={cls} aria-hidden="true" />;
    case 'MOVE_BACKWARD':
      return <ArrowLeft className={cls} aria-hidden="true" />;
    case 'EXTRA_ROLL':
      return <Dices className={cls} aria-hidden="true" />;
  }
}

export function ExtraCardModal({
  card,
  player,
  onlineMode = false,
  isMyTurn = true,
  onResolve,
}: ExtraCardModalProps) {
  const isChallenge = card.effectType === 'CHALLENGE';
  const isBonus = card.effectType === 'BONUS_POINTS';
  const isLocalBotTurn = !onlineMode && Boolean(player.isBot);
  const resolvedRef = useRef(false);

  useEffect(() => {
    resolvedRef.current = false;
    gameAudio.playCardFlip();
    if (isBonus) {
      gameAudio.playCorrect();
    }
  }, [card.id, isBonus]);

  // Auto-resolve EXTRA card when drawn by an AI Bot
  useEffect(() => {
    if (!isLocalBotTurn) return;

    const timer = window.setTimeout(() => {
      if (resolvedRef.current) return;
      resolvedRef.current = true;
      if (isChallenge) {
        const lvl = player.botDifficulty ?? 'medium';
        const chance = lvl === 'hard' ? 0.85 : lvl === 'medium' ? 0.68 : 0.45;
        const ok = Math.random() < chance;
        if (ok) {
          gameAudio.playCorrect();
        } else {
          gameAudio.playWrong();
        }
        onResolve(ok);
      } else {
        gameAudio.playClick();
        onResolve(true);
      }
    }, 1750);

    return () => window.clearTimeout(timer);
  }, [isLocalBotTurn, isChallenge, player.botDifficulty, onResolve, card.id]);

  return (
    <div
      className="fixed inset-0 z-50 bg-black/85 backdrop-blur-sm flex items-center justify-center p-4"
      role="dialog"
      aria-modal="true"
      aria-labelledby="extra-card-title"
      style={{ perspective: '1200px' }}
    >
      <ConfettiBurst active={isBonus} intensity="burst" />

      <motion.div
        key={card.id}
        initial={{ rotateY: -180, scale: 0.9, opacity: 0.4 }}
        animate={{ rotateY: 0, scale: 1, opacity: 1 }}
        transition={{ duration: 0.42, ease: [0.16, 1, 0.3, 1] }}
        style={{
          transformStyle: 'preserve-3d',
          boxShadow: '0 0 40px rgba(255,255,255,0.22), 0 24px 60px rgba(0,0,0,0.95)',
        }}
        className="w-full max-w-md bg-black text-white rounded-2xl overflow-hidden border-2 border-white"
      >
        <div className="bg-white text-black px-5 py-4 flex items-center justify-between gap-3">
          <div className="flex items-center gap-2.5">
            <div className="w-10 h-10 rounded-xl bg-neutral-100 border border-neutral-300 flex items-center justify-center">
              <ExtraCardIcon type={card.effectType} />
            </div>
            <div>
              <p className="text-xs font-semibold text-neutral-600">Casilla blanca</p>
              <h2 className="font-display text-xl font-bold text-black leading-tight">
                EXTRA
              </h2>
            </div>
          </div>

          <div className="flex items-center gap-2 px-2.5 py-1 rounded-full bg-black text-white text-xs font-semibold">
            <PlayerTokenIcon color={player.color} size="sm" />
            <span className="truncate max-w-[100px]">{player.name}</span>
          </div>
        </div>

        <div className="relative p-5 sm:p-6 bg-black">
          <svg
            viewBox="0 0 24 24"
            className="w-3.5 h-3.5 text-white/40 absolute top-4 right-5 pointer-events-none"
            fill="currentColor"
            aria-hidden="true"
          >
            <path d="M12 0 L14.8 9.2 L24 12 L14.8 14.8 L12 24 L9.2 14.8 L0 12 L9.2 9.2 Z" />
          </svg>

          <h3
            id="extra-card-title"
            className="font-display text-2xl font-bold text-white text-balance"
          >
            {card.title}
          </h3>
          <p className="text-sm sm:text-base text-neutral-300 mt-2.5 leading-relaxed">
            {card.description}
          </p>

          <div className="mt-4 rounded-xl bg-neutral-950 border border-white/20 px-4 py-3 text-sm font-semibold text-white">
            Efecto: {card.effectLabel}
          </div>

          {isLocalBotTurn ? (
            <div className="mt-5 rounded-xl bg-neutral-950 border border-cyan-400/40 px-4 py-3 flex items-center justify-center gap-2.5 text-xs font-semibold text-cyan-300">
              <Bot className="w-4 h-4 animate-pulse shrink-0" aria-hidden="true" />
              <span>{player.name} está aplicando esta casilla EXTRA...</span>
            </div>
          ) : onlineMode && !isMyTurn ? (
            <p className="mt-5 text-center text-xs text-neutral-400">
              Esperando a que {player.name} aplique esta tarjeta...
            </p>
          ) : isChallenge ? (
            <div className="mt-5 grid grid-cols-1 sm:grid-cols-2 gap-2.5">
              <button
                type="button"
                onClick={() => {
                  if (resolvedRef.current) return;
                  resolvedRef.current = true;
                  gameAudio.playCorrect();
                  onResolve(true);
                }}
                className="font-display min-h-[44px] px-4 py-2.5 rounded-xl bg-emerald-500 hover:bg-emerald-400 hover:shadow-[0_0_20px_rgba(52,211,153,0.4)] text-black font-bold text-sm transition-all cursor-pointer whitespace-nowrap shrink-0"
              >
                Reto cumplido (+1 pto)
              </button>
              <button
                type="button"
                onClick={() => {
                  if (resolvedRef.current) return;
                  resolvedRef.current = true;
                  gameAudio.playClick();
                  onResolve(false);
                }}
                className="font-display min-h-[44px] px-4 py-2.5 rounded-xl bg-neutral-900 hover:bg-neutral-800 border border-white/20 text-white font-semibold text-sm transition-all cursor-pointer whitespace-nowrap shrink-0"
              >
                No cumplido (0 pts)
              </button>
            </div>
          ) : (
            <button
              type="button"
              autoFocus
              onClick={() => {
                if (resolvedRef.current) return;
                resolvedRef.current = true;
                gameAudio.playClick();
                onResolve(true);
              }}
              className="font-display mt-5 w-full min-h-[46px] px-5 py-2.5 rounded-xl bg-white hover:bg-neutral-200 hover:shadow-[0_0_24px_rgba(255,255,255,0.35)] text-black font-bold text-base transition-all cursor-pointer whitespace-nowrap shrink-0"
            >
              {card.effectType === 'EXTRA_ROLL'
                ? 'Volver a lanzar dado'
                : 'Aplicar efecto y continuar'}
            </button>
          )}
        </div>
      </motion.div>
    </div>
  );
}
