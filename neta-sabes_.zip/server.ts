import crypto from 'node:crypto';
import http from 'node:http';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import express from 'express';
import { WebSocket, WebSocketServer } from 'ws';
import { BOARD_TILES, CATEGORY_META, PLAYER_COLORS, TOTAL_TILES } from './src/data/board.ts';
import { pickRandomExtraCard } from './src/data/extraCards.ts';
import {
  buildQuestionOptions,
  isAnswerCorrect,
  pickAnyQuestion,
  pickQuestionForCategory,
} from './src/data/questions.ts';
import type {
  AnswerMode,
  DifficultyLevel,
  ExtraCard,
  GamePhase,
  OnlineRoomSnapshot,
  Player,
  PlayerColorOption,
  QuestionResolution,
  TriviaQuestion,
  TurnEvent,
} from './src/types/game.ts';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const PORT = Number(process.env.PORT || 3000);
const ROOM_CHARS = 'ABCDEFGHJKLMNPQRSTUVWXYZ23456789';
const QUESTION_DURATION_MS = 30_000;
const ROOM_TTL_MS = 2 * 60 * 60 * 1000;

interface ServerRoom {
  roomCode: string;
  hostClientId: string;
  difficulty: DifficultyLevel;
  answerMode: AnswerMode;
  phase: GamePhase;
  players: Player[];
  starterIndex: number;
  currentPlayerIndex: number;
  roundNumber: number;
  finalRoundTriggered: boolean;
  diceValue: number;
  statusMessage: string;
  events: TurnEvent[];
  activeFullQuestion: TriviaQuestion | null;
  activeQuestionOptions: string[] | null;
  questionDeadlineAt: number | null;
  questionResolution: QuestionResolution | null;
  activeExtraCard: ExtraCard | null;
  lastExtraCardId?: string;
  usedQuestionIds: Set<string>;
  tiebreakerIds: number[];
  tiebreakerPointer: number;
  tiebreakerRound: number;
  tiebreakerScores: Record<number, number>;
  winnerId: number | null;
  wonByTiebreaker: boolean;
  lastActivityAt: number;
  timers: Set<ReturnType<typeof setTimeout>>;
  questionTimeout: ReturnType<typeof setTimeout> | null;
  clients: Map<string, WebSocket>;
  sessionTokens: Map<string, string>;
}

const rooms = new Map<string, ServerRoom>();

function generateRoomCode(): string {
  let code = '';
  do {
    const bytes = crypto.randomBytes(6);
    code = Array.from(bytes, (b) => ROOM_CHARS[b % ROOM_CHARS.length]).join('');
  } while (rooms.has(code));
  return code;
}

function generateSessionToken(): string {
  return crypto.randomBytes(24).toString('hex');
}

function sanitizeName(raw: unknown, fallback: string): string {
  if (typeof raw !== 'string') return fallback;
  const cleaned = raw.replace(/\s+/g, ' ').trim().slice(0, 18);
  return cleaned || fallback;
}

function isValidDifficulty(val: unknown): val is DifficultyLevel {
  return val === 'easy' || val === 'medium' || val === 'hard';
}

function isValidAnswerMode(val: unknown): val is AnswerMode {
  return val === 'multiple_choice' || val === 'typed';
}

function isValidRoomCode(val: unknown): val is string {
  return typeof val === 'string' && /^[A-Z0-9]{6}$/.test(val);
}

function pickAvailableColor(players: Player[], preferredId?: string): PlayerColorOption {
  const taken = new Set(players.map((p) => p.color.id));
  if (preferredId) {
    const match = PLAYER_COLORS.find((c) => c.id === preferredId && !taken.has(c.id));
    if (match) return match;
  }
  return PLAYER_COLORS.find((c) => !taken.has(c.id)) ?? PLAYER_COLORS[players.length % PLAYER_COLORS.length];
}

function clearRoomTimers(room: ServerRoom) {
  room.timers.forEach((t) => clearTimeout(t));
  room.timers.clear();
  if (room.questionTimeout) {
    clearTimeout(room.questionTimeout);
    room.questionTimeout = null;
  }
}

function scheduleRoomTimeout(room: ServerRoom, fn: () => void, ms: number) {
  const t = setTimeout(() => {
    room.timers.delete(t);
    fn();
  }, ms);
  room.timers.add(t);
  return t;
}

function toSnapshot(room: ServerRoom): OnlineRoomSnapshot {
  return {
    roomCode: room.roomCode,
    hostClientId: room.hostClientId,
    difficulty: room.difficulty,
    answerMode: room.answerMode,
    phase: room.phase,
    players: room.players,
    starterIndex: room.starterIndex,
    currentPlayerIndex: room.currentPlayerIndex,
    roundNumber: room.roundNumber,
    finalRoundTriggered: room.finalRoundTriggered,
    diceValue: room.diceValue,
    statusMessage: room.statusMessage,
    events: room.events,
    activeQuestion: room.activeFullQuestion
      ? {
          id: room.activeFullQuestion.id,
          category: room.activeFullQuestion.category,
          difficulty: room.activeFullQuestion.difficulty,
          prompt: room.activeFullQuestion.prompt,
          options: room.activeQuestionOptions ?? undefined,
        }
      : null,
    questionDeadlineAt: room.questionDeadlineAt,
    questionResolution: room.questionResolution,
    activeExtraCard: room.activeExtraCard,
    tiebreakerIds: room.tiebreakerIds,
    tiebreakerPointer: room.tiebreakerPointer,
    tiebreakerRound: room.tiebreakerRound,
    tiebreakerScores: room.tiebreakerScores,
    winnerId: room.winnerId,
    wonByTiebreaker: room.wonByTiebreaker,
  };
}

function broadcastRoom(room: ServerRoom) {
  room.lastActivityAt = Date.now();
  const payload = JSON.stringify({
    type: 'room_state',
    state: toSnapshot(room),
  });
  for (const ws of room.clients.values()) {
    if (ws.readyState === WebSocket.OPEN) {
      ws.send(payload);
    }
  }
}

function sendError(ws: WebSocket, message: string) {
  if (ws.readyState === WebSocket.OPEN) {
    ws.send(JSON.stringify({ type: 'error', message }));
  }
}

function addRoomEvent(room: ServerRoom, player: Player, summary: string) {
  room.events = [
    {
      id: `${Date.now()}-${crypto.randomBytes(3).toString('hex')}`,
      playerName: player.name,
      playerHex: player.color.hex,
      summary,
    },
    ...room.events.slice(0, 7),
  ];
}

function evaluateEndOfGame(room: ServerRoom) {
  const maxScore = Math.max(...room.players.map((p) => p.score));
  const leaders = room.players.filter((p) => p.score === maxScore);

  if (leaders.length === 1) {
    room.winnerId = leaders[0].id;
    room.wonByTiebreaker = false;
    room.phase = 'GAME_OVER';
    broadcastRoom(room);
    return;
  }

  const initialTbScores: Record<number, number> = {};
  leaders.forEach((l) => {
    initialTbScores[l.id] = 0;
  });
  room.tiebreakerIds = leaders.map((l) => l.id);
  room.tiebreakerScores = initialTbScores;
  room.tiebreakerPointer = 0;
  room.tiebreakerRound = 1;
  room.phase = 'TIEBREAKER_INTRO';
  broadcastRoom(room);
}

function advanceTurn(room: ServerRoom) {
  const total = room.players.length;
  let nextIdx = (room.currentPlayerIndex + 1) % total;
  let nextRound = room.roundNumber;

  for (let attempts = 0; attempts <= total; attempts++) {
    if (nextIdx === room.starterIndex) {
      if (room.finalRoundTriggered) {
        evaluateEndOfGame(room);
        return;
      }
      nextRound += 1;
    }

    if (room.players[nextIdx].skipNextTurn) {
      const skipped = room.players[nextIdx];
      skipped.skipNextTurn = false;
      addRoomEvent(room, skipped, 'Perdió su turno por casilla EXTRA');
      nextIdx = (nextIdx + 1) % total;
    } else {
      break;
    }
  }

  room.roundNumber = nextRound;
  room.currentPlayerIndex = nextIdx;
  room.statusMessage = 'Lanza el dado para avanzar';
  room.phase = 'READY_TO_ROLL';
  broadcastRoom(room);
}

function startQuestionTimer(room: ServerRoom, targetPlayerId: number) {
  if (room.questionTimeout) {
    clearTimeout(room.questionTimeout);
    room.questionTimeout = null;
  }
  room.questionDeadlineAt = Date.now() + QUESTION_DURATION_MS;
  room.questionResolution = null;

  room.questionTimeout = setTimeout(() => {
    room.questionTimeout = null;
    if (
      !room.activeFullQuestion ||
      room.questionResolution ||
      (room.phase !== 'QUESTION' && room.phase !== 'TIEBREAKER_QUESTION')
    ) {
      return;
    }

    room.questionResolution = {
      correct: false,
      timedOut: true,
      submittedAnswer: '',
      displayAnswer: room.activeFullQuestion.displayAnswer,
      playerId: targetPlayerId,
    };
    broadcastRoom(room);
  }, QUESTION_DURATION_MS);
}

function movePlayerSteps(
  room: ServerRoom,
  playerIdx: number,
  stepsDelta: number,
  triggerTileOnLand: boolean
) {
  const totalSteps = Math.abs(stepsDelta);
  const direction = stepsDelta >= 0 ? 1 : -1;

  if (totalSteps === 0) {
    if (!triggerTileOnLand) {
      advanceTurn(room);
    }
    return;
  }

  room.phase = 'MOVING';
  broadcastRoom(room);

  const stepOnce = (remaining: number) => {
    const target = room.players[playerIdx];
    if (!target) return;

    if (direction > 0) {
      const rawNext = target.position + 1;
      if (rawNext >= TOTAL_TILES) {
        target.position = rawNext % TOTAL_TILES;
        target.completedLap = true;
        room.finalRoundTriggered = true;
      } else {
        target.position = rawNext;
      }
    } else {
      target.position = Math.max(0, target.position - 1);
    }

    broadcastRoom(room);

    if (remaining > 1) {
      scheduleRoomTimeout(room, () => stepOnce(remaining - 1), 175);
      return;
    }

    const landedTile = BOARD_TILES[target.position];

    if (!triggerTileOnLand) {
      if (target.completedLap) {
        addRoomEvent(room, target, 'Completó la vuelta al pasar por SALIDA');
      }
      scheduleRoomTimeout(room, () => advanceTurn(room), 280);
      return;
    }

    if (landedTile.type === 'SALIDA') {
      addRoomEvent(room, target, 'Completó la vuelta y llegó a SALIDA');
      room.statusMessage = '¡Llegó a SALIDA! Se cierra la ronda.';
      broadcastRoom(room);
      scheduleRoomTimeout(room, () => advanceTurn(room), 700);
      return;
    }

    if (landedTile.type === 'EXTRA') {
      const card = pickRandomExtraCard(room.lastExtraCardId);
      room.lastExtraCardId = card.id;
      room.activeExtraCard = card;
      room.statusMessage = 'Casilla blanca EXTRA';
      scheduleRoomTimeout(room, () => {
        room.phase = 'EXTRA_CARD';
        broadcastRoom(room);
      }, 240);
      return;
    }

    const q = pickQuestionForCategory(
      landedTile.type,
      room.usedQuestionIds,
      room.difficulty
    );
    room.usedQuestionIds.add(q.id);
    room.activeFullQuestion = q;
    room.activeQuestionOptions =
      room.answerMode === 'multiple_choice' ? buildQuestionOptions(q) : null;
    room.statusMessage = `Pregunta de ${CATEGORY_META[landedTile.type].label}`;
    scheduleRoomTimeout(room, () => {
      room.phase = 'QUESTION';
      startQuestionTimer(room, target.id);
      broadcastRoom(room);
    }, 240);
  };

  stepOnce(totalSteps);
}

// Cleanup inactive rooms periodically
setInterval(() => {
  const now = Date.now();
  for (const [code, room] of rooms.entries()) {
    if (now - room.lastActivityAt > ROOM_TTL_MS && room.clients.size === 0) {
      clearRoomTimers(room);
      rooms.delete(code);
    }
  }
}, 5 * 60 * 1000).unref();

async function bootstrap() {
  const app = express();
  app.use(express.json());

  app.get('/api/health', (_req, res) => {
    res.json({ ok: true });
  });

  app.get('/api/rooms/:code', (req, res) => {
    const code = String(req.params.code || '').toUpperCase().trim();
    if (!isValidRoomCode(code)) {
      res.status(400).json({ exists: false, message: 'Código de sala inválido' });
      return;
    }
    const room = rooms.get(code);
    if (!room) {
      res.status(404).json({ exists: false, message: 'Sala no encontrada' });
      return;
    }
    res.json({
      exists: true,
      roomCode: room.roomCode,
      phase: room.phase,
      difficulty: room.difficulty,
      playerCount: room.players.length,
      joinable: room.phase === 'LOBBY_WAITING' && room.players.length < 4,
    });
  });

  if (process.env.NODE_ENV === 'production') {
    const distPath = path.resolve(__dirname, 'dist');
    app.use(express.static(distPath));
    app.get('/{*splat}', (_req, res) => {
      res.sendFile(path.join(distPath, 'index.html'));
    });
  } else {
    const { createServer: createViteServer } = await import('vite');
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  }

  const server = http.createServer(app);
  const wss = new WebSocketServer({ server, path: '/ws', maxPayload: 16 * 1024 });

  wss.on('connection', (ws) => {
    let boundRoomCode: string | null = null;
    let boundClientId: string | null = null;

    ws.on('message', (raw) => {
      let msg: Record<string, unknown>;
      try {
        msg = JSON.parse(raw.toString());
      } catch {
        sendError(ws, 'Mensaje inválido');
        return;
      }

      const type = msg.type;

      if (type === 'create_room') {
        const clientId =
          typeof msg.clientId === 'string' && msg.clientId.length >= 8 && msg.clientId.length <= 64
            ? msg.clientId
            : crypto.randomUUID();
        const playerName = sanitizeName(msg.playerName, 'Anfitrión');
        const difficulty: DifficultyLevel = isValidDifficulty(msg.difficulty)
          ? msg.difficulty
          : 'medium';
        const answerMode: AnswerMode = isValidAnswerMode(msg.answerMode)
          ? msg.answerMode
          : 'multiple_choice';
        const roomCode = generateRoomCode();
        const sessionToken = generateSessionToken();
        const color = pickAvailableColor([], typeof msg.colorId === 'string' ? msg.colorId : undefined);

        const hostPlayer: Player = {
          id: 1,
          clientId,
          name: playerName,
          color,
          position: 0,
          score: 0,
          completedLap: false,
          skipNextTurn: false,
          correctAnswers: 0,
          questionsAnswered: 0,
          connected: true,
          isHost: true,
        };

        const room: ServerRoom = {
          roomCode,
          hostClientId: clientId,
          difficulty,
          answerMode,
          phase: 'LOBBY_WAITING',
          players: [hostPlayer],
          starterIndex: 0,
          currentPlayerIndex: 0,
          roundNumber: 1,
          finalRoundTriggered: false,
          diceValue: 1,
          statusMessage: 'Esperando jugadores en la sala',
          events: [],
          activeFullQuestion: null,
          activeQuestionOptions: null,
          questionDeadlineAt: null,
          questionResolution: null,
          activeExtraCard: null,
          usedQuestionIds: new Set(),
          tiebreakerIds: [],
          tiebreakerPointer: 0,
          tiebreakerRound: 1,
          tiebreakerScores: {},
          winnerId: null,
          wonByTiebreaker: false,
          lastActivityAt: Date.now(),
          timers: new Set(),
          questionTimeout: null,
          clients: new Map([[clientId, ws]]),
          sessionTokens: new Map([[clientId, sessionToken]]),
        };

        rooms.set(roomCode, room);
        boundRoomCode = roomCode;
        boundClientId = clientId;

        ws.send(
          JSON.stringify({
            type: 'joined_room',
            clientId,
            sessionToken,
            state: toSnapshot(room),
          })
        );
        return;
      }

      if (type === 'join_room') {
        const roomCode = typeof msg.roomCode === 'string' ? msg.roomCode.toUpperCase().trim() : '';
        if (!isValidRoomCode(roomCode)) {
          sendError(ws, 'Ingresa un código de sala válido de 6 caracteres.');
          return;
        }
        const room = rooms.get(roomCode);
        if (!room) {
          sendError(ws, 'No se encontró ninguna sala con ese código.');
          return;
        }

        const clientId =
          typeof msg.clientId === 'string' && msg.clientId.length >= 8 && msg.clientId.length <= 64
            ? msg.clientId
            : crypto.randomUUID();
        const providedToken = typeof msg.sessionToken === 'string' ? msg.sessionToken : '';

        // Check reconnection for an existing player
        const existingPlayer = room.players.find((p) => p.clientId === clientId);
        if (existingPlayer) {
          const expectedToken = room.sessionTokens.get(clientId);
          if (expectedToken && providedToken === expectedToken) {
            existingPlayer.connected = true;
            room.clients.set(clientId, ws);
            boundRoomCode = roomCode;
            boundClientId = clientId;

            ws.send(
              JSON.stringify({
                type: 'joined_room',
                clientId,
                sessionToken: expectedToken,
                state: toSnapshot(room),
              })
            );
            broadcastRoom(room);
            return;
          }
          sendError(ws, 'No se pudo verificar tu sesión en esta sala.');
          return;
        }

        if (room.phase !== 'LOBBY_WAITING') {
          sendError(ws, 'La partida ya comenzó. Espera a que termine o crea una nueva sala.');
          return;
        }

        if (room.players.length >= 4) {
          sendError(ws, 'La sala está llena (máximo 4 jugadores).');
          return;
        }

        const nextId = Math.max(0, ...room.players.map((p) => p.id)) + 1;
        const playerName = sanitizeName(msg.playerName, `Jugador ${nextId}`);
        const color = pickAvailableColor(room.players, typeof msg.colorId === 'string' ? msg.colorId : undefined);
        const sessionToken = generateSessionToken();

        const newPlayer: Player = {
          id: nextId,
          clientId,
          name: playerName,
          color,
          position: 0,
          score: 0,
          completedLap: false,
          skipNextTurn: false,
          correctAnswers: 0,
          questionsAnswered: 0,
          connected: true,
          isHost: false,
        };

        room.players.push(newPlayer);
        room.clients.set(clientId, ws);
        room.sessionTokens.set(clientId, sessionToken);
        boundRoomCode = roomCode;
        boundClientId = clientId;

        ws.send(
          JSON.stringify({
            type: 'joined_room',
            clientId,
            sessionToken,
            state: toSnapshot(room),
          })
        );
        broadcastRoom(room);
        return;
      }

      // All subsequent actions require an authenticated bound room & client
      if (!boundRoomCode || !boundClientId) {
        sendError(ws, 'No estás conectado a ninguna sala.');
        return;
      }
      const room = rooms.get(boundRoomCode);
      if (!room) {
        sendError(ws, 'La sala ya no existe.');
        return;
      }

      if (type === 'update_lobby_profile') {
        if (room.phase !== 'LOBBY_WAITING') return;
        const player = room.players.find((p) => p.clientId === boundClientId);
        if (!player) return;

        if (typeof msg.playerName === 'string') {
          player.name = sanitizeName(msg.playerName, player.name);
        }
        if (typeof msg.colorId === 'string') {
          const desired = PLAYER_COLORS.find((c) => c.id === msg.colorId);
          if (desired && !room.players.some((p) => p.clientId !== boundClientId && p.color.id === desired.id)) {
            player.color = desired;
          }
        }
        broadcastRoom(room);
        return;
      }

      if (type === 'set_difficulty') {
        if (room.hostClientId !== boundClientId) {
          sendError(ws, 'Solo el anfitrión puede cambiar la dificultad.');
          return;
        }
        if (room.phase !== 'LOBBY_WAITING') return;
        if (isValidDifficulty(msg.difficulty)) {
          room.difficulty = msg.difficulty;
          broadcastRoom(room);
        }
        return;
      }

      if (type === 'set_answer_mode') {
        if (room.hostClientId !== boundClientId) {
          sendError(ws, 'Solo el anfitrión puede cambiar el modo de respuesta.');
          return;
        }
        if (room.phase !== 'LOBBY_WAITING') return;
        if (isValidAnswerMode(msg.answerMode)) {
          room.answerMode = msg.answerMode;
          broadcastRoom(room);
        }
        return;
      }

      if (type === 'start_game') {
        if (room.hostClientId !== boundClientId) {
          sendError(ws, 'Solo el anfitrión puede iniciar la partida.');
          return;
        }
        if (room.players.length < 2) {
          sendError(ws, 'Se necesitan al menos 2 jugadores para iniciar.');
          return;
        }
        if (room.phase !== 'LOBBY_WAITING' && room.phase !== 'GAME_OVER') return;

        clearRoomTimers(room);
        room.usedQuestionIds.clear();
        room.players = room.players.map((p) => ({
          ...p,
          position: 0,
          score: 0,
          completedLap: false,
          skipNextTurn: false,
          correctAnswers: 0,
          questionsAnswered: 0,
        }));
        const randomStarter = crypto.randomInt(0, room.players.length);
        room.starterIndex = randomStarter;
        room.currentPlayerIndex = randomStarter;
        room.roundNumber = 1;
        room.finalRoundTriggered = false;
        room.diceValue = 1;
        room.statusMessage = 'Lanza el dado para avanzar';
        room.events = [];
        room.activeFullQuestion = null;
        room.activeQuestionOptions = null;
        room.questionDeadlineAt = null;
        room.questionResolution = null;
        room.activeExtraCard = null;
        room.lastExtraCardId = undefined;
        room.tiebreakerIds = [];
        room.tiebreakerPointer = 0;
        room.tiebreakerRound = 1;
        room.tiebreakerScores = {};
        room.winnerId = null;
        room.wonByTiebreaker = false;
        room.phase = 'STARTER_REVEAL';
        broadcastRoom(room);
        return;
      }

      if (type === 'confirm_starter') {
        if (room.phase !== 'STARTER_REVEAL') return;
        const starter = room.players[room.starterIndex];
        if (starter?.clientId !== boundClientId && room.hostClientId !== boundClientId) {
          return;
        }
        room.phase = 'READY_TO_ROLL';
        broadcastRoom(room);
        return;
      }

      if (type === 'roll_dice') {
        if (room.phase !== 'READY_TO_ROLL') return;
        const activePlayer = room.players[room.currentPlayerIndex];
        if (!activePlayer || activePlayer.clientId !== boundClientId) {
          sendError(ws, 'No es tu turno para lanzar el dado.');
          return;
        }

        room.phase = 'ROLLING';
        room.statusMessage = 'Girando el dado...';
        broadcastRoom(room);

        let ticks = 0;
        const stepRoll = () => {
          room.diceValue = crypto.randomInt(1, 7);
          ticks += 1;
          broadcastRoom(room);
          if (ticks < 6) {
            scheduleRoomTimeout(room, stepRoll, 70);
          } else {
            const finalRoll = crypto.randomInt(1, 7);
            room.diceValue = finalRoll;
            room.statusMessage = `Sacó ${finalRoll} · Avanzando ${finalRoll} ${finalRoll === 1 ? 'casilla' : 'casillas'}`;
            broadcastRoom(room);
            scheduleRoomTimeout(room, () => {
              movePlayerSteps(room, room.currentPlayerIndex, finalRoll, true);
            }, 260);
          }
        };
        scheduleRoomTimeout(room, stepRoll, 70);
        return;
      }

      if (type === 'submit_answer') {
        if (room.phase !== 'QUESTION' && room.phase !== 'TIEBREAKER_QUESTION') return;
        if (!room.activeFullQuestion || room.questionResolution) return;

        const targetPlayer =
          room.phase === 'TIEBREAKER_QUESTION'
            ? room.players.find((p) => p.id === room.tiebreakerIds[room.tiebreakerPointer])
            : room.players[room.currentPlayerIndex];

        if (!targetPlayer || targetPlayer.clientId !== boundClientId) {
          sendError(ws, 'Solo el jugador en turno puede responder.');
          return;
        }

        const rawAnswer = typeof msg.answer === 'string' ? msg.answer.slice(0, 120) : '';
        if (!rawAnswer.trim()) return;

        if (room.questionTimeout) {
          clearTimeout(room.questionTimeout);
          room.questionTimeout = null;
        }

        const correct = isAnswerCorrect(rawAnswer, room.activeFullQuestion);
        room.questionResolution = {
          correct,
          timedOut: false,
          submittedAnswer: rawAnswer.trim(),
          displayAnswer: room.activeFullQuestion.displayAnswer,
          playerId: targetPlayer.id,
        };
        broadcastRoom(room);
        return;
      }

      if (type === 'continue_after_question') {
        if (room.phase !== 'QUESTION' && room.phase !== 'TIEBREAKER_QUESTION') return;
        if (!room.activeFullQuestion || !room.questionResolution) return;

        const targetPlayer =
          room.phase === 'TIEBREAKER_QUESTION'
            ? room.players.find((p) => p.id === room.tiebreakerIds[room.tiebreakerPointer])
            : room.players[room.currentPlayerIndex];

        if (!targetPlayer || (targetPlayer.clientId !== boundClientId && room.hostClientId !== boundClientId)) {
          return;
        }

        const { correct, timedOut } = room.questionResolution;
        const catLabel = CATEGORY_META[room.activeFullQuestion.category].label;

        targetPlayer.score = correct ? targetPlayer.score + 1 : targetPlayer.score;
        targetPlayer.correctAnswers = correct
          ? targetPlayer.correctAnswers + 1
          : targetPlayer.correctAnswers;
        targetPlayer.questionsAnswered += 1;

        if (room.phase === 'QUESTION') {
          if (correct) {
            addRoomEvent(room, targetPlayer, `Acertó en ${catLabel} (+1 pto)`);
          } else if (timedOut) {
            addRoomEvent(room, targetPlayer, `Se agotó el tiempo en ${catLabel}`);
          } else {
            addRoomEvent(room, targetPlayer, `Falló en ${catLabel}`);
          }

          room.activeFullQuestion = null;
          room.activeQuestionOptions = null;
          room.questionDeadlineAt = null;
          room.questionResolution = null;
          advanceTurn(room);
          return;
        }

        // Tiebreaker resolution
        room.tiebreakerScores[targetPlayer.id] =
          (room.tiebreakerScores[targetPlayer.id] ?? 0) + (correct ? 1 : 0);

        if (correct) {
          addRoomEvent(room, targetPlayer, 'Acertó en desempate (+1 pto)');
        } else {
          addRoomEvent(
            room,
            targetPlayer,
            timedOut ? 'Se agotó el tiempo en desempate' : 'Falló en desempate'
          );
        }

        if (room.tiebreakerPointer + 1 < room.tiebreakerIds.length) {
          room.tiebreakerPointer += 1;
          const nextTbPlayer = room.players.find(
            (p) => p.id === room.tiebreakerIds[room.tiebreakerPointer]
          );
          const nextQ = pickAnyQuestion(room.usedQuestionIds, room.difficulty);
          room.usedQuestionIds.add(nextQ.id);
          room.activeFullQuestion = nextQ;
          room.activeQuestionOptions =
            room.answerMode === 'multiple_choice' ? buildQuestionOptions(nextQ) : null;
          startQuestionTimer(room, nextTbPlayer?.id ?? targetPlayer.id);
          broadcastRoom(room);
          return;
        }

        room.activeFullQuestion = null;
        room.activeQuestionOptions = null;
        room.questionDeadlineAt = null;
        room.questionResolution = null;

        const maxTb = Math.max(
          ...room.tiebreakerIds.map((id) => room.tiebreakerScores[id] ?? 0)
        );
        const remainingLeaders = room.tiebreakerIds.filter(
          (id) => (room.tiebreakerScores[id] ?? 0) === maxTb
        );

        if (remainingLeaders.length === 1) {
          room.winnerId = remainingLeaders[0];
          room.wonByTiebreaker = true;
          room.phase = 'GAME_OVER';
          broadcastRoom(room);
          return;
        }

        const resetScores: Record<number, number> = {};
        remainingLeaders.forEach((id) => {
          resetScores[id] = 0;
        });
        room.tiebreakerIds = remainingLeaders;
        room.tiebreakerScores = resetScores;
        room.tiebreakerPointer = 0;
        room.tiebreakerRound += 1;
        room.phase = 'TIEBREAKER_INTRO';
        broadcastRoom(room);
        return;
      }

      if (type === 'resolve_extra_card') {
        if (room.phase !== 'EXTRA_CARD' || !room.activeExtraCard) return;
        const current = room.players[room.currentPlayerIndex];
        if (!current || current.clientId !== boundClientId) {
          sendError(ws, 'Solo el jugador en turno puede resolver la tarjeta EXTRA.');
          return;
        }

        const card = room.activeExtraCard;
        const challengeSucceeded = msg.challengeSucceeded !== false;
        room.activeExtraCard = null;

        if (card.effectType === 'EXTRA_ROLL') {
          addRoomEvent(room, current, 'Casilla EXTRA: repite tiro de dado');
          room.statusMessage = '¡Tiro extra! Lanza el dado nuevamente';
          room.phase = 'READY_TO_ROLL';
          broadcastRoom(room);
          return;
        }

        if (card.effectType === 'MOVE_FORWARD') {
          const steps = card.value ?? 2;
          addRoomEvent(room, current, `Casilla EXTRA: avanza ${steps} casillas`);
          room.statusMessage = `Avanza ${steps} casillas adicionales`;
          movePlayerSteps(room, room.currentPlayerIndex, steps, false);
          return;
        }

        if (card.effectType === 'MOVE_BACKWARD') {
          const steps = card.value ?? 2;
          addRoomEvent(room, current, `Casilla EXTRA: retrocede ${steps} casillas`);
          room.statusMessage = `Retrocede ${steps} casillas`;
          movePlayerSteps(room, room.currentPlayerIndex, -steps, false);
          return;
        }

        if (card.effectType === 'CHALLENGE') {
          if (challengeSucceeded) {
            current.score += card.value ?? 1;
            addRoomEvent(room, current, `Superó el reto EXTRA (+${card.value ?? 1} pto)`);
          } else {
            addRoomEvent(room, current, 'No superó el reto EXTRA (0 pts)');
          }
        } else if (card.effectType === 'BONUS_POINTS') {
          current.score += card.value ?? 1;
          addRoomEvent(room, current, `Casilla EXTRA: +${card.value ?? 1} punto(s)`);
        } else if (card.effectType === 'LOSE_POINTS') {
          current.score = Math.max(0, current.score - (card.value ?? 1));
          addRoomEvent(room, current, `Casilla EXTRA: -${card.value ?? 1} punto`);
        } else if (card.effectType === 'SKIP_TURN') {
          current.skipNextTurn = true;
          addRoomEvent(room, current, 'Casilla EXTRA: pierde su próximo turno');
        }

        advanceTurn(room);
        return;
      }

      if (type === 'start_tiebreaker_round') {
        if (room.phase !== 'TIEBREAKER_INTRO') return;
        const firstTbPlayer = room.players.find((p) => p.id === room.tiebreakerIds[0]);
        if (room.hostClientId !== boundClientId && firstTbPlayer?.clientId !== boundClientId) {
          return;
        }
        const q = pickAnyQuestion(room.usedQuestionIds, room.difficulty);
        room.usedQuestionIds.add(q.id);
        room.activeFullQuestion = q;
        room.activeQuestionOptions =
          room.answerMode === 'multiple_choice' ? buildQuestionOptions(q) : null;
        room.tiebreakerPointer = 0;
        room.phase = 'TIEBREAKER_QUESTION';
        startQuestionTimer(room, firstTbPlayer?.id ?? room.tiebreakerIds[0]);
        broadcastRoom(room);
        return;
      }

      if (type === 'return_to_lobby') {
        if (room.hostClientId !== boundClientId) {
          sendError(ws, 'Solo el anfitrión puede reiniciar la sala.');
          return;
        }
        clearRoomTimers(room);
        room.phase = 'LOBBY_WAITING';
        room.players = room.players.map((p) => ({
          ...p,
          position: 0,
          score: 0,
          completedLap: false,
          skipNextTurn: false,
          correctAnswers: 0,
          questionsAnswered: 0,
        }));
        room.events = [];
        room.activeFullQuestion = null;
        room.activeQuestionOptions = null;
        room.questionDeadlineAt = null;
        room.questionResolution = null;
        room.activeExtraCard = null;
        room.winnerId = null;
        room.wonByTiebreaker = false;
        room.finalRoundTriggered = false;
        room.roundNumber = 1;
        room.statusMessage = 'Esperando jugadores en la sala';
        broadcastRoom(room);
        return;
      }

      if (type === 'leave_room') {
        room.clients.delete(boundClientId);
        if (room.phase === 'LOBBY_WAITING') {
          room.players = room.players.filter((p) => p.clientId !== boundClientId);
          if (room.players.length === 0) {
            clearRoomTimers(room);
            rooms.delete(room.roomCode);
          } else {
            if (room.hostClientId === boundClientId) {
              room.hostClientId = room.players[0].clientId ?? '';
              room.players[0].isHost = true;
            }
            broadcastRoom(room);
          }
        } else {
          const p = room.players.find((pl) => pl.clientId === boundClientId);
          if (p) {
            p.connected = false;
            broadcastRoom(room);
          }
        }
        boundRoomCode = null;
        boundClientId = null;
      }
    });

    ws.on('close', () => {
      if (!boundRoomCode || !boundClientId) return;
      const room = rooms.get(boundRoomCode);
      if (!room) return;

      if (room.clients.get(boundClientId) === ws) {
        room.clients.delete(boundClientId);
      }

      const player = room.players.find((p) => p.clientId === boundClientId);
      if (player) {
        player.connected = false;
        broadcastRoom(room);
      }
    });
  });

  server.listen(PORT, '0.0.0.0', () => {
    console.log(`Neta sabes? server listening on http://0.0.0.0:${PORT}`);
  });
}

bootstrap().catch((err) => {
  console.error('Failed to start server:', err);
  process.exit(1);
});
