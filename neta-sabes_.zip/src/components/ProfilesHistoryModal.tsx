import { FormEvent, useState } from 'react';
import { Bot, History, Lock, Plus, Trash2, Trophy, UserPlus, X } from 'lucide-react';
import { motion } from 'motion/react';
import { ACHIEVEMENTS, AchievementId } from '../data/achievements';
import { PLAYER_COLORS } from '../data/board';
import { DIFFICULTY_META } from '../data/questions';
import {
  clearMatchHistory,
  createProfile,
  deleteProfile,
  LocalProfile,
  MatchRecord,
} from '../utils/profilesStorage';
import { gameAudio } from '../utils/sound';
import { AchievementGlyph } from './AchievementToast';
import { PlayerTokenIcon } from './PlayerTokenIcon';

interface ProfilesHistoryModalProps {
  profiles: LocalProfile[];
  history: MatchRecord[];
  onProfilesChange: (next: LocalProfile[]) => void;
  onHistoryCleared: () => void;
  onClose: () => void;
}

export function ProfilesHistoryModal({
  profiles,
  history,
  onProfilesChange,
  onHistoryCleared,
  onClose,
}: ProfilesHistoryModalProps) {
  const [tab, setTab] = useState<'profiles' | 'history'>('profiles');
  const [username, setUsername] = useState('');
  const [colorId, setColorId] = useState(PLAYER_COLORS[0].id);
  const [confirmClearHistory, setConfirmClearHistory] = useState(false);
  const [selectedBadge, setSelectedBadge] = useState<{
    profileId: string;
    achievementId: AchievementId;
  } | null>(null);

  const handleCreate = (e: FormEvent) => {
    e.preventDefault();
    if (!username.trim()) return;
    gameAudio.playClick();
    const created = createProfile(username, colorId);
    onProfilesChange([created, ...profiles]);
    setUsername('');
  };

  const handleDeleteProfile = (id: string) => {
    gameAudio.playClick();
    const next = deleteProfile(id);
    onProfilesChange(next);
  };

  const handleClearHistory = () => {
    gameAudio.playClick();
    clearMatchHistory();
    onHistoryCleared();
    setConfirmClearHistory(false);
  };

  const formatDate = (iso: string) => {
    try {
      return new Intl.DateTimeFormat('es-MX', {
        dateStyle: 'medium',
        timeStyle: 'short',
      }).format(new Date(iso));
    } catch {
      return iso;
    }
  };

  return (
    <div
      className="fixed inset-0 z-50 bg-black/85 backdrop-blur-sm flex items-center justify-center p-4"
      role="dialog"
      aria-modal="true"
      aria-labelledby="profiles-history-title"
    >
      <motion.div
        initial={{ opacity: 0, scale: 0.96, y: 8 }}
        animate={{ opacity: 1, scale: 1, y: 0 }}
        transition={{ duration: 0.2 }}
        className="w-full max-w-3xl max-h-[90vh] flex flex-col bg-black text-white rounded-2xl border-2 border-pink-500/70 shadow-[0_0_40px_rgba(236,72,153,0.2)] overflow-hidden"
      >
        {/* Header */}
        <div className="px-6 py-4 border-b border-white/15 flex flex-wrap items-center justify-between gap-4 shrink-0">
          <div>
            <h2
              id="profiles-history-title"
              className="font-display text-2xl font-bold text-white"
            >
              Perfiles, Logros e Historial
            </h2>
            <p className="text-xs text-neutral-400 mt-0.5">
              Guardados localmente en este dispositivo
            </p>
          </div>

          <div className="flex items-center gap-3">
            <div className="flex items-center gap-1 p-1 bg-neutral-950 border border-white/15 rounded-xl">
              <button
                type="button"
                onClick={() => {
                  gameAudio.playClick();
                  setTab('profiles');
                }}
                className={`font-display px-3 py-1.5 rounded-lg text-xs font-bold inline-flex items-center gap-1.5 transition-all cursor-pointer whitespace-nowrap shrink-0 ${
                  tab === 'profiles'
                    ? 'bg-pink-500 text-white shadow-[0_0_14px_rgba(236,72,153,0.4)]'
                    : 'text-neutral-300 hover:text-white'
                }`}
              >
                <UserPlus className="w-3.5 h-3.5 shrink-0" aria-hidden="true" />
                <span>Perfiles ({profiles.length})</span>
              </button>
              <button
                type="button"
                onClick={() => {
                  gameAudio.playClick();
                  setTab('history');
                }}
                className={`font-display px-3 py-1.5 rounded-lg text-xs font-bold inline-flex items-center gap-1.5 transition-all cursor-pointer whitespace-nowrap shrink-0 ${
                  tab === 'history'
                    ? 'bg-pink-500 text-white shadow-[0_0_14px_rgba(236,72,153,0.4)]'
                    : 'text-neutral-300 hover:text-white'
                }`}
              >
                <History className="w-3.5 h-3.5 shrink-0" aria-hidden="true" />
                <span>Historial ({history.length})</span>
              </button>
            </div>

            <button
              type="button"
              onClick={() => {
                gameAudio.playClick();
                onClose();
              }}
              aria-label="Cerrar perfiles e historial"
              className="w-10 h-10 rounded-xl bg-neutral-950 hover:bg-neutral-900 border border-white/15 flex items-center justify-center text-neutral-300 hover:text-white transition-colors cursor-pointer shrink-0"
            >
              <X className="w-5 h-5" aria-hidden="true" />
            </button>
          </div>
        </div>

        {/* Body */}
        <div className="p-6 overflow-y-auto flex-1 space-y-5">
          {tab === 'profiles' ? (
            <>
              <form
                onSubmit={handleCreate}
                className="rounded-xl bg-neutral-950 border border-white/15 p-4 space-y-3"
              >
                <p className="font-display text-xs font-semibold text-neutral-300">
                  Crear nuevo perfil local
                </p>
                <div className="flex flex-col sm:flex-row sm:items-center gap-3">
                  <input
                    type="text"
                    maxLength={18}
                    value={username}
                    onChange={(e) => setUsername(e.target.value)}
                    placeholder="Nombre de usuario..."
                    aria-label="Nombre de perfil"
                    className="flex-1 px-3.5 py-2.5 rounded-xl bg-black border border-white/20 focus:border-pink-400 focus:outline-none text-sm font-medium text-white placeholder:text-neutral-500"
                  />

                  <div className="flex items-center gap-2 shrink-0">
                    {PLAYER_COLORS.map((c) => (
                      <button
                        key={c.id}
                        type="button"
                        onClick={() => setColorId(c.id)}
                        aria-label={`Color ${c.name}`}
                        className={`w-8 h-8 rounded-full transition-transform cursor-pointer ${
                          colorId === c.id
                            ? 'ring-2 ring-white scale-110'
                            : 'opacity-55 hover:opacity-100'
                        }`}
                        style={{ backgroundColor: c.hex }}
                      />
                    ))}
                  </div>

                  <button
                    type="submit"
                    disabled={!username.trim()}
                    className="font-display min-h-[42px] px-4 py-2 rounded-xl bg-pink-500 hover:bg-pink-400 hover:shadow-[0_0_20px_rgba(236,72,153,0.4)] disabled:bg-neutral-900 disabled:text-neutral-600 text-white font-bold text-sm inline-flex items-center justify-center gap-1.5 transition-all cursor-pointer disabled:cursor-not-allowed whitespace-nowrap shrink-0"
                  >
                    <Plus className="w-4 h-4 shrink-0" aria-hidden="true" />
                    <span>Crear perfil</span>
                  </button>
                </div>
              </form>

              {profiles.length === 0 ? (
                <div className="rounded-xl border border-dashed border-white/20 p-8 text-center text-sm text-neutral-400">
                  Aún no tienes perfiles guardados. Crea uno arriba para registrar tus
                  estadísticas, logros desbloqueados y seleccionarlo rápido al jugar.
                </div>
              ) : (
                <ul className="grid grid-cols-1 sm:grid-cols-2 gap-3.5">
                  {profiles.map((prof) => {
                    const colorOpt =
                      PLAYER_COLORS.find((c) => c.id === prof.colorId) ?? PLAYER_COLORS[0];
                    const accuracy =
                      prof.totalQuestions > 0
                        ? Math.round((prof.totalCorrect / prof.totalQuestions) * 100)
                        : 0;
                    const unlockedMap = prof.achievements ?? {};
                    const unlockedCount = ACHIEVEMENTS.filter(
                      (a) => Boolean(unlockedMap[a.id])
                    ).length;
                    const inspectedDef =
                      selectedBadge && selectedBadge.profileId === prof.id
                        ? ACHIEVEMENTS.find((a) => a.id === selectedBadge.achievementId)
                        : undefined;
                    const inspectedDate = inspectedDef
                      ? unlockedMap[inspectedDef.id]
                      : undefined;

                    return (
                      <li
                        key={prof.id}
                        style={{
                          borderColor: `${colorOpt.hex}66`,
                          boxShadow: `0 0 18px ${colorOpt.hex}18`,
                        }}
                        className="rounded-xl bg-neutral-950 border p-4 flex flex-col justify-between gap-3"
                      >
                        <div className="flex items-center justify-between gap-3">
                          <div className="flex items-center gap-2.5 min-w-0">
                            <PlayerTokenIcon color={colorOpt} size="md" />
                            <div className="min-w-0">
                              <p className="font-display font-bold text-base text-white truncate">
                                {prof.username}
                              </p>
                              <p className="text-xs text-neutral-400">{colorOpt.name}</p>
                            </div>
                          </div>

                          <button
                            type="button"
                            onClick={() => handleDeleteProfile(prof.id)}
                            aria-label={`Eliminar perfil ${prof.username}`}
                            className="w-9 h-9 rounded-lg bg-black hover:bg-rose-500/20 border border-white/10 text-neutral-400 hover:text-rose-300 flex items-center justify-center transition-colors cursor-pointer shrink-0"
                          >
                            <Trash2 className="w-4 h-4" aria-hidden="true" />
                          </button>
                        </div>

                        <div className="grid grid-cols-4 gap-2 pt-3 border-t border-white/10 text-center">
                          <div>
                            <div className="font-display font-bold text-sm text-white tabular-nums">
                              {prof.matchesPlayed}
                            </div>
                            <div className="text-[11px] text-neutral-400">Partidas</div>
                          </div>
                          <div>
                            <div className="font-display font-bold text-sm text-yellow-400 tabular-nums">
                              {prof.wins}
                            </div>
                            <div className="text-[11px] text-neutral-400">Victorias</div>
                          </div>
                          <div>
                            <div className="font-display font-bold text-sm text-white tabular-nums">
                              {prof.totalPoints}
                            </div>
                            <div className="text-[11px] text-neutral-400">Puntos</div>
                          </div>
                          <div>
                            <div className="font-display font-bold text-sm text-emerald-400 tabular-nums">
                              {accuracy}%
                            </div>
                            <div className="text-[11px] text-neutral-400">Aciertos</div>
                          </div>
                        </div>

                        {/* Unlocked & Locked Achievement Badges */}
                        <div className="pt-3 border-t border-white/10 space-y-2">
                          <div className="flex items-center justify-between text-[11px]">
                            <span className="font-display font-semibold text-neutral-300">
                              Logros desbloqueados
                            </span>
                            <span className="font-display font-bold text-yellow-400 tabular-nums">
                              {unlockedCount} / {ACHIEVEMENTS.length}
                            </span>
                          </div>

                          <div className="flex flex-wrap items-center gap-1.5">
                            {ACHIEVEMENTS.map((ach) => {
                              const isUnlocked = Boolean(unlockedMap[ach.id]);
                              const isSelected =
                                selectedBadge?.profileId === prof.id &&
                                selectedBadge?.achievementId === ach.id;

                              return (
                                <button
                                  key={ach.id}
                                  type="button"
                                  title={`${ach.title}: ${ach.description}`}
                                  aria-label={`${ach.title} (${
                                    isUnlocked ? 'Desbloqueado' : 'Bloqueado'
                                  })`}
                                  onClick={() => {
                                    gameAudio.playClick();
                                    setSelectedBadge(
                                      isSelected
                                        ? null
                                        : { profileId: prof.id, achievementId: ach.id }
                                    );
                                  }}
                                  style={
                                    isUnlocked
                                      ? {
                                          borderColor: ach.accentHex,
                                          backgroundColor: `${ach.accentHex}22`,
                                          color: ach.accentHex,
                                          boxShadow: isSelected
                                            ? `0 0 14px ${ach.accentHex}66`
                                            : `0 0 8px ${ach.accentHex}25`,
                                        }
                                      : undefined
                                  }
                                  className={`w-8 h-8 rounded-full border flex items-center justify-center transition-all cursor-pointer ${
                                    isUnlocked
                                      ? 'hover:scale-110'
                                      : 'bg-black border-white/15 text-neutral-600 opacity-50 hover:opacity-80'
                                  } ${isSelected ? 'ring-2 ring-white scale-110' : ''}`}
                                >
                                  {isUnlocked ? (
                                    <AchievementGlyph icon={ach.icon} className="w-4 h-4" />
                                  ) : (
                                    <Lock className="w-3.5 h-3.5" aria-hidden="true" />
                                  )}
                                </button>
                              );
                            })}
                          </div>

                          {inspectedDef && (
                            <div
                              style={{
                                borderColor: inspectedDate
                                  ? `${inspectedDef.accentHex}66`
                                  : 'rgba(255,255,255,0.15)',
                              }}
                              className="rounded-lg bg-black border px-3 py-2 text-xs"
                            >
                              <div className="flex items-center justify-between gap-2">
                                <span
                                  className="font-display font-bold"
                                  style={{
                                    color: inspectedDate
                                      ? inspectedDef.accentHex
                                      : '#a3a3a3',
                                  }}
                                >
                                  {inspectedDef.title}
                                </span>
                                <span className="text-[10px] text-neutral-400">
                                  {inspectedDate ? 'Desbloqueado' : 'Bloqueado'}
                                </span>
                              </div>
                              <p className="text-neutral-300 mt-0.5">
                                {inspectedDef.description}
                              </p>
                              {inspectedDate && (
                                <p className="text-[10px] text-neutral-500 mt-1">
                                  Obtenido el {formatDate(inspectedDate)}
                                </p>
                              )}
                            </div>
                          )}
                        </div>
                      </li>
                    );
                  })}
                </ul>
              )}
            </>
          ) : (
            <>
              {history.length > 0 && (
                <div className="flex items-center justify-between gap-3">
                  <p className="text-xs text-neutral-400">
                    Últimas {history.length} partidas completadas
                  </p>
                  {!confirmClearHistory ? (
                    <button
                      type="button"
                      onClick={() => setConfirmClearHistory(true)}
                      className="text-xs font-medium text-rose-400 hover:text-rose-300 transition-colors cursor-pointer"
                    >
                      Limpiar historial
                    </button>
                  ) : (
                    <div className="flex items-center gap-2 text-xs">
                      <span className="text-neutral-300">¿Borrar todo?</span>
                      <button
                        type="button"
                        onClick={handleClearHistory}
                        className="px-2.5 py-1 rounded-lg bg-rose-600 hover:bg-rose-500 text-white font-semibold cursor-pointer"
                      >
                        Sí, borrar
                      </button>
                      <button
                        type="button"
                        onClick={() => setConfirmClearHistory(false)}
                        className="px-2.5 py-1 rounded-lg bg-white/10 hover:bg-white/15 text-white cursor-pointer"
                      >
                        Cancelar
                      </button>
                    </div>
                  )}
                </div>
              )}

              {history.length === 0 ? (
                <div className="rounded-xl border border-dashed border-white/20 p-8 text-center text-sm text-neutral-400">
                  Todavía no hay partidas finalizadas en el historial. Completa una partida
                  para ver los resultados aquí.
                </div>
              ) : (
                <ul className="space-y-3">
                  {history.map((match) => (
                    <li
                      key={match.id}
                      className="rounded-xl bg-neutral-950 border border-white/15 p-4 space-y-3"
                    >
                      <div className="flex flex-wrap items-center justify-between gap-2">
                        <div className="flex items-center gap-2 text-sm font-semibold text-white">
                          <Trophy className="w-4 h-4 text-yellow-400 shrink-0" aria-hidden="true" />
                          <span className="font-display">Ganador: {match.winnerName}</span>
                          {match.wonByTiebreaker && (
                            <span className="text-xs text-yellow-300 font-normal">
                              · Por desempate
                            </span>
                          )}
                        </div>
                        <div className="text-xs text-neutral-400 flex items-center gap-2">
                          <span>{match.mode === 'online' ? 'En línea' : 'Local'}</span>
                          <span aria-hidden="true">·</span>
                          <span>{DIFFICULTY_META[match.difficulty].label}</span>
                          <span aria-hidden="true">·</span>
                          <span>{formatDate(match.date)}</span>
                        </div>
                      </div>

                      <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                        {match.players.map((pl, idx) => {
                          const c =
                            PLAYER_COLORS.find((col) => col.id === pl.colorId) ??
                            PLAYER_COLORS[0];
                          return (
                            <div
                              key={idx}
                              className={`flex items-center justify-between gap-2 px-3 py-2 rounded-lg border ${
                                pl.isWinner
                                  ? 'bg-yellow-400/10 border-yellow-400/50'
                                  : 'bg-black border-white/10'
                              }`}
                            >
                              <div className="flex items-center gap-2 min-w-0">
                                <span className="font-display text-xs font-bold text-neutral-400 tabular-nums">
                                  #{pl.placement}
                                </span>
                                <PlayerTokenIcon color={c} size="sm" />
                                <span className="text-xs font-semibold text-white truncate">
                                  {pl.name}
                                </span>
                                {pl.isBot && (
                                  <span className="inline-flex items-center gap-0.5 px-1.5 py-0.5 rounded-full bg-cyan-400/15 text-[10px] font-bold text-cyan-300 shrink-0">
                                    <Bot className="w-2.5 h-2.5" aria-hidden="true" />
                                    IA
                                  </span>
                                )}
                              </div>
                              <span className="px-2 py-0.5 rounded-full bg-white/10 text-xs font-bold text-white tabular-nums shrink-0">
                                {pl.score} pts
                              </span>
                            </div>
                          );
                        })}
                      </div>
                    </li>
                  ))}
                </ul>
              )}
            </>
          )}
        </div>
      </motion.div>
    </div>
  );
}
