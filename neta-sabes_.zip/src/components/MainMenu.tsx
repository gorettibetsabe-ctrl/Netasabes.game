import { BookOpen, Play, Trophy, Volume2, VolumeX } from 'lucide-react';
import { motion } from 'motion/react';
import { BOARD_IMAGE_PATH } from '../data/board';
import { gameAudio } from '../utils/sound';

interface MainMenuProps {
  inviteRoomCode?: string;
  muted: boolean;
  onToggleMute: () => void;
  onPlay: () => void;
  onOpenProfiles: () => void;
  onOpenHowToPlay: () => void;
  profileCount: number;
  matchCount: number;
}

export function MainMenu({
  inviteRoomCode,
  muted,
  onToggleMute,
  onPlay,
  onOpenProfiles,
  onOpenHowToPlay,
  profileCount,
  matchCount,
}: MainMenuProps) {
  return (
    <div className="relative z-10 min-h-screen flex flex-col items-center justify-center p-4 sm:p-6 lg:p-8">
      {/* Top-right Sound Toggle */}
      <div className="w-full max-w-5xl flex justify-end mb-4">
        <button
          type="button"
          onClick={onToggleMute}
          className="font-display min-h-[40px] px-4 py-2 rounded-full bg-black hover:bg-neutral-900 border border-white/20 hover:border-white/45 hover:shadow-[0_0_18px_rgba(255,255,255,0.16)] text-white text-xs font-semibold inline-flex items-center gap-2 transition-all cursor-pointer whitespace-nowrap shrink-0"
        >
          {muted ? (
            <VolumeX className="w-4 h-4 text-neutral-400 shrink-0" aria-hidden="true" />
          ) : (
            <Volume2 className="w-4 h-4 text-yellow-400 shrink-0" aria-hidden="true" />
          )}
          <span>{muted ? 'Sonido desactivado' : 'Sonido activado'}</span>
        </button>
      </div>

      <motion.div
        initial={{ opacity: 0, y: 14 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.35, ease: [0.16, 1, 0.3, 1] }}
        className="relative w-full max-w-5xl bg-black border border-white/20 rounded-3xl p-6 sm:p-8 lg:p-10 shadow-[0_0_70px_rgba(255,255,255,0.06)] grid grid-cols-1 lg:grid-cols-12 gap-8 items-center overflow-hidden"
      >
        {/* Subtle curved orbital line & corner 4-point sparkles */}
        <svg
          viewBox="0 0 800 500"
          className="absolute inset-0 w-full h-full pointer-events-none opacity-25"
          fill="none"
          aria-hidden="true"
        >
          <path
            d="M 380 -40 C 560 90, 740 160, 840 340"
            stroke="rgba(255,255,255,0.35)"
            strokeWidth="1.2"
          />
          <path
            d="M 410 530 C 570 430, 710 420, 830 460"
            stroke="rgba(255,255,255,0.22)"
            strokeWidth="1"
          />
        </svg>

        <svg
          viewBox="0 0 24 24"
          className="w-4 h-4 text-white/70 absolute top-5 right-6 pointer-events-none animate-twinkle"
          fill="currentColor"
          aria-hidden="true"
        >
          <path d="M12 0 L14.8 9.2 L24 12 L14.8 14.8 L12 24 L9.2 14.8 L0 12 L9.2 9.2 Z" />
        </svg>

        {/* Left: Board Showcase */}
        <div className="relative z-10 lg:col-span-6 flex flex-col items-center">
          <div className="relative w-full max-w-[390px] aspect-square rounded-2xl overflow-hidden bg-black border border-white/20 shadow-[0_0_45px_rgba(255,255,255,0.08)]">
            <img
              src={BOARD_IMAGE_PATH}
              alt="Tablero oficial de Neta sabes?"
              referrerPolicy="no-referrer"
              className="w-full h-full object-contain"
            />
          </div>
        </div>

        {/* Right: Title & Game Menu Actions */}
        <div className="relative z-10 lg:col-span-6 flex flex-col justify-center">
          <div className="inline-flex items-center gap-2 text-xs font-semibold text-yellow-300 mb-2">
            <span aria-hidden="true">✦</span>
            <span>Edición Digital Multijugador</span>
            <span aria-hidden="true">·</span>
            <span>2 a 4 jugadores</span>
          </div>

          <h1 className="font-display text-5xl sm:text-6xl font-bold text-white tracking-tight leading-[0.95] text-balance">
            Neta sabes?
          </h1>
          <p className="text-sm sm:text-base text-neutral-300 mt-3.5 leading-relaxed">
            Demuestra cuánto sabes en 7 categorías vibrantes, supera casillas{' '}
            <strong className="text-white">EXTRA</strong> y compite en tiempo real con
            amigos o en un mismo dispositivo.
          </p>

          {inviteRoomCode && (
            <div className="mt-4 rounded-xl bg-black border border-yellow-400/70 shadow-[0_0_20px_rgba(250,204,21,0.18)] px-4 py-3 text-sm text-yellow-200">
              Tienes una invitación activa para la sala{' '}
              <strong className="font-mono text-yellow-300">{inviteRoomCode}</strong>.
              Pulsa <strong>Jugar</strong> para entrar.
            </div>
          )}

          <div className="mt-6 space-y-3">
            <button
              type="button"
              onClick={() => {
                gameAudio.playClick();
                onPlay();
              }}
              className="font-display w-full min-h-[56px] px-6 py-3.5 rounded-2xl bg-yellow-400 hover:bg-yellow-300 hover:shadow-[0_0_28px_rgba(250,204,21,0.5)] active:scale-[0.99] text-black font-bold text-xl inline-flex items-center justify-center gap-2.5 transition-all cursor-pointer whitespace-nowrap shrink-0"
            >
              <Play className="w-5 h-5 fill-current shrink-0" aria-hidden="true" />
              <span>{inviteRoomCode ? `Jugar (Sala ${inviteRoomCode})` : 'Jugar'}</span>
            </button>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              <button
                type="button"
                onClick={() => {
                  gameAudio.playClick();
                  onOpenProfiles();
                }}
                className="font-display min-h-[48px] px-4 py-3 rounded-xl bg-black hover:bg-neutral-900 border border-pink-500/50 hover:border-pink-400 hover:shadow-[0_0_20px_rgba(236,72,153,0.28)] text-white font-semibold text-sm inline-flex items-center justify-center gap-2 transition-all cursor-pointer whitespace-nowrap shrink-0"
              >
                <Trophy className="w-4 h-4 text-pink-400 shrink-0" aria-hidden="true" />
                <span>Perfiles e Historial</span>
              </button>

              <button
                type="button"
                onClick={() => {
                  gameAudio.playClick();
                  onOpenHowToPlay();
                }}
                className="font-display min-h-[48px] px-4 py-3 rounded-xl bg-black hover:bg-neutral-900 border border-cyan-400/50 hover:border-cyan-300 hover:shadow-[0_0_20px_rgba(34,211,238,0.28)] text-white font-semibold text-sm inline-flex items-center justify-center gap-2 transition-all cursor-pointer whitespace-nowrap shrink-0"
              >
                <BookOpen className="w-4 h-4 text-cyan-400 shrink-0" aria-hidden="true" />
                <span>Cómo jugar</span>
              </button>
            </div>
          </div>

          <div className="mt-6 pt-4 border-t border-white/15 flex flex-wrap items-center gap-x-4 gap-y-1 text-xs text-neutral-400 tabular-nums">
            <span>{profileCount} perfiles locales</span>
            <span aria-hidden="true">·</span>
            <span>{matchCount} partidas registradas</span>
            <span aria-hidden="true">·</span>
            <span>147 preguntas en 3 dificultades</span>
          </div>
        </div>
      </motion.div>
    </div>
  );
}
